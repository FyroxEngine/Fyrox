import React, { useState } from 'react';
import type { QuantumForgeProject } from '../types';
import VaultCard from './VaultCard';
import Icon from './icons/Icon';
import { GENRE_TEMPLATES } from '../constants';

interface VaultLibraryProps {
  projects: QuantumForgeProject[];
  onSelectProject: (project: QuantumForgeProject) => void;
  onCreateProject: (templateId: string) => void;
  onDeleteProject: (id: string) => void;
}

const VaultLibrary: React.FC<VaultLibraryProps> = ({ projects, onSelectProject, onCreateProject, onDeleteProject }) => {
  const [templateMenuOpen, setTemplateMenuOpen] = useState(false);

  const handleCreate = (templateId: string) => {
    onCreateProject(templateId);
    setTemplateMenuOpen(false);
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold text-[var(--text-highlight)]">Project Hub</h1>
          <p className="text-[var(--text-secondary)] mt-1">Select or create a project.</p>
        </div>
        <div className="relative">
          <button 
            onClick={() => setTemplateMenuOpen(prev => !prev)}
            className="flex items-center gap-2 bg-[var(--color-accent-primary)] hover:bg-[var(--color-accent-primary-hover)] text-white font-bold px-4 py-2 rounded-md transition-colors h-full"
          >
            <Icon name="plus" className="w-5 h-5"/>
            <span>New Project</span>
          </button>
          {templateMenuOpen && (
            <div 
              onMouseLeave={() => setTemplateMenuOpen(false)}
              className="absolute top-full right-0 mt-2 w-64 bg-[var(--bg-tertiary)] border border-[var(--border-primary)] rounded-md shadow-lg z-30"
            >
              <p className="px-3 py-2 text-xs font-bold text-[var(--text-secondary)] tracking-wider uppercase">Create from Template</p>
              {GENRE_TEMPLATES.map(template => (
                <button 
                  key={template.id}
                  onClick={() => handleCreate(template.id)}
                  className="w-full text-left px-3 py-2 text-sm transition-colors text-[var(--text-primary)] hover:bg-[var(--bg-interactive)]"
                >
                  <div className="flex items-center gap-2">
                    <Icon name={template.icon} className="w-5 h-5 text-[var(--text-highlight)]" />
                    <div>
                      <p className="font-bold">{template.name}</p>
                      <p className="text-xs text-[var(--text-secondary)]">{template.description}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      
      <div className="flex-grow grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 overflow-y-auto pr-2">
        {projects.map(project => (
          <VaultCard 
            key={project.id} 
            project={project} 
            onSelect={onSelectProject} 
            onDelete={onDeleteProject}
          />
        ))}
         {projects.length === 0 && (
            <div className="text-[var(--text-secondary)] col-span-full flex items-center justify-center h-full">
                <p>No projects found. Create one to get started.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default VaultLibrary;