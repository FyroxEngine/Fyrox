// This component is deprecated. Its functionality has been migrated to components/AddPluginModal.tsx
const AddInstrumentModal = () => null;
export default AddInstrumentModal;
