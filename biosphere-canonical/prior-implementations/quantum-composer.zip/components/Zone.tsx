import React from 'react';
import type { Zone } from '../types';

interface ZoneProps {
    zone: Zone;
    isSelected: boolean;
    onSelect: (e: React.MouseEvent) => void;
    onDragStart: (e: React.MouseEvent, offset: {x: number, y: number}) => void;
    onResizeStart: (e: React.MouseEvent, handle: 'tl' | 'tr' | 'bl' | 'br', initialRect: Zone['rect']) => void;
    onContextMenu: (e: React.MouseEvent) => void;
}

const ZoneComponent: React.FC<ZoneProps> = ({ zone, isSelected, onSelect, onDragStart, onResizeStart, onContextMenu }) => {
    const { rect, label, color, resonanceField } = zone;

    const handleMouseDown = (e: React.MouseEvent) => {
        onDragStart(e, { x: e.clientX, y: e.clientY });
    };
    
    const isResonanceField = !!resonanceField;
    const baseClasses = "absolute rounded-lg border-2 zone";
    const selectedClasses = isSelected ? "border-[var(--color-accent-primary)]" : "border-transparent";
    const resonanceClasses = isResonanceField ? "resonance-field-active" : "";

    return (
        <div
            className={`${baseClasses} ${selectedClasses} ${resonanceClasses}`}
            style={{
                left: rect.x,
                top: rect.y,
                width: rect.width,
                height: rect.height,
                backgroundColor: color,
                boxShadow: isSelected ? `0 0 15px ${color}` : 'none',
                zIndex: -1,
            }}
            onClick={onSelect}
            onContextMenu={onContextMenu}
        >
            <div 
                className="absolute -top-8 left-0 text-sm font-bold px-2 py-1 rounded cursor-move bg-[var(--bg-tertiary)] border border-[var(--border-primary)]"
                onMouseDown={handleMouseDown}
            >
                {label}
            </div>

            {isSelected && (
                <>
                    <div onMouseDown={e => onResizeStart(e, 'tl', rect)} className="w-4 h-4 cursor-nwse-resize absolute -top-1 -left-1 bg-white rounded-full border-2 border-[var(--color-accent-primary)]" />
                    <div onMouseDown={e => onResizeStart(e, 'tr', rect)} className="w-4 h-4 cursor-nesw-resize absolute -top-1 -right-1 bg-white rounded-full border-2 border-[var(--color-accent-primary)]" />
                    <div onMouseDown={e => onResizeStart(e, 'bl', rect)} className="w-4 h-4 cursor-nesw-resize absolute -bottom-1 -left-1 bg-white rounded-full border-2 border-[var(--color-accent-primary)]" />
                    <div onMouseDown={e => onResizeStart(e, 'br', rect)} className="w-4 h-4 cursor-nwse-resize absolute -bottom-1 -right-1 bg-white rounded-full border-2 border-[var(--color-accent-primary)]" />
                </>
            )}
        </div>
    );
};

export default ZoneComponent;