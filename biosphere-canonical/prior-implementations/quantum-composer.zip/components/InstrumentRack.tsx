// This component is deprecated. Its functionality has been migrated to components/panels/PluginManagerPanel.tsx
const InstrumentRack = () => null;
export default InstrumentRack;
