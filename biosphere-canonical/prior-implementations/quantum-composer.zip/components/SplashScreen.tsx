import React, { useState } from 'react';
import Icon from './icons/Icon';

interface SplashScreenProps {
  onEnter: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onEnter }) => {
  const [isCollapsing, setIsCollapsing] = useState(false);

  const handleEnterClick = () => {
    setIsCollapsing(true);
    // Wait for the collapse animation to mostly finish before calling onEnter
    setTimeout(onEnter, 3500); // Should match CSS animation duration
  };

  const containerClasses = isCollapsing ? 'splash-collapsing' : 'splash-visible';

  return (
    <div className={`splash-container ${containerClasses}`}>
      <div className="glow-effect"></div>
      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center">
        <div className="sigil w-24 h-24 mb-6 flex items-center justify-center bg-[var(--bg-tertiary)] rounded-2xl border-2 border-[var(--border-primary)] shadow-2xl shadow-[var(--shadow-color)]">
          <Icon name="cubes" className="w-16 h-16 text-[var(--text-highlight)]" />
        </div>
        <h1 className="title text-5xl font-bold text-[var(--text-primary)] tracking-wider">Quantum Forge</h1>
        <p className="subtitle text-lg text-[var(--color-accent-primary)] opacity-80 mt-2 mb-8">Powered by Quantum Quill</p>
        <button 
          onClick={handleEnterClick}
          className="enter-button px-8 py-3 bg-[var(--color-accent-primary-hover)] hover:bg-[var(--color-accent-primary)] text-white font-bold text-lg rounded-md transition-all duration-300 transform hover:scale-105 shadow-lg"
        >
          ENTER
        </button>
      </div>
    </div>
  );
};

export default SplashScreen;
