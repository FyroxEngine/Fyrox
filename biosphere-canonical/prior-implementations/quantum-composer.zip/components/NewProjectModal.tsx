import React, { useState } from 'react';
import type { QuantumForgeProject, ShowcaseCapsule } from '../types';
import { GENRE_TEMPLATES } from '../constants';
import Icon from './icons/Icon';

interface NewProjectModalProps {
    onClose: () => void;
    onSelectTemplate: (template: QuantumForgeProject) => void;
    showcaseCapsules: ShowcaseCapsule[];
    onCreateFromCapsule: (capsule: ShowcaseCapsule) => void;
}

type Tab = 'templates' | 'remix';

const NewProjectModal: React.FC<NewProjectModalProps> = ({ onClose, onSelectTemplate, showcaseCapsules, onCreateFromCapsule }) => {
    const [activeTab, setActiveTab] = useState<Tab>('templates');

    return (
        <div onClick={onClose} className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div 
                onClick={e => e.stopPropagation()} 
                className="bg-[var(--bg-secondary)] w-full max-w-4xl h-full max-h-[80vh] rounded-lg border border-[var(--border-primary)] flex flex-col shadow-2xl shadow-[var(--shadow-color)]"
            >
                <div className="px-6 py-4 border-b border-[var(--border-primary)] flex items-center justify-between flex-shrink-0">
                    <h2 className="text-xl font-bold text-[var(--text-highlight)]">Create New Project</h2>
                    <button onClick={onClose} className="p-2 -mr-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-full hover:bg-[var(--bg-interactive)]">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>

                <div className="flex-shrink-0 border-b border-[var(--border-primary)] px-4">
                    <div className="flex -mb-px">
                        <TabButton name="From Template" icon="plus" active={activeTab === 'templates'} onClick={() => setActiveTab('templates')} />
                        <TabButton name="Remix from Capsule" icon="remix" active={activeTab === 'remix'} onClick={() => setActiveTab('remix')} />
                    </div>
                </div>

                <div className="flex-grow p-6 overflow-y-auto">
                    {activeTab === 'templates' && <TemplateSelector onSelect={onSelectTemplate} />}
                    {activeTab === 'remix' && <CapsuleRemixer capsules={showcaseCapsules} onRemix={onCreateFromCapsule} />}
                </div>
            </div>
        </div>
    );
};

const TabButton: React.FC<{name: string, icon: any, active: boolean, onClick: ()=>void}> = ({name, icon, active, onClick}) => (
    <button 
        onClick={onClick}
        className={`flex items-center gap-2 px-4 py-3 border-b-2 text-sm font-bold transition-colors ${active ? 'border-[var(--color-accent-primary)] text-[var(--color-accent-primary)]' : 'border-transparent text-[var(--text-secondary)] hover:text-[var(--text-primary)]'}`}
    >
        <Icon name={icon} className="w-5 h-5"/>
        {name}
    </button>
);

const TemplateSelector: React.FC<{onSelect: (t: QuantumForgeProject)=>void}> = ({onSelect}) => (
    <div>
        <p className="text-center text-[var(--text-secondary)] mb-6">Start your project from a template to get a head start.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {GENRE_TEMPLATES.map(template => (
                <button 
                    key={template.id}
                    onClick={() => onSelect(template)}
                    className="group relative bg-[var(--bg-tertiary)]/50 border border-[var(--border-primary)] rounded-lg p-5 flex flex-col text-left transition-all duration-300 hover:border-[var(--text-highlight)]/40 hover:bg-[var(--bg-tertiary)] hover:shadow-xl hover:shadow-[var(--shadow-color)]"
                >
                    <div className="flex-grow flex flex-col">
                        <div className="w-10 h-10 flex items-center justify-center bg-[var(--bg-interactive)]/50 rounded-lg mb-4">
                            <Icon name={template.icon} className="w-6 h-6 text-[var(--text-highlight)]" />
                        </div>
                        <h3 className="text-lg font-bold text-[var(--text-highlight)] group-hover:text-[var(--text-primary)] transition-colors">{template.name}</h3>
                        <p className="text-[var(--text-secondary)] mt-1 text-sm flex-grow">{template.description}</p>
                    </div>
                </button>
            ))}
        </div>
    </div>
);

const CapsuleRemixer: React.FC<{capsules: ShowcaseCapsule[], onRemix: (c: ShowcaseCapsule)=>void}> = ({capsules, onRemix}) => (
     <div>
        <p className="text-center text-[var(--text-secondary)] mb-6">Create a new project based on a previously curated Showcase Capsule.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {capsules.length === 0 && (
                <p className="col-span-full text-center text-[var(--text-secondary)] mt-8">No Showcase Capsules found in your projects.</p>
            )}
            {capsules.map(capsule => (
                <div key={capsule.id} className="group relative bg-[var(--bg-tertiary)]/50 border border-[var(--border-primary)] rounded-lg p-5 flex flex-col text-left transition-all duration-300 hover:border-[var(--text-highlight)]/40 hover:bg-[var(--bg-tertiary)]">
                     <h3 className="text-lg font-bold text-[var(--text-highlight)]">{capsule.metadata.title}</h3>
                     <p className="text-sm text-[var(--text-secondary)] mt-1">by {capsule.metadata.author}</p>
                     <p className="text-sm text-[var(--text-primary)] mt-2 flex-grow">{capsule.metadata.description}</p>
                     <div className="flex flex-wrap gap-1 mt-3">
                        {capsule.metadata.tags.map(tag => <span key={tag} className="text-xs px-2 py-0.5 bg-[var(--bg-interactive)] rounded-full">{tag}</span>)}
                    </div>
                     <button onClick={() => onRemix(capsule)} className="button-primary mt-4 w-full flex items-center justify-center gap-2">
                        <Icon name="remix" className="w-5 h-5" />
                        Remix this Capsule
                    </button>
                </div>
            ))}
        </div>
    </div>
)

export default NewProjectModal;