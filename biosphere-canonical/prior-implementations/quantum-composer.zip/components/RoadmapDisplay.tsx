import React from 'react';
import type { BlueprintRoadmapData, RoadmapState, CellStatus } from '../types';
import Icon from './icons/Icon';
import type { IconName } from '../types';

interface RoadmapDisplayProps {
    roadmap: BlueprintRoadmapData;
    roadmapState: RoadmapState;
    onUpdateCell: (layerId: string, versionKey: string, phaseKey: string, status: CellStatus) => void;
}

const STATUS_CYCLE: CellStatus[] = ['locked', 'in-progress', 'sub-phase', 'completed'];
const STATUS_INFO: Record<CellStatus, { icon: IconName; color: string; title: string }> = {
    'locked': { icon: 'lock-closed', color: 'text-slate-500', title: 'Locked' },
    'in-progress': { icon: 'arrow-path', color: 'text-yellow-400 animate-spin', title: 'In Progress' },
    'sub-phase': { icon: 'swirl', color: 'text-sky-400', title: 'Sub-Phase' },
    'completed': { icon: 'check-circle', color: 'text-green-400', title: 'Completed' },
};

const RoadmapDisplay: React.FC<RoadmapDisplayProps> = ({ roadmap, roadmapState, onUpdateCell }) => {
    const versions = Object.keys(roadmap.versions);
    const phases = Object.keys(roadmap.versions[versions[0]] || {});

    const handleCellClick = (versionKey: string, phaseKey: string, currentStatus: CellStatus) => {
        const currentIndex = STATUS_CYCLE.indexOf(currentStatus);
        const nextIndex = (currentIndex + 1) % STATUS_CYCLE.length;
        onUpdateCell(roadmap.layerId, versionKey, phaseKey, STATUS_CYCLE[nextIndex]);
    };

    return (
        <div className="overflow-x-auto">
            <h3 className="text-xl font-bold text-[var(--text-highlight)] mb-4">{roadmap.layerName}</h3>
            <table className="roadmap-table w-full">
                <thead>
                    <tr>
                        <th>VERSION</th>
                        {phases.map(phaseKey => (
                            <th key={phaseKey}>{phaseKey.replace('P', 'PHASE ')}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {versions.map(versionKey => (
                        <tr key={versionKey}>
                            <td className="version-col">{versionKey}</td>
                            {phases.map(phaseKey => {
                                const description = roadmap.versions[versionKey]?.[phaseKey] || '';
                                const cellState = roadmapState[roadmap.layerId]?.[versionKey]?.[phaseKey];
                                const status = cellState?.status || 'locked';
                                const { icon, color, title } = STATUS_INFO[status];

                                return (
                                    <td 
                                        key={phaseKey} 
                                        onClick={() => handleCellClick(versionKey, phaseKey, status)}
                                        className="cursor-pointer hover:bg-[var(--bg-tertiary)]/50 transition-colors"
                                        title={`Click to change status from: ${title}`}
                                    >
                                        <div className="flex flex-col justify-between h-full">
                                            <p className="flex-grow">{description}</p>
                                            <div className="flex justify-end items-center mt-1">
                                                <Icon name={icon} className={`w-4 h-4 ${color}`} />
                                            </div>
                                        </div>
                                    </td>
                                );
                            })}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default RoadmapDisplay;
