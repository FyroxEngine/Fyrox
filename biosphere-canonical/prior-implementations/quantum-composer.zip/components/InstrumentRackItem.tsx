// This component is deprecated. Its functionality has been migrated to components/PluginManagerItem.tsx
const InstrumentRackItem = () => null;
export default InstrumentRackItem;
