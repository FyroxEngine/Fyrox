
import React, { useEffect, useRef } from 'react';

interface ContextMenuProps {
    x: number;
    y: number;
    children: React.ReactNode;
    onClose: () => void;
}

const ContextMenu: React.FC<ContextMenuProps> = ({ x, y, children, onClose }) => {
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                onClose();
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [onClose]);

    const style: React.CSSProperties = {
        top: y,
        left: x,
    };

    return (
        <div
            ref={menuRef}
            style={style}
            className="absolute z-50 w-48 bg-[var(--bg-tertiary)] border border-[var(--border-primary)] rounded-md shadow-lg"
        >
            {children}
        </div>
    );
};

export default ContextMenu;