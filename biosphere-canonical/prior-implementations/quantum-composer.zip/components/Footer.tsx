import React from 'react';

interface FooterProps {
  projectName: string | undefined;
}

const Footer: React.FC<FooterProps> = ({ projectName }) => {
  return (
    <footer style={{ height: '10vh' }} className="flex-shrink-0 px-4 flex items-center justify-between bg-[var(--bg-primary)] border-t border-[var(--border-primary)] text-xs text-[var(--text-secondary)] panel-overlay-bg">
      <div>
        <span>Project: </span>
        <span className="text-[var(--text-primary)] font-bold">{projectName || "None"}</span>
      </div>
      <div>
        <span>Status: Ready</span>
      </div>
    </footer>
  );
};

export default Footer;