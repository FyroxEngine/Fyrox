

import React, { useRef, useState, useCallback, useMemo } from 'react';
import type { QuantumForgeProject, QuantumForgeNode, QuantumForgeNodeUpdate, Port, ContextMenuState, Zone, IconName, MediaAsset, AnimationState, QuantumOutcome, Connection } from '../types';
import Node from './Node';
import ZoneComponent from './Zone';
import { NODE_LIBRARY } from '../../constants';


interface NodeCanvasProps {
    project: QuantumForgeProject;
    view: { x: number; y: number; zoom: number };
    setView: React.Dispatch<React.SetStateAction<{ x: number; y: number; zoom: number }>>;
    selectedIds: string[];
    onSelectNodes: (ids: string[]) => void;
    selectedZoneId: string | null;
    onSelectZone: (id: string | null) => void;
    onUpdateNodes: (nodeUpdates: QuantumForgeNodeUpdate[]) => void;
    onUpdateProject: (updatedProject: QuantumForgeProject) => void;
    onUpdateZone: (zone: Zone) => void;
    setContextMenu: (menu: ContextMenuState | null) => void;
    onAddNode: (type: string, position: {x: number, y: number}, icon: IconName, mediaAsset?: MediaAsset) => void;
    mediaAssets: MediaAsset[];
    animationState: AnimationState;
    isPerformMode: boolean;
    effectiveProbabilities: Map<string, QuantumOutcome[]>;
}

type DraggingState = 
    | { type: 'panning' } 
    | { type: 'draggingNodes' } 
    | { type: 'draggingZone', zoneId: string } 
    | { type: 'resizingZone', zoneId: string, handle: 'tl' | 'tr' | 'bl' | 'br' } 
    | null;

const NodeCanvas: React.FC<NodeCanvasProps> = ({ 
    project, view, setView, 
    selectedIds, onSelectNodes, 
    selectedZoneId, onSelectZone,
    onUpdateNodes, onUpdateProject, onUpdateZone, 
    setContextMenu, onAddNode, mediaAssets,
    animationState, isPerformMode, effectiveProbabilities
}) => {
    const canvasRef = useRef<HTMLDivElement>(null);
    const [draggingState, setDraggingState] = useState<DraggingState>(null);
    const [linkingState, setLinkingState] = useState<{ fromNodeId: string; fromPort: Port; fromPos: { x: number, y: number }; toMouse: { x: number, y: number } } | null>(null);
    const dragStartPos = useRef({ clientX: 0, clientY: 0 });
    const initialPositions = useRef(new Map<string, { x: number, y: number }>());
    const initialZoneRect = useRef<Zone['rect'] | null>(null);

    const nodesById = useMemo(() => 
        project.nodeGraph.nodes.reduce((acc, node) => {
            acc[node.id] = node;
            return acc;
        }, {} as Record<string, QuantumForgeNode>),
    [project.nodeGraph.nodes]);

    const getCanvasCoords = useCallback((clientX: number, clientY: number) => {
        if (!canvasRef.current) return { x: 0, y: 0 };
        const rect = canvasRef.current.getBoundingClientRect();
        return {
            x: (clientX - rect.left - view.x) / view.zoom,
            y: (clientY - rect.top - view.y) / view.zoom,
        };
    }, [view]);

    const getPortPosition = useCallback((node: QuantumForgeNode, portId: string, isInput: boolean) => {
        const ports = isInput ? node.inputs : node.outputs;
        const portIndex = Math.max(0, ports.findIndex(p => p.id === portId));
        const portCount = ports.length;
        
        const y = node.position.y + 60 + (portIndex * 20);
        const x = isInput ? node.position.x : node.position.x + 180; // Node width is 180
        
        return { x, y };
    }, []);

    const getCurvePath = (x1: number, y1: number, x2: number, y2: number) => {
        const dx = x2 - x1;
        const handleX1 = x1 + Math.abs(dx) * 0.5;
        const handleX2 = x2 - Math.abs(dx) * 0.5;
        return `M ${x1} ${y1} C ${handleX1} ${y1}, ${handleX2} ${y2}, ${x2} ${y2}`;
    };

    // FIX: Changed React.MouseEvent to React.MouseEvent<HTMLDivElement> to correctly type `e.currentTarget` as an element with a `style` property.
    const handleMouseDown = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        if (e.button !== 0 || e.target !== canvasRef.current) return;
        dragStartPos.current = { clientX: e.clientX, clientY: e.clientY };
        setDraggingState({ type: 'panning' });
        e.currentTarget.style.cursor = 'grabbing';
    }, []);

    const handleMouseMove = useCallback((e: React.MouseEvent) => {
        const { x, y } = getCanvasCoords(e.clientX, e.clientY);
        if (linkingState) {
            setLinkingState(prev => prev ? { ...prev, toMouse: { x, y } } : null);
        }

        if (!draggingState) return;

        const dx = (e.clientX - dragStartPos.current.clientX) / view.zoom;
        const dy = (e.clientY - dragStartPos.current.clientY) / view.zoom;

        if (draggingState.type === 'panning') {
            setView(v => ({ ...v, x: v.x + dx * view.zoom, y: v.y + dy * view.zoom }));
        } else if (draggingState.type === 'draggingNodes') {
            const updates: QuantumForgeNodeUpdate[] = selectedIds.map(id => {
                const initial = initialPositions.current.get(id) || { x: 0, y: 0 };
                return { id, position: { x: initial.x + dx, y: initial.y + dy } };
            });
            onUpdateNodes(updates);
        } else if (draggingState.type === 'draggingZone' && initialZoneRect.current) {
            const updatedRect = { ...initialZoneRect.current, x: initialZoneRect.current.x + dx, y: initialZoneRect.current.y + dy };
            onUpdateZone({ ...project.zones!.find(z => z.id === draggingState.zoneId)!, rect: updatedRect });
        } else if (draggingState.type === 'resizingZone' && initialZoneRect.current) {
            let { x: ix, y: iy, width: iw, height: ih } = initialZoneRect.current;
            switch(draggingState.handle) {
                case 'tl': onUpdateZone({ ...project.zones!.find(z => z.id === draggingState.zoneId)!, rect: { x: ix + dx, y: iy + dy, width: iw - dx, height: ih - dy } }); break;
                case 'tr': onUpdateZone({ ...project.zones!.find(z => z.id === draggingState.zoneId)!, rect: { ...initialZoneRect.current!, y: iy + dy, width: iw + dx, height: ih - dy } }); break;
                case 'bl': onUpdateZone({ ...project.zones!.find(z => z.id === draggingState.zoneId)!, rect: { ...initialZoneRect.current!, x: ix + dx, width: iw - dx, height: ih + dy } }); break;
                case 'br': onUpdateZone({ ...project.zones!.find(z => z.id === draggingState.zoneId)!, rect: { ...initialZoneRect.current!, width: iw + dx, height: ih + dy } }); break;
            }
        }
    }, [getCanvasCoords, linkingState, draggingState, view.zoom, selectedIds, onUpdateNodes, onUpdateZone, setView, project.zones]);

    const handleMouseUp = useCallback(() => {
        setDraggingState(null);
        setLinkingState(null);
        if (canvasRef.current) canvasRef.current.style.cursor = 'grab';
    }, []);

    const handleWheel = useCallback((e: React.WheelEvent) => {
        e.preventDefault();
        const rect = canvasRef.current!.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;
        const newZoom = Math.max(0.2, Math.min(2, view.zoom - e.deltaY * 0.001));
        const zoomFactor = newZoom / view.zoom;
        setView({
            zoom: newZoom,
            x: mouseX - (mouseX - view.x) * zoomFactor,
            y: mouseY - (mouseY - view.y) * zoomFactor,
        });
    }, [view.x, view.y, view.zoom, setView]);

    const handleNodeMouseDown = (e: React.MouseEvent, nodeId: string) => {
        e.stopPropagation();
        dragStartPos.current = { clientX: e.clientX, clientY: e.clientY };
        setDraggingState({ type: 'draggingNodes' });
        const initialPosMap = new Map<string, { x: number, y: number }>();
        selectedIds.forEach(id => {
            const node = nodesById[id];
            if (node) initialPosMap.set(id, node.position);
        });
        initialPositions.current = initialPosMap;
    };

    const handleNodeClick = (e: React.MouseEvent, nodeId: string) => {
        e.stopPropagation();
        if (e.ctrlKey || e.metaKey) {
            onSelectNodes(selectedIds.includes(nodeId) ? selectedIds.filter(id => id !== nodeId) : [...selectedIds, nodeId]);
        } else {
            onSelectNodes([nodeId]);
        }
    };
    
    const handlePortMouseDown = (e: React.MouseEvent, nodeId: string, port: Port, isInput: boolean) => {
        e.stopPropagation();
        if (isInput) return;
        const node = nodesById[nodeId];
        if (!node) return;
        const fromPos = getPortPosition(node, port.id, false);
        const toMouse = getCanvasCoords(e.clientX, e.clientY);
        setLinkingState({ fromNodeId: nodeId, fromPort: port, fromPos, toMouse });
    };

    const handlePortMouseUp = (e: React.MouseEvent, nodeId: string, port: Port, isInput: boolean) => {
        e.stopPropagation();
        if (linkingState && isInput && linkingState.fromNodeId !== nodeId) {
            const newConnection: Connection = {
                id: `conn_${Date.now()}`,
                fromNodeId: linkingState.fromNodeId,
                fromPortId: linkingState.fromPort.id,
                toNodeId: nodeId,
                toPortId: port.id,
            };
            onUpdateProject({
                ...project,
                nodeGraph: {
                    ...project.nodeGraph,
                    connections: [...project.nodeGraph.connections, newConnection],
                },
            });
        }
        setLinkingState(null);
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        const data = e.dataTransfer.getData('application/json');
        if (!data) return;
        
        const { x, y } = getCanvasCoords(e.clientX, e.clientY);
        
        try {
            const droppedItem = JSON.parse(data);
            if (droppedItem.type === 'newNode') {
                onAddNode(droppedItem.nodeType, {x, y}, droppedItem.icon);
            } else {
                const nodeType = NODE_LIBRARY.find(n => n.category === droppedItem.type) || NODE_LIBRARY[0];
                onAddNode(nodeType.type, {x, y}, nodeType.icon, droppedItem as MediaAsset);
            }
        } catch (error) {
            console.error("Failed to parse dropped data:", error);
        }
    };

    return (
        <div 
            ref={canvasRef}
            className="w-full h-full overflow-hidden bg-[var(--bg-secondary)] cursor-grab active:cursor-grabbing"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onWheel={handleWheel}
            onContextMenu={e => { 
                e.preventDefault(); 
                const {x, y} = getCanvasCoords(e.clientX, e.clientY);
                setContextMenu({ type: 'canvas', x: e.clientX, y: e.clientY, canvasX: x, canvasY: y });
            }}
            onDrop={handleDrop}
            onDragOver={e => e.preventDefault()}
        >
            <div className="w-full h-full" style={{ transform: `translate(${view.x}px, ${view.y}px) scale(${view.zoom})`, transformOrigin: 'top left' }}>
                {(project.zones || []).map(zone => (
                    <ZoneComponent 
                        key={zone.id}
                        zone={zone}
                        isSelected={selectedZoneId === zone.id}
                        onSelect={e => { e.stopPropagation(); onSelectZone(zone.id); }}
                        onDragStart={(e, offset) => {
                            e.stopPropagation();
                            dragStartPos.current = { clientX: e.clientX, clientY: e.clientY };
                            initialZoneRect.current = zone.rect;
                            setDraggingState({ type: 'draggingZone', zoneId: zone.id });
                        }}
                        onResizeStart={(e, handle) => {
                            e.stopPropagation();
                            dragStartPos.current = { clientX: e.clientX, clientY: e.clientY };
                            initialZoneRect.current = zone.rect;
                            setDraggingState({ type: 'resizingZone', zoneId: zone.id, handle });
                        }}
                        onContextMenu={e => {
                            e.preventDefault();
                            e.stopPropagation();
                            setContextMenu({ type: 'zone', x: e.clientX, y: e.clientY, zoneId: zone.id });
                        }}
                    />
                ))}

                <svg className="absolute top-0 left-0 w-full h-full pointer-events-none" style={{ overflow: 'visible' }}>
                    {project.nodeGraph.connections.map(conn => {
                        const fromNode = nodesById[conn.fromNodeId];
                        const toNode = nodesById[conn.toNodeId];
                        if (!fromNode || !toNode) return null;
                        
                        const start = getPortPosition(fromNode, conn.fromPortId, false);
                        const end = getPortPosition(toNode, conn.toPortId, true);
                        
                        return <path key={conn.id} d={getCurvePath(start.x, start.y, end.x, end.y)} stroke="var(--text-secondary)" strokeWidth="2" fill="none" />;
                    })}
                    {linkingState && (
                        <path 
                            d={getCurvePath(linkingState.fromPos.x, linkingState.fromPos.y, linkingState.toMouse.x, linkingState.toMouse.y)}
                            stroke="var(--color-accent-primary)"
                            strokeWidth="2"
                            fill="none"
                            strokeDasharray="5,5"
                        />
                    )}
                </svg>

                {project.nodeGraph.nodes.map(node => (
                    <Node 
                        key={node.id} 
                        node={node} 
                        isSelected={selectedIds.includes(node.id)}
                        onNodeMouseDown={handleNodeMouseDown}
                        onNodeClick={handleNodeClick}
                        onContextMenu={(e, nodeId) => {
                            e.preventDefault();
                            e.stopPropagation();
                            setContextMenu({ type: 'node', x: e.clientX, y: e.clientY, nodeId });
                        }}
                        onPortMouseDown={handlePortMouseDown}
                        onPortMouseUp={handlePortMouseUp}
                        animationState={animationState}
                        isPerformMode={isPerformMode}
                        mediaAssets={mediaAssets}
                        effectiveProbabilities={effectiveProbabilities}
                    />
                ))}
            </div>
        </div>
    );
};

export default NodeCanvas;