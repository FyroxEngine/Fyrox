import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { QuantumForgeProject, ControlElement, Zone } from '../types';
import Icon from './icons/Icon';

interface PluginManagerItemProps {
    plugin: QuantumForgeProject;
    parentProject: QuantumForgeProject;
    isSelected: boolean;
    onSelect: () => void;
    onUpdateProject: (updatedProject: QuantumForgeProject) => void;
    onDeletePlugin: () => void;
}

const PluginManagerItem: React.FC<PluginManagerItemProps> = ({ plugin, parentProject, isSelected, onSelect, onUpdateProject, onDeletePlugin }) => {
    
    const handleControlChange = (controlId: string, newValue: number) => {
        const updatedProject = JSON.parse(JSON.stringify(parentProject));
        const pluginInstance = updatedProject.plugins.find((p: QuantumForgeProject) => p.id === plugin.id);
        if(!pluginInstance || !pluginInstance.controls) return;
        
        const control = pluginInstance.controls.find((c: ControlElement) => c.id === controlId);
        if (!control) return;

        control.value = Math.max(0, Math.min(1, newValue));
        
        const targetNode = updatedProject.nodeGraph.nodes.find((n: any) => n.id === control.targetNodeId);
        if (targetNode) {
            if (!targetNode.attributes) targetNode.attributes = {};
            targetNode.attributes[control.targetAttribute] = control.value;
            updatedProject.lastUpdatedNodeId = targetNode.id;
            updatedProject.lastUpdateTime = Date.now();
        }

        onUpdateProject(updatedProject);
    };

    const handleDelete = (e: React.MouseEvent) => {
        e.stopPropagation();
        if(window.confirm(`Are you sure you want to delete the plugin "${plugin.name}"?`)) {
            onDeletePlugin();
        }
    }
    
    const allZones = parentProject.zones || [];

    return (
        <div 
            onClick={onSelect}
            className={`p-4 rounded-lg border-2 flex flex-col gap-4 cursor-pointer transition-all duration-200 group ${isSelected ? 'border-[var(--color-accent-primary)] bg-[var(--bg-tertiary)]' : 'border-[var(--border-primary)] bg-[var(--bg-secondary)] hover:border-[var(--text-highlight)]/50'}`}
        >
            <div className="flex items-center justify-between pb-2 border-b border-[var(--border-primary)]">
                <div className="flex items-center gap-2" onClick={onSelect}>
                    <Icon name={plugin.icon} className="w-5 h-5 text-[var(--text-highlight)]" />
                    <h3 className="font-bold text-lg text-[var(--text-primary)]">{plugin.name}</h3>
                </div>
                <div className="flex items-center gap-2">
                     <button onClick={handleDelete} title="Delete Plugin" className="text-[var(--text-secondary)] hover:text-[var(--color-accent-primary)] opacity-0 group-hover:opacity-100 transition-opacity">
                        <Icon name="trash" className="w-5 h-5" />
                     </button>
                    <span className="text-xs text-[var(--text-secondary)]">I/O</span>
                    <button className={`w-10 h-5 rounded-full p-1 transition-colors ${isSelected ? 'bg-[var(--color-accent-primary)]' : 'bg-slate-600'}`}>
                        <div className={`w-3 h-3 rounded-full bg-white transition-transform ${isSelected ? 'transform translate-x-4' : ''}`}></div>
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-4 gap-4 items-center">
                 {(plugin.controls || []).map(control => (
                     <div key={control.id} className={control.type === 'fader' ? 'col-span-2' : 'col-span-1'}>
                        <Control control={control} onChange={handleControlChange} zones={allZones} />
                     </div>
                 ))}
            </div>
        </div>
    );
};

const Control: React.FC<{control: ControlElement, onChange: (id: string, value: number) => void, zones: Zone[]}> = ({ control, onChange, zones }) => {
    const knobRef = useRef<HTMLDivElement>(null);

    const isLinked = zones.some(z => z.resonanceField?.sourceId === control.id);

    const handleMouseMove = useCallback((e: MouseEvent) => {
        const currentValue = (knobRef.current as any)?.valueNow;
        onChange(control.id, currentValue - e.movementY * 0.005);
    }, [control.id, onChange]);

    const handleMouseUp = useCallback(() => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
        document.body.style.cursor = 'default';
    }, [handleMouseMove]);
    
    const handleMouseDown = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (knobRef.current) {
            (knobRef.current as any).valueNow = control.value;
        }
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
        document.body.style.cursor = 'ns-resize';
    };

    useEffect(() => {
        return () => {
             window.removeEventListener('mousemove', handleMouseMove);
             window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [handleMouseMove, handleMouseUp]);

    const label = (
        <label className="text-xs text-[var(--text-secondary)] tracking-widest uppercase flex items-center gap-1">
            {isLinked && <Icon name="infinity" className="w-3 h-3 text-[var(--text-highlight)]" title="Linked to a Resonance Field"/>}
            {control.label}
        </label>
    );

    if (control.type === 'fader') {
         return (
            <div className="w-full flex flex-col items-center gap-1 px-2">
                 <div className="self-start">{label}</div>
                 <input 
                    type="range" min="0" max="1" step="0.01"
                    value={control.value}
                    onChange={(e) => onChange(control.id, parseFloat(e.target.value))}
                    className="w-full h-2 bg-[var(--bg-primary)] rounded-full appearance-none cursor-pointer accent-[var(--color-accent-primary)]"
                />
            </div>
        )
    }

    if (control.type === 'switch') {
        return (
             <div className="flex flex-col items-center gap-1">
                <button
                    onClick={() => onChange(control.id, control.value === 1 ? 0 : 1)}
                    className={`relative w-12 h-12 rounded-lg flex items-center justify-center transition-colors ${control.value === 1 ? 'bg-[var(--color-accent-primary)]' : 'bg-[var(--bg-primary)] border-2 border-[var(--border-primary)]'}`}
                >
                    <Icon name="switch" className="w-6 h-6"/>
                </button>
                 {label}
            </div>
        )
    }

    // Default to Knob
    return (
        <div className="flex flex-col items-center gap-2">
            <div 
                ref={knobRef}
                onMouseDown={handleMouseDown}
                className="w-12 h-12 rounded-full bg-[var(--bg-primary)] border-2 border-[var(--border-primary)] flex items-center justify-center relative cursor-ns-resize select-none"
                aria-valuenow={control.value}
                aria-label={control.label}
                role="slider"
            >
                <div 
                    className="w-1 h-4 bg-[var(--text-secondary)] rounded-full absolute top-1 transition-transform"
                    style={{ transform: `rotate(${control.value * 270 - 135}deg)`, transformOrigin: 'center 20px' }}
                ></div>
                <span className="text-xs font-mono text-[var(--text-highlight)] pointer-events-none">
                    {Math.round(control.value * 100)}
                </span>
            </div>
            {label}
        </div>
    )
}

export default PluginManagerItem;