

import React, { useRef } from 'react';
import type { Blueprint, QuantumForgeProject, CellStatus } from '../types';
import Icon from './icons/Icon';
import MermaidDiagram from './MermaidDiagram';
import RoadmapDisplay from './RoadmapDisplay';

// Declaring global variables from the CDN scripts to satisfy TypeScript
declare const html2canvas: any;
declare const jspdf: any;

interface BlueprintDisplayModalProps {
    blueprint: Blueprint;
    project: QuantumForgeProject;
    onClose: () => void;
    onUpdateRoadmapCell: (layerId: string, versionKey: string, phaseKey: string, status: CellStatus) => void;
}

const BlueprintDisplayModal: React.FC<BlueprintDisplayModalProps> = ({ blueprint, project, onClose, onUpdateRoadmapCell }) => {
    const contentRef = useRef<HTMLDivElement>(null);

    const parseContent = (content: string) => {
        // This regex splits the content by mermaid and pre tags while keeping the delimiters
        const parts = content.split(/(<div class="mermaid">.*?<\/div>|<pre><code>.*?<\/code><\/pre>)/gs);
        
        return parts.map((part, index) => {
            if (!part) return null;

            if (part.startsWith('<div class="mermaid">')) {
                const chart = part.replace('<div class="mermaid">', '').replace('</div>', '');
                return <MermaidDiagram key={index} chart={chart.trim()} />;
            } 
            
            if (part.startsWith('<pre><code>')) {
                const code = part.replace('<pre><code>', '').replace('</code></pre>', '');
                return (
                    <pre key={index} className="text-xs font-mono text-cyan-200 bg-slate-900 p-4 rounded-md border border-slate-700 my-4">
                        <code>{code}</code>
                    </pre>
                );
            }
            // Regular HTML content
            return <div key={index} dangerouslySetInnerHTML={{ __html: part.replace(/(\r\n|\n|\r)/gm, '<br />') }} />;
        });
    };

    const handleExportMD = () => {
        // Strip HTML for a cleaner Markdown export
        const mdContent = `# ${blueprint.name}\n\n${blueprint.description}\n\n---\n\n${
            blueprint.content
                .replace(/<div class="mermaid">/g, '\n```mermaid\n')
                .replace(/<\/div>/g, '\n```\n')
                .replace(/<pre><code>/g, '\n```json\n')
                .replace(/<\/code><\/pre>/g, '\n```\n')
                .replace(/<h3>/g, '### ')
                .replace(/<\/h3>/g, '')
                .replace(/<h4>/g, '#### ')
                .replace(/<\/h4>/g, '')
                .replace(/<p>/g, '')
                .replace(/<\/p>/g, '\n')
                .replace(/<br \/>/g, '\n')
                .replace(/&nbsp;/g, ' ')
        }`;
        const blob = new Blob([mdContent], { type: 'text/markdown' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${blueprint.name.replace(/\s+/g, '_')}.md`;
        a.click();
        URL.revokeObjectURL(url);
    };
    
    const handleExportPDF = async () => {
        const { jsPDF } = jspdf;
        const input = contentRef.current;
        if (!input) return;

        // Temporarily change styles to render full height for capture
        const originalHeight = input.style.height;
        const originalOverflow = input.style.overflow;
        input.style.height = 'auto';
        input.style.overflow = 'visible';

        try {
            const canvas = await html2canvas(input, {
                scale: 2,
                backgroundColor: 'rgb(15, 23, 42)', // --bg-secondary
                windowWidth: input.scrollWidth,
                windowHeight: input.scrollHeight,
            });

            // Revert styles immediately after capture
            input.style.height = originalHeight;
            input.style.overflow = originalOverflow;

            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF({
                orientation: 'p',
                unit: 'px',
                format: [canvas.width, canvas.height]
            });
            pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
            pdf.save(`${blueprint.name.replace(/\s+/g, '_')}.pdf`);
        } catch (error) {
            console.error("Error generating PDF:", error);
            // Revert styles even if there's an error
            input.style.height = originalHeight;
            input.style.overflow = originalOverflow;
        }
    };
    
    const contentToRender = blueprint.id === 'bp_observer_audit'
        ? project.observerAuditLog?.slice().reverse().map(entry => {
            const node = project.nodeGraph.nodes.find(n => n.id === entry.collapsedNodeId);
            return `<div class="blueprint-section"><h4>Node Collapsed: ${node?.label || 'Unknown'}</h4><p>Time: ${new Date(entry.timestamp).toLocaleString()}</p><p>Chosen Reality: "${entry.chosenOutcome.content}"</p></div>`;
          }).join('') || '<p>No audit data available.</p>'
        : blueprint.content;

    return (
        <div 
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-8"
        >
            <div 
                onClick={e => e.stopPropagation()}
                className="bg-[var(--bg-secondary)] w-full max-w-6xl h-full max-h-[90vh] rounded-lg border border-[var(--border-primary)] flex flex-col shadow-2xl shadow-[var(--shadow-color)]"
            >
                {/* Header */}
                <div className="flex-shrink-0 px-6 py-4 border-b border-[var(--border-primary)] flex items-center justify-between">
                    <div className="flex items-center gap-4">
                         <Icon name={blueprint.icon} className="w-6 h-6 text-[var(--text-highlight)]" />
                         <div>
                            <h2 className="text-xl font-bold text-[var(--text-highlight)]">{blueprint.name}</h2>
                            <p className="text-sm text-[var(--text-secondary)]">{blueprint.description}</p>
                         </div>
                    </div>
                    <div className="flex items-center gap-2">
                        {!blueprint.roadmap && <button onClick={handleExportMD} className="button-secondary text-xs">Export to MD</button>}
                        <button onClick={handleExportPDF} className="button-primary text-xs">Export to PDF</button>
                        <button onClick={onClose} className="p-2 -mr-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-full hover:bg-[var(--bg-interactive)]">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>
                </div>

                {/* Content */}
                <div ref={contentRef} className="flex-grow p-6 overflow-y-auto blueprint-content">
                    {blueprint.roadmap ? (
                         <RoadmapDisplay
                            roadmap={blueprint.roadmap}
                            roadmapState={project.roadmapState || {}}
                            onUpdateCell={onUpdateRoadmapCell}
                        />
                    ) : (
                        parseContent(contentToRender)
                    )}
                </div>
            </div>
        </div>
    );
};

export default BlueprintDisplayModal;