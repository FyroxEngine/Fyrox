import React, { useState } from 'react';
import Icon from './icons/Icon';
import ThemeEditorPanel from './panels/ThemeEditorPanel';
import AIModelSettingsPanel from './panels/AIModelSettingsPanel';
import type { Theme, CustomThemeConfig, LLMConfig } from '../types';

interface SettingsModalProps {
    onClose: () => void;
    currentTheme: Theme;
    onSetTheme: (theme: Theme) => void;
    customConfig: CustomThemeConfig;
    onSetConfig: (config: CustomThemeConfig) => void;
    aiModels: LLMConfig[];
    onUpdateAiModels: (models: LLMConfig[]) => void;
}

type SettingsTab = 'theme' | 'ai';

const SettingsModal: React.FC<SettingsModalProps> = (props) => {
    const [activeTab, setActiveTab] = useState<SettingsTab>('theme');
    
    return (
         <div 
            onClick={props.onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        >
            <div 
                onClick={e => e.stopPropagation()}
                className="bg-[var(--bg-secondary)] w-full max-w-3xl h-full max-h-[80vh] rounded-lg border border-[var(--border-primary)] flex flex-col shadow-2xl shadow-[var(--shadow-color)]"
            >
                <div className="px-6 py-4 border-b border-[var(--border-primary)] flex items-center justify-between flex-shrink-0">
                    <div className="flex items-center gap-3">
                        <Icon name="cog" className="w-6 h-6 text-[var(--text-highlight)]" />
                        <h2 className="text-xl font-bold text-[var(--text-highlight)]">Settings</h2>
                    </div>
                    <button onClick={props.onClose} className="p-2 -mr-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-full hover:bg-[var(--bg-interactive)]">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>

                <div className="flex flex-grow overflow-hidden">
                    <div className="w-48 border-r border-[var(--border-primary)] p-2 space-y-1">
                       <TabButton active={activeTab === 'theme'} onClick={() => setActiveTab('theme')} icon="palette" label="Theme" />
                       <TabButton active={activeTab === 'ai'} onClick={() => setActiveTab('ai')} icon="cpu" label="AI Models" />
                    </div>
                    <div className="flex-grow overflow-y-auto">
                        {activeTab === 'theme' && (
                            <ThemeEditorPanel 
                                currentTheme={props.currentTheme}
                                onSetTheme={props.onSetTheme}
                                customConfig={props.customConfig}
                                onSetConfig={props.onSetConfig}
                            />
                        )}
                        {activeTab === 'ai' && (
                            <AIModelSettingsPanel models={props.aiModels} onUpdate={props.onUpdateAiModels}/>
                        )}
                    </div>
                </div>
            </div>
        </div>
    )
}

const TabButton: React.FC<{active: boolean, onClick: () => void, icon: any, label: string}> = ({ active, onClick, icon, label}) => (
    <button 
        onClick={onClick}
        className={`w-full flex items-center gap-2 p-2 rounded-md text-sm text-left ${active ? 'bg-[var(--color-accent-primary)]/20 text-[var(--text-primary)]' : 'text-[var(--text-secondary)] hover:bg-[var(--bg-interactive)]'}`}
    >
        <Icon name={icon} className="w-5 h-5" />
        <span>{label}</span>
    </button>
)

export default SettingsModal;