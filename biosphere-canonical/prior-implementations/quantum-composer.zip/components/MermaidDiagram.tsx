import React, { useEffect, useRef } from 'react';

declare const mermaid: any;

interface MermaidDiagramProps {
    chart: string;
}

const MermaidDiagram: React.FC<MermaidDiagramProps> = ({ chart }) => {
    const ref = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (ref.current) {
            ref.current.innerHTML = chart;
            try {
                mermaid.run({ nodes: [ref.current] });
            } catch (e) {
                console.error("Mermaid rendering error:", e);
                if (ref.current) {
                    ref.current.innerHTML = `Error rendering diagram. Check console.`;
                }
            }
        }
    }, [chart]);

    return <div ref={ref} className="mermaid flex justify-center my-4" />;
};

export default MermaidDiagram;
