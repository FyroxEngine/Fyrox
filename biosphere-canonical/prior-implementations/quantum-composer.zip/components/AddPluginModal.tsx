

import React, { useState } from 'react';
import Icon from './icons/Icon';
import type { IconName } from '../types';

interface AddPluginModalProps {
    onClose: () => void;
    onAdd: (name: string, icon: IconName, description: string) => void;
}

const ICONS: IconName[] = ['synth', 'sampler', 'fx', 'mixer', 'sequencer', 'visualizer', 'persona', 'puzzle-piece'];

const AddPluginModal: React.FC<AddPluginModalProps> = ({ onClose, onAdd }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [selectedIcon, setSelectedIcon] = useState<IconName>('puzzle-piece');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!name.trim()) return;
        onAdd(name, selectedIcon, description);
    };

    return (
        <div onClick={onClose} className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div onClick={e => e.stopPropagation()} className="bg-[var(--bg-secondary)] w-full max-w-md rounded-lg border border-[var(--border-primary)] flex flex-col shadow-2xl shadow-[var(--shadow-color)]">
                <div className="px-6 py-4 border-b border-[var(--border-primary)] flex items-center justify-between">
                    <h2 className="text-xl font-bold text-[var(--text-highlight)]">Add New Plugin</h2>
                    <button onClick={onClose} className="p-2 -mr-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-full hover:bg-[var(--bg-interactive)]">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-bold text-[var(--text-secondary)] mb-1">Plugin Name</label>
                        <input type="text" value={name} onChange={e => setName(e.target.value)} required className="w-full bg-[var(--bg-primary)] p-2 rounded-md border border-[var(--border-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent-primary)]" />
                    </div>
                    <div>
                        <label className="block text-sm font-bold text-[var(--text-secondary)] mb-1">Description</label>
                        <textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} className="w-full bg-[var(--bg-primary)] p-2 rounded-md border border-[var(--border-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent-primary)]" />
                    </div>
                     <div>
                        <label className="block text-sm font-bold text-[var(--text-secondary)] mb-2">Icon</label>
                        <div className="flex flex-wrap gap-2">
                            {ICONS.map(icon => (
                                <button key={icon} type="button" onClick={() => setSelectedIcon(icon)} className={`p-2 rounded-md border-2 transition-colors ${selectedIcon === icon ? 'border-[var(--color-accent-primary)] bg-[var(--color-accent-primary)]/20' : 'border-transparent bg-[var(--bg-interactive)]'}`}>
                                    <Icon name={icon} className="w-6 h-6" />
                                </button>
                            ))}
                        </div>
                    </div>
                    <div className="flex justify-end gap-3 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 rounded-md bg-[var(--bg-interactive)] hover:bg-[var(--bg-tertiary)] transition-colors">Cancel</button>
                        <button type="submit" className="px-4 py-2 rounded-md bg-[var(--color-accent-primary)] hover:bg-[var(--color-accent-primary-hover)] text-white font-bold transition-colors">Add Plugin</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddPluginModal;