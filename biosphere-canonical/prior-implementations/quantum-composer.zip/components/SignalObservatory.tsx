import React, { useState, useCallback } from 'react';
import type { QuantumForgeProject } from '../types';
import Icon from './icons/Icon';
import { generateProjectInsights } from '../services/geminiService';

interface SignalObservatoryProps {
    project: QuantumForgeProject;
}

const SignalObservatory: React.FC<SignalObservatoryProps> = ({ project }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [insights, setInsights] = useState<string[]>([]);
    const [error, setError] = useState<string | null>(null);

    const handleGenerateInsights = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        setInsights([]);
        try {
            const result = await generateProjectInsights(project);
            setInsights(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [project]);

    return (
        <div className="w-full h-full bg-[var(--bg-tertiary)]/50 rounded-lg border border-[var(--border-primary)] overflow-hidden relative p-6 flex flex-col items-center">
            <Icon name="telescope" className="w-24 h-24 text-[var(--text-highlight)] opacity-20" />
            <h2 className="text-3xl font-bold mt-4 text-[var(--text-highlight)]">Signal Observatory</h2>
            <p className="text-[var(--text-secondary)] mt-2 mb-6 text-center max-w-lg">
                Analyze your project's structure, themes, and connections to uncover creative insights and potential next steps.
            </p>

            <button
                onClick={handleGenerateInsights}
                disabled={isLoading}
                className="flex items-center gap-3 px-6 py-3 rounded-lg bg-[var(--color-accent-primary)] hover:bg-[var(--color-accent-primary-hover)] text-white font-bold transition-all disabled:opacity-50 disabled:cursor-wait"
            >
                {isLoading ? (
                    <>
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Analyzing...
                    </>
                ) : (
                   <>
                     <Icon name="sparkles" className="w-5 h-5" />
                     Generate Insights
                   </>
                )}
            </button>

            <div className="mt-8 w-full max-w-2xl">
                {error && (
                    <div className="p-4 bg-red-900/50 border border-red-500/50 rounded-lg text-red-300">
                        <h4 className="font-bold">Error</h4>
                        <p>{error}</p>
                    </div>
                )}
                {insights.length > 0 && (
                     <div className="space-y-3">
                        <h3 className="text-xl font-bold text-[var(--text-highlight)]">Analysis Results:</h3>
                        {insights.map((insight, index) => (
                             <div key={index} className="p-4 bg-[var(--bg-secondary)] border border-[var(--border-primary)] rounded-md text-[var(--text-secondary)]">
                                <p>{insight}</p>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default SignalObservatory;