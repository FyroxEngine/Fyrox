import React, { useState, useRef, useCallback, useEffect } from 'react';
import type { QuantumForgeProject, GestureInput, RitualTriggerType, QuantumForgeNode } from '../types';
import Icon from './icons/Icon';
import { FusionPulseAnimator } from '../../services/FusionPulseAnimator';


type RecordingState = 'idle' | 'recording' | 'paused';
interface QuantumQuillCanvasProps {
    project: QuantumForgeProject;
    onGesture: (gesture: GestureInput) => void;
    recordingState: RecordingState;
    onStartRecording: () => void;
    onStopRecording: () => void;
    suggestion: string;
    onGetSuggestion: () => void;
    onCollapseNode: (nodeId: string) => void;
    nodes: QuantumForgeNode[];
    lastGesture: GestureInput | null;
    selectedNodeIds: string[];
}

const QuantumQuillCanvas: React.FC<QuantumQuillCanvasProps> = ({ 
    project, onGesture, recordingState, onStartRecording, onStopRecording, 
    suggestion, onGetSuggestion, onCollapseNode, nodes, lastGesture, 
    selectedNodeIds
}) => {
    const gesturePadRef = useRef<HTMLDivElement>(null);
    const [driftIntensity, setDriftIntensity] = useState(0.5);
    const [blinkingShellId, setBlinkingShellId] = useState<string | null>(null);

    const linkedShells = project.linkedShells || [];
    const ritualLinks = project.ritualLinks || [];

    const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        if (gesturePadRef.current) {
            const rect = gesturePadRef.current.getBoundingClientRect();
            const x = (e.clientX - rect.left) / rect.width;
            const y = (e.clientY - rect.top) / rect.height;
            
            const gesture: GestureInput = {
                x: Math.max(0, Math.min(1, x)),
                y: Math.max(0, Math.min(1, y)),
                type: 'move',
            };
            onGesture(gesture);
            
            const activeRitual = ritualLinks.find(r => r.enabled && r.triggerType === 'gesture');
            if (activeRitual && activeRitual.targetShellIds.length > 0) {
                // For simplicity, we'll just blink the first target shell
                setBlinkingShellId(activeRitual.targetShellIds[0]);
            }
        }
    }, [onGesture, ritualLinks]);

    useEffect(() => {
        if (blinkingShellId) {
            const timer = setTimeout(() => setBlinkingShellId(null), 500); // Blink for 500ms
            return () => clearTimeout(timer);
        }
    }, [blinkingShellId]);
    
    const RecorderControls = () => {
        if (recordingState === 'recording') {
            return (
                 <button onClick={onStopRecording} className="w-full flex items-center justify-center gap-2 p-2 bg-red-600/80 hover:bg-red-500/80 rounded-md text-white font-bold transition-colors">
                    <Icon name="stop-circle" className="w-5 h-5" />
                    <span>Stop</span>
                </button>
            )
        }
        return (
            <button onClick={onStartRecording} className="w-full flex items-center justify-center gap-2 p-2 bg-[var(--bg-primary)] hover:bg-[var(--bg-interactive)] rounded-md text-[var(--text-secondary)] hover:text-white transition-colors">
                <Icon name="record" className="w-5 h-5 text-red-500" />
                <span>Record</span>
            </button>
        )
    }

    const handleCollapse = () => {
        // Prioritize collapsing the single selected node
        if (selectedNodeIds.length === 1) {
            onCollapseNode(selectedNodeIds[0]);
            return;
        }

        // Fallback to gesture-based collapse
        if (lastGesture) {
            const nearestNode = FusionPulseAnimator.findNearestNode(lastGesture, nodes);
            if (nearestNode) {
                onCollapseNode(nearestNode.id);
            }
        }
    };

    return (
        <div className="absolute inset-0 flex items-end justify-center pointer-events-none p-4">
             <div className="bg-[var(--bg-tertiary)]/70 backdrop-blur-md border-2 border-[var(--border-primary)] rounded-lg shadow-2xl shadow-[var(--shadow-color)] p-4 flex items-center gap-6 pointer-events-auto">
                <div 
                    ref={gesturePadRef}
                    onMouseMove={handleMouseMove}
                    className="w-64 h-64 bg-[var(--bg-primary)] rounded-lg border border-[var(--border-primary)] flex items-center justify-center text-center cursor-crosshair overflow-hidden relative"
                >
                    <Icon name="quill" className="w-16 h-16 text-[var(--text-highlight)] opacity-10" />
                    <p className="absolute text-xs text-[var(--text-secondary)]">Gesture Pad</p>
                </div>
                 <div className="flex flex-col gap-4 w-48">
                    <button 
                        onClick={handleCollapse} 
                        className="button-primary flex items-center justify-center gap-2" 
                        title="Collapse the selected node, or the node nearest your last gesture if none is selected."
                    >
                        <Icon name="git-branch" className="w-5 h-5" /> Collapse Node
                    </button>

                    <div className="text-center">
                        <label className="text-xs font-bold text-[var(--text-secondary)] tracking-wider">RECORDER</label>
                         <div className="relative mt-1">
                            {recordingState === 'recording' && (
                                <div className="absolute top-2 -right-1 w-2 h-2 rounded-full bg-red-500 animate-ping"></div>
                            )}
                            <RecorderControls />
                         </div>
                    </div>
                    
                    <div className="p-2 bg-black/20 rounded-md text-center">
                        <p className="text-xs text-center text-slate-400 italic h-10">{suggestion || 'Get a suggestion...'}</p>
                        <button onClick={onGetSuggestion} className="button-secondary w-full text-xs mt-2">
                          <Icon name="sparkles" className="w-4 h-4" /> Get Suggestion
                        </button>
                    </div>

                    <div className="text-center">
                        <label className="text-xs font-bold text-[var(--text-secondary)] tracking-wider">DRIFT</label>
                        <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.01"
                            value={driftIntensity}
                            onChange={(e) => setDriftIntensity(parseFloat(e.target.value))}
                            className="w-full h-2 bg-[var(--bg-primary)] rounded-full appearance-none cursor-pointer accent-[var(--color-accent-primary)] mt-1"
                        />
                         <span className="text-xs text-[var(--text-secondary)]">{Math.round(driftIntensity * 100)}%</span>
                    </div>
                </div>
                <div className="w-48 self-start">
                     <h4 className="text-xs font-bold text-center text-[var(--text-secondary)] tracking-wider mb-2">SHARED PERFORMANCE</h4>
                     <div className="h-56 overflow-y-auto space-y-1 bg-black/20 p-2 rounded-md">
                        {linkedShells.map(shell => (
                             <div key={shell.id} className={`flex items-center gap-2 p-1 rounded-md text-sm transition-colors ${blinkingShellId === shell.id ? 'bg-green-500/40' : ''}`}>
                                <span className={`w-2 h-2 rounded-full ${shell.status === 'online' ? 'bg-green-400' : 'bg-slate-500'}`}></span>
                                <span className="text-[var(--text-secondary)] truncate">{shell.name}</span>
                             </div>
                        ))}
                         {linkedShells.length === 0 && <p className="text-xs text-center text-[var(--text-secondary)]/50 pt-4">No linked shells</p>}
                     </div>
                </div>
            </div>
        </div>
    );
};

export default QuantumQuillCanvas;
