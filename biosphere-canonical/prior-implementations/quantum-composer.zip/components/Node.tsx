import React, { useState, useEffect } from 'react';
import type { QuantumForgeNode, Port, MediaAsset, AnimationState, QuantumOutcome } from '../types';
import Icon from './icons/Icon';
import { VISUAL_EFFECT_MANIFEST } from '../../constants';

interface NodeProps {
    node: QuantumForgeNode;
    isSelected: boolean;
    onNodeMouseDown: (e: React.MouseEvent, nodeId: string) => void;
    onNodeClick: (e: React.MouseEvent, nodeId: string) => void;
    onContextMenu: (e: React.MouseEvent, nodeId: string) => void;
    onPortMouseDown: (e: React.MouseEvent, nodeId: string, port: Port, isInput: boolean) => void;
    onPortMouseUp: (e: React.MouseEvent, nodeId: string, port: Port, isInput: boolean) => void;
    animationState: AnimationState;
    isPerformMode: boolean;
    mediaAssets: MediaAsset[];
    effectiveProbabilities: Map<string, QuantumOutcome[]>;
}

const Node: React.FC<NodeProps> = ({ 
    node, isSelected, onNodeMouseDown, onNodeClick, onContextMenu, 
    onPortMouseDown, onPortMouseUp, animationState, isPerformMode, 
    mediaAssets, effectiveProbabilities 
}) => {
    const isPulsing = animationState.pulses.some(p => p.targetId === node.id && p.type === 'trait-pulse');
    const isPortGlowing = animationState.pulses.some(p => p.targetId === node.id && p.type === 'port-glow');
    
    const { collapsed } = node.quantumState;
    const outcomes = effectiveProbabilities.get(node.id) || node.quantumState.outcomes;

    const categoryColor = VISUAL_EFFECT_MANIFEST.categoryColors[node.category || 'default'];

    const nodeStyle: React.CSSProperties = {
        top: node.position.y,
        left: node.position.x,
        width: '180px',
        minHeight: '120px',
    };

    const renderNodeContent = () => {
        if (node.type === 'media-player' && node.mediaAssetId) {
            const media = mediaAssets.find(m => m.id === node.mediaAssetId);
            if (media && media.type === 'image') {
                return (
                    <div className="p-1">
                        <img src={media.path} alt={media.name} className="w-full h-auto rounded-sm object-cover" />
                    </div>
                );
            }
        }
        
        if (collapsed) {
             const contentToShow = outcomes[0]?.content || '...';
             return (
                <div className="text-xs p-2 text-center text-[var(--text-secondary)] min-h-[24px]">
                     <p className="truncate">{contentToShow}</p>
                </div>
            )
        }

        // Dynamic Outcome Preview for uncollapsed nodes
        const sortedOutcomes = [...outcomes].sort((a, b) => b.probability - a.probability);

        return (
             <div className="text-xs p-2 text-left text-[var(--text-secondary)] space-y-1 min-h-[24px]">
                 {sortedOutcomes.map((outcome, index) => (
                    <p 
                        key={index} 
                        className="truncate transition-all duration-300"
                        style={{
                            opacity: 0.4 + (outcome.probability * 0.6),
                            fontWeight: index === 0 ? 'bold' : 'normal',
                            color: index === 0 ? 'var(--text-primary)' : 'var(--text-secondary)',
                        }}
                    >
                       {outcome.content}
                    </p>
                 ))}
            </div>
        )
    }

    return (
        <div
            onClick={(e) => onNodeClick(e, node.id)}
            onContextMenu={(e) => onContextMenu(e, node.id)}
            className={`absolute border-2 rounded-lg shadow-lg bg-[var(--bg-tertiary)]/80 backdrop-blur-sm transition-all duration-100 flex flex-col
                ${isSelected ? 'border-[var(--color-accent-primary)] shadow-[var(--color-accent-primary)]/30' : 'border-[var(--border-primary)]'}
                ${!collapsed ? 'quantum-shimmer' : ''}
            `}
            style={nodeStyle}
        >
            {isPerformMode && isPulsing && (
                 <div className="absolute -inset-2 rounded-full border-2 border-[var(--color-accent-primary)] trait-pulse-ring pointer-events-none" />
            )}
            
            {/* Node Header */}
            <div 
                className="p-2 flex items-center gap-2 rounded-t-md border-b border-[var(--border-primary)]/50 cursor-move"
                onMouseDown={(e) => onNodeMouseDown(e, node.id)}
            >
                {node.icon && <Icon name={node.icon} className="w-4 h-4 flex-shrink-0" style={{ color: categoryColor }}/>}
                <h3 className="text-sm font-bold text-[var(--text-primary)] truncate pointer-events-none">{node.label}</h3>
                {node.aiConfig?.promptTemplate && (
                     <Icon name="sparkles" className="w-4 h-4 text-yellow-400 ml-auto flex-shrink-0" title="AI Enabled"/>
                )}
            </div>
            
            {/* Body/Content Area */}
            <div className="flex-grow">
                {renderNodeContent()}
            </div>
            
            {/* Ports */}
            {node.inputs.map((port, index) => {
                const top = 60 + index * 20;
                return (
                    <div 
                        key={port.id}
                        onMouseDown={(e) => onPortMouseDown(e, node.id, port, true)}
                        onMouseUp={(e) => onPortMouseUp(e, node.id, port, true)}
                        className="absolute w-4 h-4 -left-2 flex items-center justify-center cursor-crosshair"
                        style={{ top: `${top}px` }}
                        title={`${port.name} (${port.type})`}
                    >
                        <div className={`w-3 h-3 rounded-full border-2 border-[var(--bg-secondary)] hover:bg-[var(--text-highlight)] transition-colors ${isPortGlowing ? 'port-glow' : 'bg-slate-500'}`}/>
                    </div>
                );
            })}

            {node.outputs.map((port, index) => {
                const top = 60 + index * 20;
                return (
                    <div
                        key={port.id}
                        onMouseDown={(e) => onPortMouseDown(e, node.id, port, false)}
                        onMouseUp={(e) => onPortMouseUp(e, node.id, port, false)}
                        className="absolute w-4 h-4 -right-2 flex items-center justify-center cursor-crosshair"
                        style={{ top: `${top}px` }}
                        title={`${port.name} (${port.type})`}
                    >
                         <div className="w-3 h-3 bg-slate-400 rounded-full border-2 border-[var(--bg-secondary)] hover:bg-[var(--text-highlight)] transition-colors"/>
                    </div>
                );
            })}
        </div>
    );
};

export default React.memo(Node);