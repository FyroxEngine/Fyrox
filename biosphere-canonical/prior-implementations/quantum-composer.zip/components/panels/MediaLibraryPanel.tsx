
import React, { useRef } from 'react';
import type { MediaAsset } from '../../types';
import Icon from '../icons/Icon';

interface MediaLibraryPanelProps {
  mediaAssets: MediaAsset[];
  onAddAsset: (asset: MediaAsset) => void;
}

const MediaLibraryPanel: React.FC<MediaLibraryPanelProps> = ({ mediaAssets, onAddAsset }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const handleDragStart = (e: React.DragEvent, mediaAsset: MediaAsset) => {
    e.dataTransfer.setData('application/json', JSON.stringify(mediaAsset));
  };

  const getAssetType = (fileName: string): MediaAsset['type'] => {
      const ext = fileName.split('.').pop()?.toLowerCase() || '';
      if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(ext)) return 'image';
      if (['mp3', 'wav', 'ogg', 'flac'].includes(ext)) return 'audio';
      if (['mp4', 'webm', 'mov'].includes(ext)) return 'video';
      if (['glb', 'gltf'].includes(ext)) return 'model';
      return 'document';
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
              const newAsset: MediaAsset = {
                  id: `media_${Date.now()}`,
                  name: file.name,
                  type: getAssetType(file.name),
                  path: event.target?.result as string,
                  tags: ['uploaded'],
              };
              onAddAsset(newAsset);
          };
          reader.readAsDataURL(file);
      }
  };

  const handleAddByUrl = () => {
      const url = window.prompt("Enter the URL of the media asset:");
      if (url) {
          const name = url.substring(url.lastIndexOf('/') + 1);
          const newAsset: MediaAsset = {
              id: `media_${Date.now()}`,
              name: name || 'New Web Asset',
              type: getAssetType(name),
              path: url,
              tags: ['web'],
          };
          onAddAsset(newAsset);
      }
  };

  return (
    <div className="h-full flex flex-col">
      <h3 className="panel-header text-lg mb-2 text-[var(--text-highlight)]">Media Library</h3>
      <p className="text-sm text-[var(--text-secondary)] mt-1 mb-4">Drag media onto the canvas to create nodes.</p>
      
      <div className="flex gap-2 mb-4">
          <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" />
          <button onClick={() => fileInputRef.current?.click()} className="button-secondary w-full text-sm">Upload File</button>
          <button onClick={handleAddByUrl} className="button-secondary w-full text-sm">Add by URL</button>
      </div>

      <div className="space-y-3 flex-grow overflow-y-auto pr-2">
        {mediaAssets.map(asset => (
          <div
            key={asset.id}
            draggable
            onDragStart={e => handleDragStart(e, asset)}
            className="p-2 rounded-md bg-[var(--bg-interactive)] flex items-center gap-3 cursor-grab"
          >
            {asset.type === 'image' ? (
                <img src={asset.path} alt={asset.name} className="w-12 h-12 object-cover rounded-md flex-shrink-0" />
            ) : (
                <div className="w-12 h-12 flex items-center justify-center bg-[var(--bg-secondary)] rounded-md flex-shrink-0">
                    <Icon name={asset.type === 'video' ? 'video' : asset.type === 'audio' ? 'audio' : asset.type === 'model' ? 'cubes' : 'document-text'} className="w-6 h-6 text-[var(--text-secondary)]" />
                </div>
            )}
            
            <div className="overflow-hidden">
              <p className="font-bold text-sm text-[var(--text-primary)] truncate">{asset.name}</p>
              <div className="flex flex-wrap gap-1 mt-1">
                {asset.tags.map(tag => (
                  <span key={tag} className="px-1.5 py-0.5 text-xs bg-[var(--bg-secondary)] rounded-full text-[var(--text-secondary)]">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
        {mediaAssets.length === 0 && (
            <div className="text-center text-[var(--text-secondary)] py-8">
                <p>No media assets found.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default MediaLibraryPanel;
