import React from 'react';
import type { IconName, QuantumForgeProject } from '../../types';
import Icon from '../icons/Icon';
import { NODE_LIBRARY } from '../../constants';

interface ExplorerPanelProps {
    project: QuantumForgeProject;
    onUpdateProject: (project: QuantumForgeProject) => void;
}

const ExplorerPanel: React.FC<ExplorerPanelProps> = ({ project, onUpdateProject }) => {
    
    const projectItems = [
        { id: 'nodes', name: 'Nodes', icon: 'diagram', count: project.nodeGraph.nodes.length },
        { id: 'zones', name: 'Zones', icon: 'layers', count: project.zones?.length || 0 },
        { id: 'plugins', name: 'Plugins', icon: 'puzzle-piece', count: project.plugins?.length || 0 },
    ];

    return (
        <div className="flex flex-col h-full">
            <div className="pb-4">
                <h3 className="panel-header text-lg mb-2 text-[var(--text-highlight)]">Node Library</h3>
                 <div className="space-y-2">
                    {NODE_LIBRARY.map(node => (
                        <button 
                            key={node.type}
                            draggable
                            onDragStart={(e) => {
                                e.dataTransfer.setData('application/json', JSON.stringify({type: 'newNode', nodeType: node.type, icon: node.icon}));
                            }}
                            className="w-full text-left p-2 rounded-md bg-[var(--bg-interactive)] hover:bg-[var(--color-accent-primary)]/80 flex items-center gap-3 transition-colors cursor-grab"
                        >
                            <Icon name={node.icon} className="w-5 h-5 flex-shrink-0" />
                            <span className="font-bold">{node.name}</span>
                        </button>
                    ))}
                </div>
            </div>

            <div className="mt-4 pt-4 border-t border-[var(--border-primary)] flex-grow">
                <h3 className="panel-header text-lg mb-4 text-[var(--text-highlight)]">Project Explorer</h3>
                <div className="space-y-1">
                    {projectItems.map(item => (
                        <div key={item.id} className="flex items-center justify-between p-2 rounded-md hover:bg-[var(--bg-interactive)]">
                            <div className="flex items-center gap-2 text-sm">
                                <Icon name={item.icon as IconName} className="w-4 h-4 text-[var(--text-secondary)]"/>
                                <span className="text-[var(--text-primary)]">{item.name}</span>
                            </div>
                            <span className="text-xs px-2 py-0.5 rounded-full bg-[var(--bg-primary)] text-[var(--text-secondary)]">{item.count}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ExplorerPanel;