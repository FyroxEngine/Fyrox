import React, { useState } from 'react';
import type { QuantumForgeProject, Trait, SymbolGlyph, IconName } from '../../types';
import Icon from '../icons/Icon';

interface TraitRegistryPanelProps {
    project: QuantumForgeProject;
    onUpdateProject: (project: QuantumForgeProject) => void;
}

type ActiveTab = 'traits' | 'symbols';

const LORE_ICONS: IconName[] = ['dna', 'sparkles', 'brain-circuit', 'atom', 'remix', 'infinity', 'theater', 'quill', 'tag'];

const TraitRegistryPanel: React.FC<TraitRegistryPanelProps> = ({ project, onUpdateProject }) => {
    const [activeTab, setActiveTab] = useState<ActiveTab>('traits');

    return (
        <div className="flex flex-col h-full text-sm">
            <h3 className="panel-header text-lg mb-4 text-[var(--text-highlight)] flex items-center gap-2">
                <Icon name="dna" className="w-5 h-5"/>
                Lore Manager
            </h3>
            
            <div className="flex border-b border-[var(--border-primary)] mb-4">
                <TabButton name="Traits" icon="dna" active={activeTab === 'traits'} onClick={() => setActiveTab('traits')} />
                <TabButton name="Symbols" icon="tag" active={activeTab === 'symbols'} onClick={() => setActiveTab('symbols')} />
            </div>

            <div className="flex-grow overflow-y-auto pr-2">
                {activeTab === 'traits' && <TraitsManager project={project} onUpdateProject={onUpdateProject} />}
                {activeTab === 'symbols' && <SymbolsManager project={project} onUpdateProject={onUpdateProject} />}
            </div>
        </div>
    );
};

const TabButton: React.FC<{name: string, icon: IconName, active: boolean, onClick: ()=>void}> = ({name, icon, active, onClick}) => (
    <button 
        onClick={onClick}
        className={`flex items-center gap-2 px-4 py-2 border-b-2 text-sm font-bold transition-colors -mb-px ${active ? 'border-[var(--color-accent-primary)] text-[var(--color-accent-primary)]' : 'border-transparent text-[var(--text-secondary)] hover:text-[var(--text-primary)]'}`}
    >
        <Icon name={icon} className="w-5 h-5"/>
        {name}
    </button>
);

const TraitsManager: React.FC<TraitRegistryPanelProps> = ({ project, onUpdateProject }) => {
    const [editingTrait, setEditingTrait] = useState<Partial<Trait> | null>(null);

    const handleSave = () => {
        if (!editingTrait || !editingTrait.name) return;
        const traits = project.traitRegistry.traits || [];
        const updatedTraits = editingTrait.id
            ? traits.map(t => t.id === editingTrait.id ? { ...t, ...editingTrait } as Trait : t)
            : [...traits, { ...editingTrait, id: `trait_${Date.now()}` } as Trait];
        
        onUpdateProject({ ...project, traitRegistry: { ...project.traitRegistry, traits: updatedTraits } });
        setEditingTrait(null);
    };

    const handleDelete = (id: string) => {
        const traits = project.traitRegistry.traits.filter(t => t.id !== id);
        onUpdateProject({ ...project, traitRegistry: { ...project.traitRegistry, traits } });
    };

    return (
        <div className="space-y-4">
            {project.traitRegistry.traits.map(trait => (
                <div key={trait.id} className="p-2 bg-[var(--bg-interactive)] rounded-md flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full flex-shrink-0" style={{ backgroundColor: trait.color }} />
                    <Icon name={trait.icon} className="w-5 h-5 flex-shrink-0" />
                    <div className="flex-grow">
                        <p className="font-bold">{trait.name}</p>
                        <p className="text-xs text-[var(--text-secondary)]">{trait.description}</p>
                    </div>
                    <button onClick={() => setEditingTrait(trait)} className="p-1 text-[var(--text-secondary)] hover:text-white"><Icon name="cog" className="w-4 h-4"/></button>
                    <button onClick={() => handleDelete(trait.id)} className="p-1 text-[var(--text-secondary)] hover:text-red-400"><Icon name="trash" className="w-4 h-4"/></button>
                </div>
            ))}
            
            {editingTrait ? (
                <div className="p-3 bg-[var(--bg-tertiary)] rounded-lg border border-[var(--border-primary)] space-y-2">
                    <h4 className="label-text">{editingTrait.id ? 'Edit Trait' : 'New Trait'}</h4>
                    <input type="text" placeholder="Trait Name" value={editingTrait.name || ''} onChange={e => setEditingTrait({...editingTrait, name: e.target.value})} className="inspector-input" />
                    <textarea placeholder="Description" value={editingTrait.description || ''} onChange={e => setEditingTrait({...editingTrait, description: e.target.value})} className="inspector-input" rows={2} />
                    <div className="flex items-center gap-2">
                        <input type="color" value={editingTrait.color || '#ffffff'} onChange={e => setEditingTrait({...editingTrait, color: e.target.value})} className="w-10 h-10 p-1 bg-transparent border-none rounded" />
                        <select value={editingTrait.icon || 'dna'} onChange={e => setEditingTrait({...editingTrait, icon: e.target.value as IconName})} className="inspector-input">
                            {LORE_ICONS.map(icon => <option key={icon} value={icon}>{icon}</option>)}
                        </select>
                    </div>
                    <div className="flex gap-2">
                        <button onClick={() => setEditingTrait(null)} className="button-secondary w-full">Cancel</button>
                        <button onClick={handleSave} className="button-primary w-full">Save</button>
                    </div>
                </div>
            ) : (
                <button onClick={() => setEditingTrait({name: '', description: '', color: '#ffffff', icon: 'dna'})} className="button-secondary w-full">
                    Add Trait
                </button>
            )}
        </div>
    );
};

const SymbolsManager: React.FC<TraitRegistryPanelProps> = ({ project, onUpdateProject }) => {
    const [editingSymbol, setEditingSymbol] = useState<Partial<SymbolGlyph> | null>(null);

    const handleSave = () => {
        if (!editingSymbol || !editingSymbol.name) return;
        const symbols = project.symbolRegistry.symbols || [];
        const updatedSymbols = editingSymbol.id
            ? symbols.map(s => s.id === editingSymbol.id ? { ...s, ...editingSymbol } as SymbolGlyph : s)
            : [...symbols, { ...editingSymbol, id: `symbol_${Date.now()}` } as SymbolGlyph];
        
        onUpdateProject({ ...project, symbolRegistry: { ...project.symbolRegistry, symbols: updatedSymbols } });
        setEditingSymbol(null);
    };

    const handleDelete = (id: string) => {
        const symbols = project.symbolRegistry.symbols.filter(s => s.id !== id);
        onUpdateProject({ ...project, symbolRegistry: { ...project.symbolRegistry, symbols } });
    };

    return (
        <div className="space-y-4">
            {project.symbolRegistry.symbols.map(symbol => (
                <div key={symbol.id} className="p-2 bg-[var(--bg-interactive)] rounded-md flex items-center gap-2">
                    <Icon name="tag" className="w-5 h-5 flex-shrink-0 text-[var(--text-secondary)]" />
                    <div className="flex-grow">
                        <p className="font-bold">{symbol.name}</p>
                        <p className="text-xs text-[var(--text-secondary)]">{symbol.description}</p>
                    </div>
                    <button onClick={() => setEditingSymbol(symbol)} className="p-1 text-[var(--text-secondary)] hover:text-white"><Icon name="cog" className="w-4 h-4"/></button>
                    <button onClick={() => handleDelete(symbol.id)} className="p-1 text-[var(--text-secondary)] hover:text-red-400"><Icon name="trash" className="w-4 h-4"/></button>
                </div>
            ))}
            
            {editingSymbol ? (
                <div className="p-3 bg-[var(--bg-tertiary)] rounded-lg border border-[var(--border-primary)] space-y-2">
                    <h4 className="label-text">{editingSymbol.id ? 'Edit Symbol' : 'New Symbol'}</h4>
                    <input type="text" placeholder="Symbol Name" value={editingSymbol.name || ''} onChange={e => setEditingSymbol({...editingSymbol, name: e.target.value})} className="inspector-input" />
                    <textarea placeholder="Description" value={editingSymbol.description || ''} onChange={e => setEditingSymbol({...editingSymbol, description: e.target.value})} className="inspector-input" rows={2} />
                    <div className="flex gap-2">
                        <button onClick={() => setEditingSymbol(null)} className="button-secondary w-full">Cancel</button>
                        <button onClick={handleSave} className="button-primary w-full">Save</button>
                    </div>
                </div>
            ) : (
                <button onClick={() => setEditingSymbol({name: '', description: ''})} className="button-secondary w-full">
                    Add Symbol
                </button>
            )}
        </div>
    );
};

export default TraitRegistryPanel;