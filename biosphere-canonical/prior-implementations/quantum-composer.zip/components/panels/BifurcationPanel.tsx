// This component is deprecated. Its functionality has been migrated to components/panels/ObserverAuditPanel.tsx
const BifurcationPanel = () => null;
export default BifurcationPanel;
