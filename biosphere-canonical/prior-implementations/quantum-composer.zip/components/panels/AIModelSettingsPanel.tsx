
import React, { useState } from 'react';
import type { LLMConfig } from '../../types';

interface AIModelSettingsPanelProps {
  models: LLMConfig[];
  onUpdate: (models: LLMConfig[]) => void;
}

const AIModelSettingsPanel: React.FC<AIModelSettingsPanelProps> = ({ models, onUpdate }) => {
  const [editingModels, setEditingModels] = useState<LLMConfig[]>(models);

  const handleModelChange = (id: string, field: keyof LLMConfig, value: string) => {
    setEditingModels(
      editingModels.map(m => (m.id === id ? { ...m, [field]: value } : m))
    );
  };

  const handleSave = () => {
    onUpdate(editingModels);
  };

  const addModel = () => {
    const newModel: LLMConfig = {
        id: `model_${Date.now()}`,
        name: 'New Local Model',
        provider: 'local',
        modelId: 'model-name',
        url: 'http://localhost:11434/api/generate'
    };
    setEditingModels([...editingModels, newModel]);
  }

  return (
    <div className="p-4 space-y-4">
      <h3 className="panel-header">AI Model Settings</h3>
      <div className="space-y-3">
        {editingModels.map(model => (
          <div key={model.id} className="p-3 bg-[var(--bg-tertiary)] rounded-lg border border-[var(--border-primary)] space-y-2">
            <input
              type="text"
              value={model.name}
              onChange={e => handleModelChange(model.id, 'name', e.target.value)}
              className="inspector-input font-bold"
            />
            <div className="grid grid-cols-3 gap-2 text-xs">
              <span className="text-[var(--text-secondary)]">Provider</span>
              <span className="col-span-2 text-[var(--text-primary)]">{model.provider}</span>
              
              <label className="text-[var(--text-secondary)]">Model ID</label>
              <input
                type="text"
                value={model.modelId}
                onChange={e => handleModelChange(model.id, 'modelId', e.target.value)}
                className="inspector-input col-span-2"
                placeholder="e.g. gemini-2.5-flash"
              />
              
              <label className="text-[var(--text-secondary)]">URL</label>
              <input
                type="text"
                value={model.url || ''}
                disabled={model.provider !== 'local'}
                onChange={e => handleModelChange(model.id, 'url', e.target.value)}
                className="inspector-input col-span-2 disabled:opacity-50"
                placeholder="http://localhost:11434/api/generate"
              />
          </div>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <button onClick={addModel} className="button-secondary w-full">Add Local Model</button>
        <button onClick={handleSave} className="button-primary w-full">Save Changes</button>
      </div>
    </div>
  );
};

export default AIModelSettingsPanel;