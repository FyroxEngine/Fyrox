import React from 'react';
import type { QuantumForgeProject } from '../../types';
import PluginManagerItem from '../PluginManagerItem';
import Icon from '../icons/Icon';

interface PluginManagerPanelProps {
    project: QuantumForgeProject;
    selectedPluginId?: string | null;
    onSelect: (pluginId: string | null) => void;
    onUpdateProject: (updatedProject: QuantumForgeProject) => void;
    onAddPlugin: () => void;
    onDeletePlugin: (pluginId: string) => void;
}

const PluginManagerPanel: React.FC<PluginManagerPanelProps> = ({ project, selectedPluginId, onSelect, onUpdateProject, onAddPlugin, onDeletePlugin }) => {
    const plugins = project.plugins || [];

    return (
        <div className="w-full h-full flex flex-col">
             <div className="flex items-center justify-between pb-4 mb-4 border-b border-[var(--border-primary)]">
                <h3 className="panel-header text-lg text-[var(--text-highlight)]">Plugin Manager</h3>
                <button onClick={onAddPlugin} title="Add New Plugin" className="flex items-center justify-center w-8 h-8 rounded-md bg-[var(--bg-interactive)] hover:bg-[var(--color-accent-primary)]/80 transition-colors">
                    <Icon name="plus" className="w-5 h-5"/>
                </button>
             </div>
             <div className="flex-grow h-full overflow-y-auto space-y-4 pr-2">
                {plugins.length > 0 ? (
                    plugins.map(plugin => (
                        <PluginManagerItem 
                            key={plugin.id}
                            plugin={plugin}
                            parentProject={project}
                            isSelected={plugin.id === selectedPluginId}
                            onSelect={() => onSelect(plugin.id)}
                            onUpdateProject={onUpdateProject}
                            onDeletePlugin={() => onDeletePlugin(plugin.id)}
                        />
                    ))
                ) : (
                    <div className="flex items-center justify-center h-full text-center text-[var(--text-secondary)]">
                        <p>No plugins in this project.<br/>Add one to get started.</p>
                    </div>
                )}
             </div>
        </div>
    );
};

export default PluginManagerPanel;