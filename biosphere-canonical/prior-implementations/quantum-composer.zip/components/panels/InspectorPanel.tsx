import React, { useState, useEffect, useCallback } from 'react';
import type { QuantumForgeProject, QuantumForgeNode, QuantumForgeNodeUpdate, Zone, LLMConfig, Archetype, GenreProfile, QuantumOutcome, SignalModulationCurve, Trait, SymbolGlyph } from '../../types';
import Icon from '../icons/Icon';
import { generateQuantumOutcomes } from '../../services/geminiService';
import { ARCHETYPES } from '../../constants';

interface InspectorPanelProps {
    project: QuantumForgeProject | null;
    selectedNodes: QuantumForgeNode[];
    selectedZone: Zone | null;
    selectedPlugin: QuantumForgeProject | null;
    onUpdateProject: (project: QuantumForgeProject) => void;
    onUpdateNodes: (updates: QuantumForgeNodeUpdate[]) => void;
    aiModels: LLMConfig[];
    onDeleteNode: (nodeIds: string[]) => void;
    activeGenreProfile: GenreProfile | null;
    onCollapseNode: (nodeId: string) => void;
}

const InspectorPanel: React.FC<InspectorPanelProps> = ({ 
    project, 
    selectedNodes, 
    selectedZone,
    selectedPlugin,
    onUpdateProject,
    onUpdateNodes,
    aiModels,
    onDeleteNode,
    activeGenreProfile,
    onCollapseNode,
}) => {

    const handleUpdateZone = (zone: Zone) => {
        if (!project) return;
        const updatedProject = { ...project };
        if (!updatedProject.zones) updatedProject.zones = [];
        const zoneIndex = updatedProject.zones.findIndex(z => z.id === zone.id);
        if (zoneIndex !== -1) {
            updatedProject.zones[zoneIndex] = zone;
            onUpdateProject(updatedProject);
        }
    };
    
    const handleUpdatePlugin = (plugin: QuantumForgeProject) => {
       if (!project) return;
       const updatedProject = JSON.parse(JSON.stringify(project));
        if (plugin.id === project.id) {
            updatedProject.name = plugin.name;
            updatedProject.description = plugin.description;
            updatedProject.intent = plugin.intent;
        } else {
            const index = updatedProject.plugins?.findIndex(i => i.id === plugin.id);
            if (updatedProject.plugins && index !== -1) {
                updatedProject.plugins[index] = plugin;
            }
        }
        onUpdateProject(updatedProject);
    };

    const renderContent = () => {
        if (selectedNodes.length === 1) {
            return <NodeInspector node={selectedNodes[0]} onUpdate={onUpdateNodes} project={project} models={aiModels} onDeleteNode={onDeleteNode} genreProfile={activeGenreProfile} onCollapseNode={onCollapseNode} />;
        }
        if (selectedNodes.length > 1) {
             return (
                <div>
                    <div className="flex items-center gap-2 mb-4">
                        <Icon name="node-cluster" className="w-6 h-6 text-[var(--text-highlight)]"/>
                        <h3 className="text-lg font-bold text-[var(--text-primary)]">Multiple Nodes Selected</h3>
                    </div>
                    <InspectorField label="Count"><p>{selectedNodes.length} nodes selected</p></InspectorField>
                     <div className="mt-4">
                        <button onClick={() => onDeleteNode(selectedNodes.map(n => n.id))} className="w-full flex items-center justify-center gap-2 text-sm px-3 py-1.5 rounded-md bg-red-800/50 hover:bg-red-700/50 text-red-200 transition-colors">
                            <Icon name="trash" className="w-4 h-4"/>
                            Delete Selected Nodes
                        </button>
                    </div>
                </div>
            );
        }
        if (selectedZone) {
            return <ZoneInspector zone={selectedZone} onUpdate={handleUpdateZone} project={project} onUpdateProject={onUpdateProject} />;
        }
        if (selectedPlugin) {
            return <ProjectInspector project={selectedPlugin} onUpdate={handleUpdatePlugin} isSubProject={project?.id !== selectedPlugin.id} />;
        }
        return <p className="text-[var(--text-secondary)] text-center mt-8">Select an item to inspect.</p>;
    }

    return (
        <div className="p-4 text-sm space-y-4 h-full overflow-y-auto">
            {renderContent()}
        </div>
    );
};

const NodeInspector: React.FC<{node: QuantumForgeNode, onUpdate: (u: QuantumForgeNodeUpdate[]) => void, project: QuantumForgeProject | null, models: LLMConfig[], onDeleteNode: (ids: string[]) => void, genreProfile: GenreProfile | null, onCollapseNode: (nodeId: string) => void}> = ({ node, onUpdate, project, models, onDeleteNode, genreProfile, onCollapseNode }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [prompt, setPrompt] = useState('');
    const [selectedTraitId, setSelectedTraitId] = useState('');
    const [selectedSymbolId, setSelectedSymbolId] = useState('');

    const allTraits = project?.traitRegistry.traits || [];
    const allSymbols = project?.symbolRegistry.symbols || [];

    const updateField = (field: keyof QuantumForgeNode, value: any) => {
        onUpdate([{ id: node.id, [field]: value }]);
    };
    
    const updateQuantumState = (updates: Partial<typeof node.quantumState>) => {
        onUpdate([{
            id: node.id,
            quantumState: { ...node.quantumState, ...updates }
        }]);
    };

    const handleOutcomeChange = (index: number, newOutcome: QuantumOutcome) => {
        const newOutcomes = [...node.quantumState.outcomes];
        newOutcomes[index] = newOutcome;
        updateQuantumState({ outcomes: newOutcomes });
    };

    const normalizeProbabilities = () => {
        const total = node.quantumState.outcomes.reduce((sum, o) => sum + o.probability, 0);
        if (total === 0) return; // Avoid division by zero
        const newOutcomes = node.quantumState.outcomes.map(o => ({ ...o, probability: o.probability / total }));
        updateQuantumState({ outcomes: newOutcomes });
    };
    
    const handleGenerateOutcomes = async () => {
        if (!prompt) return;
        setIsLoading(true);
        try {
            const outcomes = await generateQuantumOutcomes(prompt);
            updateQuantumState({ collapsed: false, outcomes: outcomes });
        } catch(e) {
            console.error("Error generating quantum outcomes", e);
        } finally {
            setIsLoading(false);
        }
    };

    const handleLinkTrait = () => {
        if (selectedTraitId && !node.traitIds?.includes(selectedTraitId)) {
            updateField('traitIds', [...(node.traitIds || []), selectedTraitId]);
        }
    };

    const handleUnlinkTrait = (traitId: string) => {
        updateField('traitIds', (node.traitIds || []).filter(id => id !== traitId));
    };
    
    const handleLinkSymbol = () => {
        if (selectedSymbolId && !node.symbolIds?.includes(selectedSymbolId)) {
            updateField('symbolIds', [...(node.symbolIds || []), selectedSymbolId]);
        }
    };

    const handleUnlinkSymbol = (symbolId: string) => {
        updateField('symbolIds', (node.symbolIds || []).filter(id => id !== symbolId));
    };

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                    <Icon name={node.icon} className="w-6 h-6 text-[var(--text-highlight)]"/>
                    <h3 className="text-lg font-bold text-[var(--text-primary)]">Node Properties</h3>
                </div>
                <button onClick={() => onDeleteNode([node.id])} title="Delete Node" className="text-red-400/70 hover:text-red-400 p-1 rounded-full hover:bg-red-500/20">
                    <Icon name="trash" className="w-5 h-5"/>
                </button>
            </div>
            <InspectorField label="Label"><input type="text" value={node.label} onChange={e => updateField('label', e.target.value)} className="inspector-input" /></InspectorField>
            
            <InspectorField label="Lore">
                <div className="space-y-3">
                    <div>
                        <h4 className="label-text mb-1">Traits</h4>
                        <div className="space-y-1">
                            {(node.traitIds || []).map(id => {
                                const trait = allTraits.find(t => t.id === id);
                                return <div key={id} className="flex items-center justify-between bg-black/20 p-1.5 rounded-md text-xs"><span>{trait?.name || 'Unknown Trait'}</span><button onClick={()=>handleUnlinkTrait(id)} className="text-red-400/70 hover:text-red-400">X</button></div>
                            })}
                        </div>
                        <div className="flex gap-1 mt-2">
                            <select value={selectedTraitId} onChange={e => setSelectedTraitId(e.target.value)} className="inspector-input"><option value="">Link a trait...</option>{allTraits.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select>
                            <button onClick={handleLinkTrait} className="button-secondary px-3">+</button>
                        </div>
                    </div>
                     <div>
                        <h4 className="label-text mb-1">Symbols</h4>
                        <div className="space-y-1">
                            {(node.symbolIds || []).map(id => {
                                const symbol = allSymbols.find(s => s.id === id);
                                return <div key={id} className="flex items-center justify-between bg-black/20 p-1.5 rounded-md text-xs"><span>{symbol?.name || 'Unknown Symbol'}</span><button onClick={()=>handleUnlinkSymbol(id)} className="text-red-400/70 hover:text-red-400">X</button></div>
                            })}
                        </div>
                        <div className="flex gap-1 mt-2">
                            <select value={selectedSymbolId} onChange={e => setSelectedSymbolId(e.target.value)} className="inspector-input"><option value="">Link a symbol...</option>{allSymbols.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select>
                            <button onClick={handleLinkSymbol} className="button-secondary px-3">+</button>
                        </div>
                    </div>
                </div>
            </InspectorField>

            <InspectorField label="Quantum State">
                <div className="flex items-center gap-2">
                    <span>Collapsed:</span>
                    <input type="checkbox" checked={node.quantumState.collapsed} onChange={e => updateQuantumState({ collapsed: e.target.checked })} className="h-4 w-4 rounded accent-[var(--color-accent-primary)]"/>
                </div>
                 {!node.quantumState.collapsed && (
                    <button 
                        onClick={() => onCollapseNode(node.id)} 
                        className="w-full button-primary flex items-center justify-center gap-2 mt-2"
                    >
                        <Icon name="git-branch" className="w-5 h-5" />
                        Collapse State
                    </button>
                )}
            </InspectorField>

            <div className="space-y-2">
                <h4 className="label-text">Probabilistic Outcomes</h4>
                {node.quantumState.outcomes.map((outcome, index) => (
                    <div key={index} className="p-2 bg-black/20 rounded-md space-y-1">
                        <textarea value={outcome.content} onChange={e => handleOutcomeChange(index, {...outcome, content: e.target.value})} rows={2} className="inspector-input" />
                        <div className="flex items-center gap-2">
                            <label className="text-xs text-[var(--text-secondary)]">P:</label>
                            <input type="range" min="0" max="1" step="0.01" value={outcome.probability} onChange={e => handleOutcomeChange(index, {...outcome, probability: parseFloat(e.target.value)})} className="w-full h-1 accent-[var(--color-accent-primary)]"/>
                            <span className="text-xs w-8 text-right">{Math.round(outcome.probability * 100)}%</span>
                        </div>
                    </div>
                ))}
                <button onClick={normalizeProbabilities} className="button-secondary w-full text-xs">Normalize Probabilities</button>
            </div>

            <InspectorField label="AI Generation">
                <div className="p-2 bg-black/20 rounded-md space-y-2">
                    <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={2} className="inspector-input" placeholder="Enter prompt to generate outcomes..."/>
                    <button onClick={handleGenerateOutcomes} disabled={isLoading || !prompt} className="w-full button-primary flex items-center justify-center gap-2 disabled:opacity-50">
                        {isLoading ? 'Generating...' : <><Icon name="sparkles" className="w-4 h-4"/> Generate Quantum Outcomes</>}
                    </button>
                </div>
            </InspectorField>
        </div>
    )
};

const ZoneInspector: React.FC<{zone: Zone, onUpdate: (z: Zone) => void, project: QuantumForgeProject | null, onUpdateProject: (p: QuantumForgeProject) => void}> = ({ zone, onUpdate, project, onUpdateProject }) => {
    const isResonanceField = !!zone.resonanceField;

    const handleToggleResonance = (enabled: boolean) => {
        if (enabled) {
            onUpdate({ ...zone, resonanceField: { signalSource: 'control', sourceId: '', strength: 0.5 } });
        } else {
            const { resonanceField, ...rest } = zone;
            onUpdate(rest);
        }
    };
    
    const updateResonanceField = (updates: Partial<SignalModulationCurve>) => {
        if (zone.resonanceField) {
            onUpdate({ ...zone, resonanceField: { ...zone.resonanceField, ...updates } });
        }
    };
    
    const allControls = project?.plugins?.flatMap(p => p.controls?.map(c => ({...c, pluginName: p.name}))) || [];

    return (
        <div className="space-y-4">
            <h3 className="text-lg font-bold text-[var(--text-primary)]">Zone Properties</h3>
            <InspectorField label="Label"><input type="text" value={zone.label} onChange={e => onUpdate({...zone, label: e.target.value})} className="inspector-input" /></InspectorField>
            <InspectorField label="Color"><input type="color" value={zone.color.startsWith('rgba') ? '#ffffff' : zone.color} onChange={e => { const c = e.target.value; onUpdate({...zone, color: `rgba(${parseInt(c.slice(1,3),16)},${parseInt(c.slice(3,5),16)},${parseInt(c.slice(5,7),16)},0.1)`}) }} className="w-full h-8 p-0 border-none rounded-md bg-[var(--bg-primary)]"/></InspectorField>
            <InspectorField label="Symbolism"><textarea value={zone.symbolism || ''} onChange={e => onUpdate({...zone, symbolism: e.target.value})} rows={3} className="inspector-input" /></InspectorField>
            
            <InspectorField label="Resonance Field Designer">
                <div className="flex items-center gap-2 p-2 bg-black/20 rounded-md">
                    <label htmlFor="resonance-toggle" className="font-bold">Enable Resonance Field</label>
                    <input id="resonance-toggle" type="checkbox" checked={isResonanceField} onChange={e => handleToggleResonance(e.target.checked)} className="ml-auto h-4 w-4 rounded accent-[var(--color-accent-primary)]"/>
                </div>
                {isResonanceField && zone.resonanceField && (
                    <div className="p-2 bg-black/20 rounded-md mt-2 space-y-2">
                        <div>
                            <label className="text-xs text-[var(--text-secondary)]">Strength: {Math.round(zone.resonanceField.strength * 100)}%</label>
                            <input type="range" min="0" max="1" step="0.01" value={zone.resonanceField.strength} onChange={e => updateResonanceField({ strength: parseFloat(e.target.value) })} className="w-full h-2 bg-[var(--bg-primary)] rounded-full appearance-none cursor-pointer accent-[var(--color-accent-primary)] mt-1" />
                        </div>
                        <div>
                            <label className="text-xs text-[var(--text-secondary)]">Signal Source</label>
                            <select value={zone.resonanceField.sourceId} onChange={e => updateResonanceField({ sourceId: e.target.value })} className="inspector-input mt-1">
                                <option value="">Select a Control...</option>
                                {allControls.map(c => (
                                    <option key={c.id} value={c.id}>{c.pluginName}: {c.label}</option>
                                ))}
                            </select>
                        </div>
                    </div>
                )}
            </InspectorField>
        </div>
    );
};


const ProjectInspector: React.FC<{project: QuantumForgeProject, onUpdate: (p: QuantumForgeProject) => void, isSubProject: boolean}> = ({ project, onUpdate, isSubProject }) => {
    const title = isSubProject ? "Plugin Properties" : "Project Details";
    return (
        <div>
            <div className="flex items-center gap-2 mb-4">
                 <Icon name={project.icon} className="w-6 h-6 text-[var(--text-highlight)]"/>
                <h3 className="text-lg font-bold text-[var(--text-primary)]">{title}</h3>
            </div>
            <InspectorField label="Name"><input type="text" value={project.name} onChange={e => onUpdate({...project, name: e.target.value})} className="inspector-input" /></InspectorField>
            <InspectorField label="Description"><textarea value={project.description} onChange={e => onUpdate({...project, description: e.target.value})} rows={3} className="inspector-input" /></InspectorField>
            {!isSubProject && (
                 <InspectorField label="Project Intent"><textarea value={project.intent || ''} onChange={e => onUpdate({...project, intent: e.target.value})} rows={3} className="inspector-input"/></InspectorField>
            )}
        </div>
    );
}

const InspectorField: React.FC<{label:string, children: React.ReactNode}> = ({ label, children }) => (
    <div className="border-t border-[var(--border-primary)]/50 py-2">
        <label className="text-xs font-bold text-[var(--text-secondary)] tracking-wider uppercase">{label}</label>
        <div className="text-[var(--text-primary)] mt-1">{children}</div>
    </div>
)

export default InspectorPanel;
