import React, { useState } from 'react';
import type { QuantumForgeProject, GenreProfile } from '../../types';
import { GENRE_PROFILES } from '../../constants';
import { analyzeNarrativeDNA } from '../../services/geminiService';
import Icon from '../icons/Icon';

interface GenrePalettePanelProps {
    project: QuantumForgeProject;
    onSetGenre: (genreId: string | null) => void;
}

const GenrePalettePanel: React.FC<GenrePalettePanelProps> = ({ project, onSetGenre }) => {
    const activeGenreId = project.activeGenreProfileId;
    const [isLoading, setIsLoading] = useState(false);
    const [analysisResult, setAnalysisResult] = useState('');
    
    const handleAnalyze = async () => {
        setIsLoading(true);
        setAnalysisResult('');
        try {
            const resultId = await analyzeNarrativeDNA(project, GENRE_PROFILES);
            if (resultId) {
                const matchedGenre = GENRE_PROFILES.find(g => g.id === resultId);
                setAnalysisResult(`Suggested Genre: ${matchedGenre?.name || 'Unknown'}`);
                onSetGenre(resultId);
            } else {
                 setAnalysisResult('Could not determine a matching genre.');
            }
        } catch (error) {
            console.error(error);
            setAnalysisResult('Error during analysis.');
        } finally {
            setIsLoading(false);
        }
    }

    return (
        <div className="flex flex-col h-full text-sm">
            <h3 className="panel-header text-lg mb-4 text-[var(--text-highlight)] flex items-center gap-2">
                <Icon name="theater" className="w-5 h-5"/>
                Genre & Archetype
            </h3>

            <div className="space-y-3 flex-grow overflow-y-auto pr-2">
                {GENRE_PROFILES.map(genre => (
                    <button 
                        key={genre.id}
                        onClick={() => onSetGenre(activeGenreId === genre.id ? null : genre.id)}
                        className={`w-full text-left p-3 rounded-lg border-2 transition-all duration-200 ${activeGenreId === genre.id ? 'border-[var(--color-accent-primary)] bg-[var(--color-accent-primary)]/20' : 'border-transparent bg-[var(--bg-interactive)] hover:border-[var(--text-highlight)]/40'}`}
                    >
                        <p className="font-bold text-base text-[var(--text-primary)]">{genre.name}</p>
                        <p className="text-xs text-[var(--text-secondary)] mt-1">{genre.description}</p>
                    </button>
                ))}
            </div>

            <div className="mt-4 pt-4 border-t border-[var(--border-primary)]">
                 <button 
                    onClick={handleAnalyze} 
                    disabled={isLoading}
                    className="button-primary w-full flex items-center justify-center gap-2 disabled:opacity-50"
                 >
                    {isLoading ? (
                       <> <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Analyzing...</>
                    ) : (
                        <><Icon name="sparkles" className="w-4 h-4"/> Analyze Narrative DNA</>
                    )}
                 </button>
                 {analysisResult && (
                    <p className="text-center text-xs text-[var(--text-secondary)] italic mt-2">{analysisResult}</p>
                 )}
            </div>
        </div>
    );
};

export default GenrePalettePanel;