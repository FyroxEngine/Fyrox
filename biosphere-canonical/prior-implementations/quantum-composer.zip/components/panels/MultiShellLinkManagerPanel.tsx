import React, { useState } from 'react';
import type { QuantumForgeProject, StudioShell, RitualLink } from '../../types';
import { RitualEchoMode, RitualTriggerType } from '../../types';
import Icon from '../icons/Icon';

interface MultiShellLinkManagerPanelProps {
    project: QuantumForgeProject;
    onUpdateEcosystemData: (key: 'linkedShells' | 'ritualLinks', data: any[]) => void;
}

const MultiShellLinkManagerPanel: React.FC<MultiShellLinkManagerPanelProps> = ({ project, onUpdateEcosystemData }) => {
    const shells = project.linkedShells || [];
    const rituals = project.ritualLinks || [];

    const [newShellName, setNewShellName] = useState('');
    const [newRitualName, setNewRitualName] = useState('');

    const handleAddShell = () => {
        if (!newShellName.trim()) return;
        const newShell: StudioShell = {
            id: `shell_${Date.now()}`,
            name: newShellName,
            description: 'A linked creative instance.',
            status: 'online',
        };
        onUpdateEcosystemData('linkedShells', [...shells, newShell]);
        setNewShellName('');
    };

    const handleAddRitual = () => {
        if (!newRitualName.trim()) return;
        const newRitual: RitualLink = {
            id: `ritual_${Date.now()}`,
            name: newRitualName,
            triggerType: RitualTriggerType.Gesture,
            sourceShellId: 'any',
            targetShellIds: shells.map(s => s.id),
            echoMode: RitualEchoMode.Ripple,
            enabled: true,
        };
        onUpdateEcosystemData('ritualLinks', [...rituals, newRitual]);
        setNewRitualName('');
    }
    
    const handleToggleRitual = (ritualId: string) => {
        const updatedRituals = rituals.map(r => r.id === ritualId ? {...r, enabled: !r.enabled} : r);
        onUpdateEcosystemData('ritualLinks', updatedRituals);
    }
    
    const handleDeleteRitual = (ritualId: string) => {
        onUpdateEcosystemData('ritualLinks', rituals.filter(r => r.id !== ritualId));
    }

    return (
        <div className="flex flex-col h-full text-sm">
            <h3 className="panel-header text-lg mb-4 text-[var(--text-highlight)] flex items-center gap-2">
                <Icon name="infinity" className="w-5 h-5"/>
                Link Manager
            </h3>

            {/* Studio Shells Section */}
            <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 mb-4">
                <h4 className="label-text mb-2">Connected Studio Shells</h4>
                <div className="max-h-28 overflow-y-auto space-y-1 pr-1 mb-2">
                   {shells.map(shell => (
                       <div key={shell.id} className="flex items-center gap-2 p-1.5 bg-[var(--bg-interactive)] rounded-md">
                           <span className={`w-2 h-2 rounded-full ${shell.status === 'online' ? 'bg-green-400' : 'bg-slate-500'}`} />
                           <span className="truncate flex-grow">{shell.name}</span>
                       </div>
                   ))}
                    {shells.length === 0 && <p className="text-xs text-[var(--text-secondary)] text-center py-4">No linked shells.</p>}
                </div>
                 <div className="flex gap-2">
                    <input type="text" value={newShellName} onChange={e => setNewShellName(e.target.value)} placeholder="New shell name..." className="inspector-input w-full"/>
                    <button onClick={handleAddShell} className="button-primary flex-shrink-0 px-3">+</button>
                </div>
            </div>

            {/* Ritual Links Section */}
            <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50">
                <h4 className="label-text mb-2">Ritual Links</h4>
                <div className="max-h-40 overflow-y-auto space-y-2 pr-1 mb-2">
                    {rituals.map(ritual => (
                        <div key={ritual.id} className="p-2 bg-[var(--bg-interactive)] rounded-md">
                            <div className="flex items-center justify-between">
                                <span className="font-bold truncate">{ritual.name}</span>
                                <div className="flex items-center gap-2">
                                    <button onClick={() => handleDeleteRitual(ritual.id)} className="text-red-400/60 hover:text-red-400"><Icon name="trash" className="w-4 h-4"/></button>
                                    <button onClick={() => handleToggleRitual(ritual.id)} className={`w-10 h-5 rounded-full p-1 transition-colors ${ritual.enabled ? 'bg-[var(--color-accent-primary)]' : 'bg-slate-600'}`}>
                                        <div className={`w-3 h-3 rounded-full bg-white transition-transform ${ritual.enabled ? 'transform translate-x-4' : ''}`}></div>
                                    </button>
                                </div>
                            </div>
                            <div className="text-xs text-[var(--text-secondary)] mt-1">
                                <p>Trigger: {ritual.triggerType} | Echo: {ritual.echoMode}</p>
                            </div>
                        </div>
                    ))}
                    {rituals.length === 0 && <p className="text-xs text-[var(--text-secondary)] text-center py-4">No ritual links defined.</p>}
                </div>
                <div className="flex gap-2">
                    <input type="text" value={newRitualName} onChange={e => setNewRitualName(e.target.value)} placeholder="New ritual name..." className="inspector-input w-full"/>
                    <button onClick={handleAddRitual} className="button-primary flex-shrink-0 px-3">+</button>
                </div>
            </div>
        </div>
    );
};

export default MultiShellLinkManagerPanel;