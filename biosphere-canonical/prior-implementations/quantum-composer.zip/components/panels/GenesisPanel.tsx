import React, { useState } from 'react';
import type { QuantumForgeProject, MythicArchetype, NarrativeSeed, GenreProfile, ProceduralArc, EvolutionaryAlgorithmConfig } from '../../types';
import { GENRE_PROFILES } from '../../constants';
import { generateNarrativeArc, mutateArchetype } from '../../services/geminiService';
import Icon from '../icons/Icon';

interface GenesisPanelProps {
    project: QuantumForgeProject;
    onCreateArchetype: (archetype: MythicArchetype) => void;
    onUpdateArchetype: (archetype: MythicArchetype) => void;
    onCreateSeed: (seed: NarrativeSeed) => void;
}

const GenesisPanel: React.FC<GenesisPanelProps> = ({ project, onCreateArchetype, onUpdateArchetype, onCreateSeed }) => {
    const archetypes = project.mythicArchetypes || [];
    
    // State for new items
    const [newArchetypeName, setNewArchetypeName] = useState('');
    const [newSeedName, setNewSeedName] = useState('');
    const [selectedGenreId, setSelectedGenreId] = useState(GENRE_PROFILES[0].id);
    const [selectedArchetypeId, setSelectedArchetypeId] = useState(archetypes[0]?.id || '');
    const [corePrompt, setCorePrompt] = useState('');
    
    // State for generation
    const [evolutionConfig, setEvolutionConfig] = useState<EvolutionaryAlgorithmConfig>({ stability: 0.5 });
    const [generatedArc, setGeneratedArc] = useState<ProceduralArc | null>(null);
    const [isGenerating, setIsGenerating] = useState(false);
    const [isEvolving, setIsEvolving] = useState(false);
    const [evolutionTarget, setEvolutionTarget] = useState<string | null>(null);

    const handleAddArchetype = () => {
        if (!newArchetypeName.trim()) return;
        const newArchetype: MythicArchetype = {
            id: `arch_${Date.now()}`,
            name: newArchetypeName,
            description: 'A newly created archetype.',
            thematicTraits: ['trait1', 'trait2', 'trait3', 'trait4'],
        };
        onCreateArchetype(newArchetype);
        setNewArchetypeName('');
    };
    
    const handleEvolveArchetype = async (archetype: MythicArchetype) => {
        setIsEvolving(true);
        setEvolutionTarget(archetype.id);
        try {
            const mutation = await mutateArchetype(archetype, project);
            onUpdateArchetype({ ...archetype, ...mutation });
        } catch (error) {
            console.error("Failed to evolve archetype:", error);
        } finally {
            setIsEvolving(false);
            setEvolutionTarget(null);
        }
    };
    
    const handleAddSeed = () => {
        if (!newSeedName.trim() || !corePrompt.trim()) return;
        const newSeed: NarrativeSeed = {
            id: `seed_${Date.now()}`,
            name: newSeedName,
            genreProfileId: selectedGenreId,
            mythicArchetypeId: selectedArchetypeId,
            corePrompt,
        };
        onCreateSeed(newSeed);
        setNewSeedName('');
        setCorePrompt('');
    };

    const handleGenerateArc = async () => {
        const seed = project.narrativeSeeds?.[project.narrativeSeeds.length - 1];
        if (!seed) {
            alert("Create and save a Narrative Seed first!");
            return;
        }
        
        const genre = GENRE_PROFILES.find(g => g.id === seed.genreProfileId);
        const archetype = archetypes.find(a => a.id === seed.mythicArchetypeId);
        
        if (!genre || !archetype) {
             alert("Could not find the Genre or Archetype for the latest seed.");
             return;
        }

        setIsGenerating(true);
        setGeneratedArc(null);
        try {
            const arc = await generateNarrativeArc(seed, evolutionConfig, genre, archetype);
            setGeneratedArc(arc);
        } catch (error) {
            console.error("Failed to generate narrative arc:", error);
            const errorArc: ProceduralArc = { title: "Generation Failed", scenes: [{ title: "Error", description: (error as Error).message, keyEvent: "Please check console." }] };
            setGeneratedArc(errorArc);
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <div className="flex flex-col h-full text-sm">
            <h3 className="panel-header text-lg mb-4 text-[var(--text-highlight)] flex items-center gap-2">
                <Icon name="atom" className="w-5 h-5"/>
                Narrative Genesis
            </h3>

            {/* Narrative Seed Creator */}
            <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 mb-4 space-y-2">
                <h4 className="label-text">1. Create Narrative Seed</h4>
                <input type="text" value={newSeedName} onChange={e => setNewSeedName(e.target.value)} placeholder="Seed Name" className="inspector-input" />
                <select value={selectedGenreId} onChange={e => setSelectedGenreId(e.target.value)} className="inspector-input"><option value="">Select Genre</option>{GENRE_PROFILES.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}</select>
                <select value={selectedArchetypeId} onChange={e => setSelectedArchetypeId(e.target.value)} className="inspector-input"><option value="">Select Archetype</option>{archetypes.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}</select>
                <textarea value={corePrompt} onChange={e => setCorePrompt(e.target.value)} placeholder="Core Prompt (e.g., 'a lone detective finds a strange artifact')" rows={2} className="inspector-input" />
                <button onClick={handleAddSeed} className="button-secondary w-full">Save Seed</button>
            </div>
            
            {/* Procedural Arc Generator */}
            <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 mb-4 space-y-2">
                <h4 className="label-text">2. Generate Narrative Arc</h4>
                <div>
                  <label className="text-xs text-[var(--text-secondary)]">Evolutionary Stability: {Math.round(evolutionConfig.stability * 100)}%</label>
                  <input type="range" min="0" max="1" step="0.01" value={evolutionConfig.stability} onChange={e => setEvolutionConfig({ stability: parseFloat(e.target.value) })} className="w-full h-2 bg-[var(--bg-primary)] rounded-full appearance-none cursor-pointer accent-[var(--color-accent-primary)] mt-1" />
                </div>
                <button onClick={handleGenerateArc} disabled={isGenerating || !project.narrativeSeeds?.length} className="button-primary w-full disabled:opacity-50 flex items-center justify-center gap-2">
                    {isGenerating ? 'Generating...' : <><Icon name="sparkles" className="w-4 h-4" />Generate Arc from Latest Seed</>}
                </button>
                {generatedArc && (
                    <div className="mt-2 p-2 bg-black/20 rounded-md max-h-40 overflow-y-auto space-y-2">
                        <h5 className="font-bold text-[var(--text-highlight)]">{generatedArc.title}</h5>
                        {generatedArc.scenes.map((scene, index) => (
                            <div key={index} className="text-xs border-t border-[var(--border-primary)]/50 pt-1">
                                <p className="font-bold">{scene.title}</p>
                                <p className="italic text-[var(--text-secondary)]">{scene.description}</p>
                                <p><strong>Event:</strong> {scene.keyEvent}</p>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Archetype Mutator */}
            <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 flex-grow flex flex-col">
                <h4 className="label-text mb-2">Mythic Archetypes</h4>
                 <div className="flex-grow overflow-y-auto space-y-2 pr-1 mb-2">
                     {archetypes.map(arch => (
                         <div key={arch.id} className="p-2 bg-[var(--bg-interactive)] rounded-md">
                             <div className="flex items-center justify-between">
                                 <p className="font-bold">{arch.name}</p>
                                 <button onClick={() => handleEvolveArchetype(arch)} disabled={isEvolving} className="button-secondary px-2 py-0.5 text-xs disabled:opacity-50">
                                     {isEvolving && evolutionTarget === arch.id ? '...' : 'Evolve'}
                                 </button>
                             </div>
                             <p className="text-xs text-[var(--text-secondary)] italic mt-1">{arch.description}</p>
                         </div>
                     ))}
                 </div>
                <div className="flex gap-2 mt-auto pt-2 border-t border-[var(--border-primary)]/50">
                    <input type="text" value={newArchetypeName} onChange={e => setNewArchetypeName(e.target.value)} placeholder="New archetype name..." className="inspector-input w-full"/>
                    <button onClick={handleAddArchetype} className="button-primary flex-shrink-0 px-3">+</button>
                </div>
            </div>
        </div>
    );
};

export default GenesisPanel;