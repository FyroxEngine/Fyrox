import React, { useState } from 'react';
import type { ScrollCapsule, ScrollCapsuleFile } from '../../types';
import { forgeScrollCapsule } from '../../services/geminiService';
import Icon from '../icons/Icon';

interface ScrollForgePanelProps {
    onSaveCapsule: (capsule: ScrollCapsule) => void;
}

const ScrollForgePanel: React.FC<ScrollForgePanelProps> = ({ onSaveCapsule }) => {
    const [transcript, setTranscript] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [generatedCapsule, setGeneratedCapsule] = useState<ScrollCapsule | null>(null);
    const [activeTab, setActiveTab] = useState(0);

    const handleForge = async () => {
        if (!transcript.trim()) return;
        setIsLoading(true);
        setError(null);
        setGeneratedCapsule(null);
        try {
            const files = await forgeScrollCapsule(transcript);
            const newCapsule: ScrollCapsule = {
                id: `scroll_${Date.now()}`,
                createdAt: Date.now(),
                sourceText: transcript,
                files: files,
            };
            setGeneratedCapsule(newCapsule);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred during forging.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleSave = () => {
        if (generatedCapsule) {
            onSaveCapsule(generatedCapsule);
            setGeneratedCapsule(null);
            setTranscript('');
            alert('ScrollCapsule saved to project!');
        }
    };

    return (
        <div className="flex flex-col h-full text-sm">
            <h3 className="panel-header text-lg mb-4 text-[var(--text-highlight)] flex items-center gap-2">
                <Icon name="document-arrow-down" className="w-5 h-5"/>
                ScrollForge
            </h3>

            <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 space-y-2 flex-grow flex flex-col">
                <h4 className="label-text">1. Input Transcript</h4>
                <textarea
                    value={transcript}
                    onChange={(e) => setTranscript(e.target.value)}
                    placeholder="Paste your chat transcript or text here..."
                    rows={8}
                    className="inspector-input flex-grow w-full resize-none"
                    disabled={isLoading}
                />
                <button onClick={handleForge} disabled={isLoading || !transcript.trim()} className="button-primary w-full flex items-center justify-center gap-2 disabled:opacity-50">
                    {isLoading ? (
                        <>
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Forging Capsule...
                        </>
                    ) : (
                        <><Icon name="sparkles" className="w-4 h-4"/>Forge Capsule</>
                    )}
                </button>
            </div>
            
            {error && (
                 <div className="mt-4 p-3 bg-red-900/50 border border-red-500/50 rounded-lg text-red-300 text-xs">
                    <h4 className="font-bold">Error</h4>
                    <p>{error}</p>
                </div>
            )}

            {generatedCapsule && (
                <div className="mt-4 border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 space-y-2 flex-grow flex flex-col">
                    <h4 className="label-text">2. Review & Save Capsule</h4>
                    <div className="flex border-b border-[var(--border-primary)] overflow-x-auto">
                        {generatedCapsule.files.map((file, index) => (
                            <button
                                key={index}
                                onClick={() => setActiveTab(index)}
                                className={`px-3 py-1.5 text-xs whitespace-nowrap ${activeTab === index ? 'bg-[var(--bg-interactive)] text-[var(--text-highlight)] font-bold' : 'text-[var(--text-secondary)]'}`}
                            >
                                {(file.fileName || 'untitled').split('/').pop()}
                            </button>
                        ))}
                    </div>
                    <div className="flex-grow h-0 relative">
                        <textarea
                            readOnly
                            value={generatedCapsule.files[activeTab]?.content || ''}
                            className="w-full h-full inspector-input bg-[var(--bg-primary)] resize-none"
                        />
                    </div>
                    <button onClick={handleSave} className="button-secondary w-full">
                        Save to Project
                    </button>
                </div>
            )}
        </div>
    );
};

export default ScrollForgePanel;