
import React, { useState } from 'react';
import type { Blueprint } from '../../types';
import { BLUEPRINT_CATEGORIES } from '../../constants';
import Icon from '../icons/Icon';

interface BlueprintHubPanelProps {
    onViewBlueprint: (blueprint: Blueprint) => void;
}

const BlueprintHubPanel: React.FC<BlueprintHubPanelProps> = ({ onViewBlueprint }) => {
    const [activeTab, setActiveTab] = useState(BLUEPRINT_CATEGORIES[0]?.id || '');

    return (
        <div className="flex flex-col h-full text-sm">
            <div className="flex items-center gap-2 pb-4 mb-4 border-b border-[var(--border-primary)]">
                <Icon name="book-open" className="w-5 h-5 text-[var(--text-highlight)]"/>
                <h3 className="panel-header text-lg text-[var(--text-highlight)]">Blueprint Hub</h3>
            </div>
            
            {/* Tab Navigation */}
            <div className="flex-shrink-0 -mx-4 px-2 border-b border-[var(--border-primary)]">
                <div className="flex space-x-1 overflow-x-auto -mb-px">
                    {BLUEPRINT_CATEGORIES.map(category => (
                        <button 
                            key={category.id}
                            onClick={() => setActiveTab(category.id)}
                            className={`px-3 py-2 text-xs font-bold whitespace-nowrap border-b-2 ${
                                activeTab === category.id 
                                ? 'border-[var(--color-accent-primary)] text-[var(--text-highlight)]' 
                                : 'border-transparent text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                            }`}
                        >
                            {category.name}
                        </button>
                    ))}
                </div>
            </div>

            {/* Tab Content */}
            <div className="flex-grow overflow-y-auto pt-4 -mr-4 pr-2">
                {BLUEPRINT_CATEGORIES.map(category => (
                    <div key={category.id} className={activeTab === category.id ? 'block' : 'hidden'}>
                        <div className="grid grid-cols-4 gap-2">
                            {category.blueprints.map(bp => (
                                <button
                                    key={bp.id}
                                    title={bp.name}
                                    onClick={() => onViewBlueprint(bp)}
                                    className="w-full aspect-square bg-[var(--bg-interactive)] rounded-md flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-highlight)] hover:bg-[var(--bg-tertiary)] border-2 border-transparent hover:border-[var(--color-accent-primary)]/50 transition-all duration-200"
                                >
                                    <Icon name={bp.icon} className="w-8 h-8"/>
                                </button>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default BlueprintHubPanel;
