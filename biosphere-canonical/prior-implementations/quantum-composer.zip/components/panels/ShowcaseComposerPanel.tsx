import React, { useState, useEffect } from 'react';
import type { QuantumForgeProject, NarrativeArtifact, ShowcaseCapsule, EcosystemAPIConfig, PerformativeTake, OutputStyleProfile, GenreProfile, CollapsedNarrativeBundle, RealityWeaveTemplate } from '../../types';
import { generateNarrativeArtifact, weaveNarrativeFromBundle } from '../../services/geminiService';
import { OUTPUT_STYLE_PROFILES, REALITY_WEAVE_TEMPLATES } from '../../constants';
import Icon from '../icons/Icon';

interface ShowcaseComposerPanelProps {
    project: QuantumForgeProject;
    onSaveArtifact: (artifact: NarrativeArtifact) => void;
    onSaveCapsule: (capsule: ShowcaseCapsule) => void;
    onUpdateApiConfigs: (configs: EcosystemAPIConfig[]) => void;
    onCreateBundle: (bundle: CollapsedNarrativeBundle) => void;
    onUpdateBundle: (bundle: CollapsedNarrativeBundle) => void;
    activeGenreProfile: GenreProfile | null;
}

type ComposerTab = 'artifacts' | 'weaving';

const ShowcaseComposerPanel: React.FC<ShowcaseComposerPanelProps> = ({ 
    project, onSaveArtifact, onSaveCapsule, onUpdateApiConfigs, 
    onCreateBundle, onUpdateBundle, activeGenreProfile 
}) => {
    const [activeTab, setActiveTab] = useState<ComposerTab>('artifacts');
    const [selectedTake, setSelectedTake] = useState<PerformativeTake | null>(null);
    const [selectedStyle, setSelectedStyle] = useState<OutputStyleProfile>(OUTPUT_STYLE_PROFILES[0]);
    const [isLoading, setIsLoading] = useState(false);
    const [generatedContent, setGeneratedContent] = useState('');
    const [generatedArtifact, setGeneratedArtifact] = useState<NarrativeArtifact | null>(null);

    // Capsule Curation State
    const [selectedArtifactIds, setSelectedArtifactIds] = useState<Set<string>>(new Set());
    
    // Reality Weaving State
    const [selectedBundle, setSelectedBundle] = useState<CollapsedNarrativeBundle | null>(null);
    const [selectedWeaveTemplate, setSelectedWeaveTemplate] = useState<RealityWeaveTemplate>(REALITY_WEAVE_TEMPLATES[0]);
    const [isWeaving, setIsWeaving] = useState(false);

    useEffect(() => {
        if (!selectedTake && project.performativeTakes && project.performativeTakes.length > 0) {
            setSelectedTake(project.performativeTakes[project.performativeTakes.length - 1]);
        }
    }, [project.performativeTakes, selectedTake]);

    const handleGenerateArtifact = async () => {
        if (!selectedTake) return;
        setIsLoading(true);
        setGeneratedContent('');
        setGeneratedArtifact(null);
        try {
            const artifact = await generateNarrativeArtifact(selectedTake, selectedStyle, activeGenreProfile);
            setGeneratedContent(artifact.content);
            setGeneratedArtifact(artifact);
        } catch(e) {
            console.error(e);
            setGeneratedContent("Error generating artifact.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleSaveArtifact = () => {
        if(generatedArtifact) {
            onSaveArtifact(generatedArtifact);
            setGeneratedArtifact(null);
            setGeneratedContent('');
        }
    };
    
    const handleCreateBundle = () => {
      if (!project.observerAuditLog || project.observerAuditLog.length === 0) {
        alert("No observer events to bundle.");
        return;
      }
      const newBundle: CollapsedNarrativeBundle = {
        id: `bundle_${Date.now()}`,
        createdAt: Date.now(),
        sourceProjectId: project.id,
        auditLog: project.observerAuditLog,
      };
      onCreateBundle(newBundle);
      setSelectedBundle(newBundle);
    };
    
    const handleWeaveNarrative = async () => {
        if (!selectedBundle) return;
        setIsWeaving(true);
        try {
            const wovenNarrative = await weaveNarrativeFromBundle(selectedBundle, selectedWeaveTemplate, project);
            const updatedBundle = { ...selectedBundle, wovenNarrative };
            onUpdateBundle(updatedBundle);
            setSelectedBundle(updatedBundle); // Update local state with woven text
        } catch (e) {
            console.error(e);
            alert("Error weaving narrative.");
        } finally {
            setIsWeaving(false);
        }
    };

    const TabButton = ({ id, label, icon }: { id: ComposerTab, label: string, icon: any }) => (
        <button 
            onClick={() => setActiveTab(id)}
            className={`flex items-center gap-2 px-3 py-2 text-xs font-bold transition-colors rounded-t-md ${activeTab === id ? 'bg-[var(--bg-tertiary)]/80 text-[var(--text-highlight)]' : 'bg-transparent text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)]/50'}`}
        >
             <Icon name={icon} className="w-4 h-4" /> {label}
        </button>
    );

    return (
        <div className="p-4 space-y-4 h-full flex flex-col text-sm overflow-y-auto">
            <h3 className="panel-header text-lg text-[var(--text-highlight)] flex items-center gap-2"><Icon name="capsule" className="w-5 h-5" />Showcase Composer</h3>
            
            <div className="flex gap-1 border-b border-[var(--border-primary)]">
                <TabButton id="artifacts" label="Artifact Generator" icon="sparkles" />
                <TabButton id="weaving" label="Quantum Weaving" icon="git-branch" />
            </div>

            {activeTab === 'artifacts' && (
                <>
                    <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 space-y-2">
                        <h4 className="label-text">Generate New Artifact from Take</h4>
                        <select value={selectedTake?.id || ''} onChange={(e) => setSelectedTake(project.performativeTakes?.find(t => t.id === e.target.value) || null)} className="inspector-input">
                            <option value="">Select a Performative Take</option>
                            {project.performativeTakes?.map(take => (
                                <option key={take.id} value={take.id}>Take @ {new Date(take.startTime).toLocaleString()}</option>
                            ))}
                        </select>
                        <select value={selectedStyle.id} onChange={(e) => setSelectedStyle(OUTPUT_STYLE_PROFILES.find(p => p.id === e.target.value) || OUTPUT_STYLE_PROFILES[0])} className="inspector-input">
                            {OUTPUT_STYLE_PROFILES.map(profile => (
                                 <option key={profile.id} value={profile.id}>{profile.name}</option>
                            ))}
                        </select>
                         <button onClick={handleGenerateArtifact} disabled={!selectedTake || isLoading} className="button-secondary w-full disabled:opacity-50">
                            {isLoading ? 'Generating...' : 'Generate Artifact'}
                        </button>
                    </div>
                    
                    {generatedContent && (
                         <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 space-y-2 flex-grow flex flex-col">
                            <h4 className="label-text">Generated Preview</h4>
                            <textarea value={generatedContent} readOnly className="inspector-input flex-grow w-full resize-none"/>
                            <button onClick={handleSaveArtifact} className="button-primary w-full">Save Artifact</button>
                         </div>
                    )}
                </>
            )}

            {activeTab === 'weaving' && (
                 <>
                    <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 space-y-2">
                         <h4 className="label-text">1. Consolidate Reality</h4>
                         <p className="text-xs text-[var(--text-secondary)]">Package the full Observer Audit Log into a single, final narrative bundle.</p>
                         <button onClick={handleCreateBundle} disabled={(project.observerAuditLog || []).length === 0} className="button-secondary w-full disabled:opacity-50">Create Narrative Bundle</button>
                    </div>

                    <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 space-y-2">
                        <h4 className="label-text">2. Weave Final Narrative</h4>
                        <select value={selectedBundle?.id || ''} onChange={(e) => setSelectedBundle(project.collapsedNarrativeBundles?.find(b => b.id === e.target.value) || null)} className="inspector-input">
                            <option value="">Select a Narrative Bundle</option>
                            {project.collapsedNarrativeBundles?.map(bundle => (
                                <option key={bundle.id} value={bundle.id}>Bundle @ {new Date(bundle.createdAt).toLocaleString()}</option>
                            ))}
                        </select>
                         <select value={selectedWeaveTemplate.id} onChange={(e) => setSelectedWeaveTemplate(REALITY_WEAVE_TEMPLATES.find(t => t.id === e.target.value) || REALITY_WEAVE_TEMPLATES[0])} className="inspector-input">
                            {REALITY_WEAVE_TEMPLATES.map(template => (
                                 <option key={template.id} value={template.id}>{template.name}</option>
                            ))}
                        </select>
                        <button onClick={handleWeaveNarrative} disabled={!selectedBundle || isWeaving} className="button-primary w-full disabled:opacity-50">
                            {isWeaving ? 'Weaving...' : 'Weave Narrative with AI'}
                        </button>
                    </div>

                    {selectedBundle?.wovenNarrative && (
                         <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 space-y-2 flex-grow flex flex-col">
                            <h4 className="label-text">Woven Narrative Preview</h4>
                            <textarea value={selectedBundle.wovenNarrative} readOnly className="inspector-input flex-grow w-full resize-none"/>
                         </div>
                    )}
                 </>
            )}
        </div>
    );
};

export default ShowcaseComposerPanel;