// This component is deprecated. Its functionality has been migrated to components/panels/ShowcaseComposerPanel.tsx
const ArtifactComposerPanel = () => null;
export default ArtifactComposerPanel;
