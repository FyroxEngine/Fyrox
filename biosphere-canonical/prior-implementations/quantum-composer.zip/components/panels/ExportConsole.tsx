import React, { useState } from 'react';
import type { QuantumForgeProject, OutputConfig, QuantumForgeNode, CollapsedNarrativeBundle } from '../../types';

interface ExportConsoleProps {
  project: QuantumForgeProject;
}

const ExportConsole: React.FC<ExportConsoleProps> = ({ project }) => {
  const [config, setConfig] = useState<OutputConfig>({
    format: 'markdown',
    includeHidden: false,
  });
  const [output, setOutput] = useState('');
  const [selectedBundleId, setSelectedBundleId] = useState<string | null>(null);

  const generateMarkdown = () => {
    let md = `# ${project.name}\n\n`;
    md += `> ${project.description}\n\n`;

    // A simple topological sort could go here for ordering
    project.nodeGraph.nodes.forEach(node => {
      md += `## ${node.label} (Type: ${node.type})\n\n`;
      if (node.quantumState?.outcomes?.length > 0) {
        if (node.quantumState.collapsed) {
           md += `${node.quantumState.outcomes[0].content}\n\n`;
        } else {
           md += `**Possible Outcomes:**\n`;
           node.quantumState.outcomes.forEach(outcome => {
                md += `- (P: ${Math.round(outcome.probability * 100)}%) ${outcome.content}\n`;
           });
           md += `\n`;
        }
      }
      const connections = project.nodeGraph.connections.filter(c => c.fromNodeId === node.id);
      if(connections.length > 0) {
        md += `**Connections:**\n`;
        connections.forEach(c => {
            const toNode = project.nodeGraph.nodes.find(n => n.id === c.toNodeId);
            md += `- Connects to: ${toNode?.label || c.toNodeId}\n`;
        });
        md += `\n`;
      }
    });
    setOutput(md);
  };

  const generateJson = () => {
    setOutput(JSON.stringify(project, null, 2));
  };
  
  const handleGenerate = () => {
    if (config.format === 'markdown') {
        generateMarkdown();
    } else {
        generateJson();
    }
  }
  
  const handleDownload = () => {
    const blob = new Blob([output], { type: config.format === 'json' ? 'application/json' : 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.name.replace(/\s+/g, '_')}.${config.format}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadBundle = () => {
    const bundle = project.collapsedNarrativeBundles?.find(b => b.id === selectedBundleId);
    if (!bundle) return;

    const bundleJson = JSON.stringify(bundle, null, 2);
    const blob = new Blob([bundleJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bundle_${project.name.replace(/\s+/g, '_')}_${bundle.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };


  return (
    <div className="p-4 space-y-4 h-full flex flex-col">
      <h3 className="panel-header">Export Console</h3>

      <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 space-y-2">
        <h4 className="label-text">Export Collapsed Narrative Bundle</h4>
        <select
          value={selectedBundleId || ''}
          onChange={e => setSelectedBundleId(e.target.value)}
          className="inspector-input"
        >
            <option value="">Select a Woven Reality...</option>
            {project.collapsedNarrativeBundles?.map(b => (
                <option key={b.id} value={b.id}>
                    Bundle @ {new Date(b.createdAt).toLocaleTimeString()}
                </option>
            ))}
        </select>
         <button onClick={handleDownloadBundle} disabled={!selectedBundleId} className="button-primary w-full disabled:opacity-50">
            Download Bundle (JSON)
        </button>
      </div>

      <div className="border border-[var(--border-primary)] rounded-lg p-3 bg-[var(--bg-tertiary)]/50 space-y-2 flex-grow flex flex-col">
        <h4 className="label-text">Export Full Project</h4>
        <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-[var(--text-secondary)]">Format</label>
              <select
                value={config.format}
                onChange={e => setConfig({ ...config, format: e.target.value as any })}
                className="inspector-input"
              >
                <option value="markdown">Markdown</option>
                <option value="json">JSON Bundle</option>
              </select>
            </div>
        </div>
        <button onClick={handleGenerate} className="button-secondary w-full">Generate Preview</button>
        <div className="flex-grow h-0 relative mt-2">
             <textarea
                readOnly
                value={output}
                className="w-full h-full inspector-input bg-[var(--bg-primary)] resize-none"
                placeholder="Generated output will appear here..."
            />
        </div>
        <button onClick={handleDownload} disabled={!output} className="button-secondary w-full disabled:opacity-50 mt-2">
            Download Preview File
        </button>
      </div>
    </div>
  );
};

export default ExportConsole;