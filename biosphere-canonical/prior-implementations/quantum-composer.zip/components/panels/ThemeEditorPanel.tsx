
import React, { useRef } from 'react';
import type { Theme, CustomThemeConfig } from '../../types';
import { THEMES } from '../../constants';
import Icon from '../icons/Icon';

interface ThemeEditorPanelProps {
  currentTheme: Theme;
  onSetTheme: (theme: Theme) => void;
  customConfig: CustomThemeConfig;
  onSetConfig: (config: CustomThemeConfig) => void;
}

const ThemeEditorPanel: React.FC<ThemeEditorPanelProps> = ({ currentTheme, onSetTheme, customConfig, onSetConfig }) => {
  const bgInputRef = useRef<HTMLInputElement>(null);
  const panelInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'bg' | 'panel') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === 'bg') {
          onSetConfig({ ...customConfig, bgOverlay: reader.result as string });
        } else {
          onSetConfig({ ...customConfig, panelOverlay: reader.result as string });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="p-4 space-y-6">
      <div>
        <h3 className="panel-header">Select Theme</h3>
        <div className="grid grid-cols-3 gap-2 mt-2">
          {THEMES.map(theme => (
            <button
              key={theme.id}
              onClick={() => onSetTheme(theme.id)}
              className={`p-2 rounded-md border-2 text-left transition-all ${
                currentTheme === theme.id ? 'border-[var(--color-accent-primary)] bg-[var(--color-accent-primary)]/20' : 'border-transparent bg-[var(--bg-interactive)] hover:border-[var(--text-highlight)]/50'
              }`}
            >
              <span className="text-xs font-bold">{theme.name}</span>
            </button>
          ))}
        </div>
      </div>
      <div>
        <h3 className="panel-header">Custom Skins</h3>
        <div className="space-y-3 mt-2">
          <div>
            <label className="text-sm font-bold text-[var(--text-secondary)]">Background Overlay</label>
            <input
              type="file"
              ref={bgInputRef}
              accept="image/png"
              onChange={e => handleFileUpload(e, 'bg')}
              className="hidden"
            />
            <button onClick={() => bgInputRef.current?.click()} className="button-secondary w-full mt-1">
              Upload PNG
            </button>
             {customConfig.bgOverlay && <button onClick={() => onSetConfig({...customConfig, bgOverlay: ''})} className="button-danger w-full mt-1">Clear</button>}
          </div>
          <div>
            <label className="text-sm font-bold text-[var(--text-secondary)]">Panel Overlay</label>
            <input
              type="file"
              ref={panelInputRef}
              accept="image/png"
              onChange={e => handleFileUpload(e, 'panel')}
              className="hidden"
            />
            <button onClick={() => panelInputRef.current?.click()} className="button-secondary w-full mt-1">
              Upload PNG
            </button>
            {customConfig.panelOverlay && <button onClick={() => onSetConfig({...customConfig, panelOverlay: ''})} className="button-danger w-full mt-1">Clear</button>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThemeEditorPanel;