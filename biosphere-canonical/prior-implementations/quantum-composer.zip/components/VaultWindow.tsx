// This component is deprecated and no longer in use.
// The floating window system has been replaced by a fixed layout with sliding panels.
const VaultWindow = () => null;
export default VaultWindow;
