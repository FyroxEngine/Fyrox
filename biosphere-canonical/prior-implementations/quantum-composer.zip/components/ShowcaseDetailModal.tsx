
import React from 'react';
import type { LegacyShowcaseArtifact } from '../types';
import Icon from './icons/Icon';

interface ShowcaseDetailModalProps {
    showcase: LegacyShowcaseArtifact;
    onClose: () => void;
}

const ShowcaseDetailModal: React.FC<ShowcaseDetailModalProps> = ({ showcase, onClose }) => {
    return (
        <div onClick={onClose} className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div onClick={e => e.stopPropagation()} className="bg-[var(--bg-secondary)] w-full max-w-lg rounded-lg border border-[var(--border-primary)] flex flex-col shadow-2xl shadow-[var(--shadow-color)]">
                <div className="px-6 py-4 border-b border-[var(--border-primary)] flex items-center justify-between">
                     <div className="flex items-center gap-3">
                        <Icon name="showcase" className="w-6 h-6 text-[var(--text-highlight)]" />
                        <h2 className="text-xl font-bold text-[var(--text-highlight)]">Showcase Details</h2>
                    </div>
                    <button onClick={onClose} className="p-2 -mr-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-full hover:bg-[var(--bg-interactive)]">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>
                <div className="p-6 space-y-4">
                    <div>
                        <label className="text-sm font-bold text-[var(--text-secondary)]">Title</label>
                        <p className="text-lg text-[var(--text-primary)]">{showcase.title}</p>
                    </div>
                     <div>
                        <label className="text-sm font-bold text-[var(--text-secondary)]">Created At</label>
                        <p className="text-[var(--text-primary)]">{new Date(showcase.timestamp).toLocaleString()}</p>
                    </div>
                     <div>
                        <label className="text-sm font-bold text-[var(--text-secondary)]">Node Count</label>
                        <p className="text-[var(--text-primary)]">{showcase.graphSnapshot.nodes.length}</p>
                    </div>
                     <div>
                        <label className="text-sm font-bold text-[var(--text-secondary)]">Source Chronicle ID</label>
                        <p className="text-xs font-mono text-[var(--text-primary)]">{showcase.sourceChronicleId}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ShowcaseDetailModal;
