import React, { useState } from 'react';
import type { QuantumForgeProject, QuantumForgeNodeUpdate, ContextMenuState, IconName, Zone, MediaAsset, GestureInput, AnimationState, GenreProfile, QuantumOutcome } from '../types';
import NodeCanvas from './NodeCanvas';
import QuantumQuillCanvas from './QuantumQuillCanvas';
import Minimap from './Minimap';
import { ActiveView } from '../../App';

interface WorkspaceProps {
    project: QuantumForgeProject;
    onUpdateProject: (updatedProject: QuantumForgeProject) => void;
    selectedNodeIds: string[];
    onSelectNodes: (ids: string[]) => void;
    selectedZoneId: string | null;
    onSelectZone: (id: string | null) => void;
    setContextMenu: (menu: ContextMenuState | null) => void;
    onAddNode: (type: string, position: { x: number; y: number }, icon: IconName, mediaAsset?: MediaAsset) => void;
    onUpdateNodes: (nodeUpdates: QuantumForgeNodeUpdate[]) => void;
    onUpdateZone: (zone: Zone) => void;
    mediaAssets: MediaAsset[];
    activeView: ActiveView;
    animationState: AnimationState;
    onGesture: (gesture: GestureInput) => void;
    recordingState: 'idle' | 'recording' | 'paused';
    onStartRecording: () => void;
    onStopRecording: () => void;
    activeGenreProfile: GenreProfile | null;
    performanceSuggestion: string;
    onGetSuggestion: () => void;
    onCollapseNode: (nodeId: string) => void;
    lastGesture: GestureInput | null;
    effectiveProbabilities: Map<string, QuantumOutcome[]>;
}

const Workspace: React.FC<WorkspaceProps> = (props) => {
  const { 
    project, activeGenreProfile, activeView, onGesture,
    recordingState, onStartRecording, onStopRecording,
    performanceSuggestion, onGetSuggestion, onCollapseNode, lastGesture, effectiveProbabilities
  } = props;
  
  const [view, setView] = useState({ x: 0, y: 0, zoom: 1 });

  const isPerformMode = activeView === 'quantumquill';

  const genreStyle = activeGenreProfile?.performativeStylings || null;

  return (
    <div className="flex flex-col h-full w-full gap-4 overflow-hidden relative">
        <div 
          className="w-full h-full relative"
          style={{
              border: genreStyle ? `4px solid ${genreStyle.borderColor}` : 'none',
              transition: 'border-color 0.5s ease-in-out',
          }}
        >
            {genreStyle && (
              <div 
                className="absolute inset-0 pointer-events-none -z-1"
                style={{ 
                    backgroundColor: genreStyle.overlayColor,
                    transition: 'background-color 0.5s ease-in-out',
                }}
              />
            )}
            <NodeCanvas {...props} selectedIds={props.selectedNodeIds} view={view} setView={setView} isPerformMode={isPerformMode} effectiveProbabilities={effectiveProbabilities} />
        </div>
        <Minimap project={project} view={view} setView={setView} />
        {isPerformMode && (
            <QuantumQuillCanvas 
                project={project} 
                onGesture={onGesture} 
                recordingState={recordingState}
                onStartRecording={onStartRecording}
                onStopRecording={onStopRecording}
                suggestion={performanceSuggestion}
                onGetSuggestion={onGetSuggestion}
                onCollapseNode={onCollapseNode}
                nodes={project.nodeGraph.nodes}
                lastGesture={lastGesture}
                selectedNodeIds={props.selectedNodeIds}
            />
        )}
    </div>
  );
};

export default Workspace;
