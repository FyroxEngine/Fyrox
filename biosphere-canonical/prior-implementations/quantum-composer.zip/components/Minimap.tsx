import React, { useRef, useEffect } from 'react';
import type { QuantumForgeProject } from '../types';

interface MinimapProps {
    project: QuantumForgeProject;
    view: { x: number; y: number; zoom: number };
    setView: React.Dispatch<React.SetStateAction<{ x: number; y: number; zoom: number }>>;
}

const Minimap: React.FC<MinimapProps> = ({ project, view, setView }) => {
    const mapRef = useRef<HTMLDivElement>(null);
    const isDragging = useRef(false);

    const nodes = project.nodeGraph.nodes;
    const zones = project.zones || [];
    
    if (nodes.length === 0 && zones.length === 0) {
        return null;
    }

    const nodeBounds = nodes.map(n => ({ x: n.position.x, y: n.position.y, width: 180, height: 80 }));
    const zoneBounds = zones.map(z => z.rect);
    const allBounds = [...nodeBounds, ...zoneBounds];

    const bounds = allBounds.reduce((acc, el) => {
        return {
            minX: Math.min(acc.minX, el.x),
            minY: Math.min(acc.minY, el.y),
            maxX: Math.max(acc.maxX, el.x + el.width),
            maxY: Math.max(acc.maxY, el.y + el.height),
        };
    }, { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity });

    const contentWidth = bounds.maxX - bounds.minX;
    const contentHeight = bounds.maxY - bounds.minY;

    if(contentWidth <= 0 || contentHeight <= 0) return null;

    const mapSize = 150; // pixels
    const scaleX = mapSize / contentWidth;
    const scaleY = mapSize / contentHeight;
    const scale = Math.min(scaleX, scaleY) * 0.9;
    
    const mapWidth = contentWidth * scale;
    const mapHeight = contentHeight * scale;

    const clientToView = (clientX: number, clientY: number) => {
        if (!mapRef.current) return;
        const mapRect = mapRef.current.getBoundingClientRect();
        const x = (clientX - mapRect.left) / mapWidth;
        const y = (clientY - mapRect.top) / mapHeight;
        
        const canvasRect = mapRef.current.parentElement?.parentElement?.querySelector('.w-full.h-full.bg-\\[var\\(--bg-secondary\\)\\]')?.getBoundingClientRect();
        const canvasWidth = canvasRect?.width || window.innerWidth;
        const canvasHeight = canvasRect?.height || window.innerHeight;

        // Center the view on the clicked point
        setView(v => ({...v, x: -x * contentWidth * v.zoom + canvasWidth/2, y: -y * contentHeight * v.zoom + canvasHeight/2 }))
    }

    const handleMouseDown = (e: React.MouseEvent) => {
        isDragging.current = true;
        clientToView(e.clientX, e.clientY);
    };

    const handleMouseMove = (e: React.MouseEvent) => {
        if(isDragging.current) {
            clientToView(e.clientX, e.clientY);
        }
    };
    
    const handleMouseUp = () => { isDragging.current = false };


    return (
        <div className="absolute bottom-4 right-4 bg-[var(--bg-tertiary)]/70 backdrop-blur-md border-2 border-[var(--border-primary)] rounded-lg shadow-lg overflow-hidden" style={{ width: mapWidth + 4, height: mapHeight + 4 }}>
            <div 
                ref={mapRef}
                className="relative w-full h-full cursor-pointer"
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                style={{transform: 'translate(2px, 2px)'}}
            >
                {/* Zones */}
                {zones.map(zone => (
                    <div
                        key={zone.id}
                        className="absolute"
                        style={{
                            left: (zone.rect.x - bounds.minX) * scale,
                            top: (zone.rect.y - bounds.minY) * scale,
                            width: zone.rect.width * scale,
                            height: zone.rect.height * scale,
                            backgroundColor: zone.color,
                        }}
                    />
                ))}
                
                {/* Nodes */}
                {nodes.map(node => (
                    <div
                        key={node.id}
                        className="absolute bg-[var(--text-highlight)] rounded-sm opacity-70"
                        style={{
                            left: (node.position.x - bounds.minX) * scale,
                            top: (node.position.y - bounds.minY) * scale,
                            width: 180 * scale,
                            height: 100 * scale,
                        }}
                    />
                ))}

                 {/* Viewport Rectangle */}
                <div 
                    className="absolute border border-white/80 pointer-events-none"
                    style={{
                        width: window.innerWidth / view.zoom * scale,
                        height: window.innerHeight / view.zoom * scale,
                        left: (-view.x / view.zoom - bounds.minX) * scale,
                        top: (-view.y / view.zoom - bounds.minY) * scale,
                    }}
                />
            </div>
        </div>
    );
};

export default Minimap;