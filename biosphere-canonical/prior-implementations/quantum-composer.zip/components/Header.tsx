import React from 'react';
import Icon from './icons/Icon';
import { ActiveView } from '../../App';

interface HeaderProps {
  onNewProjectClick: () => void;
  activeView: ActiveView;
  onToggleView: (view: ActiveView) => void;
}

const Header: React.FC<HeaderProps> = ({ onNewProjectClick, activeView, onToggleView }) => {
  return (
    <header style={{ height: '10vh' }} className="flex-shrink-0 px-4 flex items-center justify-between bg-[var(--bg-primary)] border-b border-[var(--border-primary)] z-40 panel-overlay-bg">
      <div className="flex items-center gap-2">
        <Icon name="cubes" className="w-6 h-6 text-[var(--text-highlight)]" />
        <h1 className="text-xl font-bold text-[var(--text-primary)] tracking-wider">Quantum Forge</h1>
      </div>
      
      <div className="absolute left-1/2 -translate-x-1/2">
        <div className="flex items-center bg-[var(--bg-secondary)] p-1 rounded-lg border border-[var(--border-primary)]">
            <button
                onClick={() => onToggleView('quantumforge')}
                className={`px-3 py-1 text-sm rounded-md transition-colors ${activeView === 'quantumforge' ? 'bg-[var(--color-accent-primary)] text-white' : 'text-[var(--text-secondary)] hover:bg-[var(--bg-interactive)]'}`}
            >
                Quantum Forge
            </button>
            <button
                onClick={() => onToggleView('quantumquill')}
                className={`px-3 py-1 text-sm rounded-md transition-colors ${activeView === 'quantumquill' ? 'bg-[var(--color-accent-primary)] text-white' : 'text-[var(--text-secondary)] hover:bg-[var(--bg-interactive)]'}`}
            >
                Quantum Quill
            </button>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <button onClick={onNewProjectClick} className="flex items-center gap-2 text-sm px-3 py-1.5 rounded-md bg-[var(--bg-interactive)] hover:bg-[var(--bg-tertiary)] transition-colors">
          <Icon name="plus" className="w-4 h-4" />
          New Project
        </button>
      </div>
    </header>
  );
};

export default Header;