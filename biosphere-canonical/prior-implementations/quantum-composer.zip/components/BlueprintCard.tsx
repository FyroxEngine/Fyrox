// This component is deprecated and no longer needed.
// The Blueprint Hub now uses an integrated, icon-based grid.
const BlueprintCard = () => null;
export default BlueprintCard;
