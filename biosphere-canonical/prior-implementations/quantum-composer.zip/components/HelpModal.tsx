
import React from 'react';
import Icon from './icons/Icon';
import { HELP_CONTENT } from '../constants';

interface HelpModalProps {
    onClose: () => void;
}

const HelpModal: React.FC<HelpModalProps> = ({ onClose }) => {
    return (
        <div 
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        >
            <div 
                onClick={e => e.stopPropagation()}
                className="bg-[var(--bg-secondary)] w-full max-w-3xl h-full max-h-[80vh] rounded-lg border border-[var(--border-primary)] flex flex-col shadow-2xl shadow-[var(--shadow-color)]"
            >
                <div className="px-6 py-4 border-b border-[var(--border-primary)] flex items-center justify-between flex-shrink-0">
                    <div className="flex items-center gap-3">
                        <Icon name="help-circle" className="w-6 h-6 text-[var(--text-highlight)]" />
                        <h2 className="text-xl font-bold text-[var(--text-highlight)]">Help & Documentation</h2>
                    </div>
                    <button onClick={onClose} className="p-2 -mr-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-full hover:bg-[var(--bg-interactive)]">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>
                <div className="flex-grow p-6 overflow-y-auto text-[var(--text-primary)] space-y-6">
                    {HELP_CONTENT.map(section => (
                         <HelpSection key={section.id} title={section.title} content={section.content} />
                    ))}
                </div>
            </div>
        </div>
    );
};

const HelpSection: React.FC<{title: string, content: string}> = ({title, content}) => (
    <div>
        <h3 className="text-lg font-bold text-[var(--text-highlight)] border-b border-[var(--border-primary)] pb-2 mb-2">{title}</h3>
        <div 
            className="text-[var(--text-secondary)] space-y-2 prose prose-invert prose-sm max-w-none"
            dangerouslySetInnerHTML={{ __html: content }}
        />
    </div>
);

export default HelpModal;