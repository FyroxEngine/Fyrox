import React from 'react';
import type { QuantumForgeProject } from '../types';
import Icon from './icons/Icon';

interface VaultCardProps {
  project: QuantumForgeProject;
  onSelect: (project: QuantumForgeProject) => void;
  onDelete: (id: string) => void;
}

const VaultCard: React.FC<VaultCardProps> = ({ project, onSelect, onDelete }) => {
  const { name, description, icon, tags } = project;

  const handleDelete = (e: React.MouseEvent) => {
      e.stopPropagation();
      onDelete(project.id);
  }

  return (
    <div
      onClick={() => onSelect(project)}
      className="group relative bg-[var(--bg-tertiary)]/50 backdrop-blur-md border border-[var(--border-primary)] rounded-lg p-5 flex flex-col h-full transition-all duration-300 hover:border-[var(--text-highlight)]/40 hover:bg-[var(--bg-tertiary)] hover:shadow-2xl hover:shadow-[var(--shadow-color)] cursor-pointer"
    >
      <div className="flex-grow flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="w-10 h-10 flex items-center justify-center bg-[var(--bg-interactive)]/50 rounded-lg">
            <Icon name={icon} className="w-6 h-6 text-[var(--text-highlight)]" />
          </div>
          <button onClick={handleDelete} className="text-slate-500 hover:text-[var(--color-accent-primary)] transition-colors opacity-0 group-hover:opacity-100" title="Delete Project">
            <Icon name="trash" className="w-5 h-5" />
          </button>
        </div>
        
        {/* Body */}
        <div className="my-4 flex-grow">
          <h3 className="text-2xl font-bold text-[var(--text-highlight)] group-hover:text-[var(--text-primary)] transition-colors">{name}</h3>
          <p className="text-[var(--text-secondary)] mt-1 text-sm h-10">{description}</p>
        </div>
        
        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          {tags.map(tag => (
            <span key={tag} className="px-2 py-0.5 bg-[var(--bg-interactive)]/50 text-[var(--text-highlight)]/80 text-xs rounded-full">
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VaultCard;