// V12 Architecture: Quantum Composer & Quantum Quill

// --- Core UI & Layout ---
export type Theme = 
  'theme-default-dark' | 'theme-cyber-minimalist' | 'theme-vintage-paper' | 
  'theme-ancient-relic' | 
  /* Visionary Themes */
  'theme-neural-narrative-designer' | 'theme-void-hunter' | 
  'theme-shadow-illusionist' | 'theme-spellwright' | 'theme-dream-cartographer' |
  'theme-synesthetic-architect' | 'theme-fractal-artisan' | 'theme-dream-sequencer' |
  'theme-arcane-weather-weaver' | 'theme-celestial-navigator';

export interface ContextMenuState {
  x: number;
  y: number;
  type: 'canvas' | 'node' | 'zone';
  canvasX?: number;
  canvasY?: number;
  nodeId?: string;
  zoneId?: string;
}

export type LeftPanelTab = 'library' | 'plugins' | 'media' | 'lore' | 'linking' | 'genre' | 'genesis' | 'scrollforge';
export type RightPanelTab = 'inspector' | 'export' | 'showcase';

// --- Theme & Customization ---
export interface ThemeConfig {
  id: Theme;
  name: string;
  description: string;
  motifs: string[];
  stylePackPath?: string;
}

export interface CustomThemeConfig {
  bgOverlay: string;
  panelOverlay: string;
}

// --- Blueprint & Roadmap ---
export type CellStatus = 'locked' | 'in-progress' | 'sub-phase' | 'completed';

export interface RoadmapCellState {
  status: CellStatus;
}

export interface RoadmapState {
  [layerId: string]: {
    [versionKey: string]: {
      [phaseKey: string]: RoadmapCellState;
    };
  };
}

export interface BlueprintRoadmapData {
    layerId: string;
    layerName: string;
    versions: Record<string, Record<string, string>>;
}


export interface Blueprint {
    id: string;
    name: string;
    icon: IconName;
    description: string;
    content: string;
    roadmap?: BlueprintRoadmapData;
}

export interface BlueprintCategory {
    id: string;
    name: string;
    blueprints: Blueprint[];
}


// --- Foundational Narrative & Lore Types ---

export interface Trait {
  id: string;
  name: string;
  description: string;
  icon: IconName;
  color: string;
}

export interface SymbolGlyph {
  id: string;
  name: string;
  description: string;
  // Future: svg path, visual properties
}

export interface TraitRegistry {
  id: string;
  name: string;
  traits: Trait[];
}

export interface SymbolRegistry {
  id: string;
  name: string;
  symbols: SymbolGlyph[];
}

export interface QuillGestureMap {
  id: string;
  name: string;
  gesturePattern: any; // To be defined: e.g., series of points, velocity thresholds
  targetNodeId: string;
  action: 'trigger' | 'modify_attribute';
  parameters?: Record<string, any>;
}

// --- Showcase, Capsules & Remixing ---

export interface CurationMetadata {
  title: string;
  author: string;
  tags: string[];
  description: string;
}

export interface RemixLayer {
  notes: string;
}

export interface ShowcaseCapsule {
  id: string;
  metadata: CurationMetadata;
  remixLayer: RemixLayer;
  narrativeArtifactIds: string[];
  sourceProject: {
    id: string;
    name: string;
  };
  // V1 Manual additions
  linkedBloomEvents?: string[];
  emotionalSignature?: Trait[];
  symbolPalette?: string[];
  compositionStyle?: 'poetic' | 'abstract' | 'technical' | 'surreal';
  ambientLayer?: string;
}

// --- Dynamic Probabilities ---
export interface SignalModulationCurve {
    signalSource: 'control' | 'gesture'; // The type of input signal
    sourceId: string; // e.g., a ControlElement ID
    strength: number; // 0 to 1, how strongly it affects probabilities
}


// --- Ecosystem & Collaboration ---
export interface StudioShell {
    id: string;
    name: string;
    description: string;
    url?: string; // e.g., an IP address or connection URI
    status: 'online' | 'offline' | 'pending';
}

export enum RitualTriggerType {
    Gesture = 'gesture',
    SymbolEvent = 'symbolEvent',
    TraitSpike = 'traitSpike',
}

export enum RitualEchoMode {
    Sync = 'sync', // All shells react simultaneously
    Ripple = 'ripple', // Shells react in a delayed sequence
    Resonate = 'resonate', // Effect amplifies across shells
    CallAndResponse = 'callAndResponse', // One shell triggers a different action in another
}

export interface RitualLink {
    id: string;
    name: string;
    triggerType: RitualTriggerType;
    sourceShellId: string; // 'any' or a specific shell ID
    targetShellIds: string[];
    echoMode: RitualEchoMode;
    enabled: boolean;
}

export interface EcosystemAPIConfig {
    id: string;
    name: string;
    targetPlatform: 'Game Engine' | 'Web Stream' | 'Custom API';
    url: string;
    apiKey?: string;
    format: 'json' | 'xml';
}

// --- V14: Agents ---
export interface ReflexModulationPath {
    agentId: string;
    memoryLog: ChronicleEntry[];
    modulationRules?: string[];
    overrideTrigger?: string;
}

export interface AgentChain {
    ensembleId: string;
    agents: string[];
    interactionBias?: string;
    resonanceStack?: string[];
}

// --- V15: Ambient Expression ---
export interface AmbientExpressionMap {
    traitModulation?: Trait[];
    rhythmFactor?: number;
    visualRhythmProfile?: string;
    symbolPulseCurve?: number[];
    glowTriggerEvents?: string[];
}
export interface MotionGlyph {
    symbolId: string;
    driftCurve?: number[];
    gestureBindings?: string[];
    feedbackTone?: string;
}

// --- V16: Symbol Fusion ---
export interface MetaSymbolDefinition {
    symbolId: string;
    sourceGlyphs: string[];
    fusionRule?: string; // logic condition
    paradoxCondition?: string;
    thematicProfile?: string;
}

// --- V17: Archives & Replay ---
export interface MemoryArchive {
    archiveId: string;
    capsuleLog: ShowcaseCapsule[];
    traitTrajectory?: Trait[];
    echoHighlights?: string[];
    remixReady: boolean;
}
export interface ReplayPackage {
    packageId: string;
    loopSignalThreads: string[];
    highlightMoments?: string[];
    remixOverlays?: string[];
    traitRhythmMap?: Trait[];
}

// --- V18: Performance Toolkits ---
export interface ControlUnit { // Placeholder
    id: string;
    type: string;
}
export interface ControlSurfaceDefinition {
    surfaceId: string;
    mappedControls: ControlUnit[];
    signalBindings?: string[];
    gestureModifiers?: string[];
}

// --- V19: Co-Performance ---
export interface CoPerformSession {
    sessionId: string;
    performers: string[];
    agentProfiles?: string[];
    sceneSync: boolean;
    gestureOverlayMode?: string;
    capsuleNarrationKit?: string[];
}

// --- Dynamic Genre Infusion ---
export interface GenreProfile {
    id: string;
    name: string;
    description: string;
    performativeStylings: {
        overlayColor: string; // e.g., 'rgba(255, 0, 255, 0.1)'
        borderColor: string; // e.g., '#ff00ff'
    };
    symbolicMotifs: string[];
    systemInstruction: string;
}

// --- Algorithmic Narrative Genesis ---
export interface MythicArchetype {
    id: string;
    name: string;
    description: string;
    thematicTraits: string[];
}

export interface NarrativeSeed {
    id: string;
    name: string;
    genreProfileId: string;
    mythicArchetypeId: string;
    corePrompt: string;
}

export interface EvolutionaryAlgorithmConfig {
    stability: number; // 0.0 (highly creative) to 1.0 (highly stable)
}

export interface ProceduralScene {
    title: string;
    description: string;
    keyEvent: string;
}

export interface ProceduralArc {
    title: string;
    scenes: ProceduralScene[];
}

// --- Quantum Narrative Superposition ---
export interface QuantumOutcome {
  probability: number; // 0.0 to 1.0
  content: string;
}

export interface QuantumNarrativeState {
  collapsed: boolean;
  outcomes: QuantumOutcome[];
}

export interface ObserverAuditLogEntry {
    id: string;
    timestamp: number;
    collapsedNodeId: string;
    chosenOutcome: QuantumOutcome;
    allOutcomes: QuantumOutcome[];
}

// --- Quantum Outcome Consolidation ---
export interface CollapsedNarrativeBundle {
    id: string;
    createdAt: number;
    sourceProjectId: string;
    auditLog: ObserverAuditLogEntry[];
    wovenNarrative?: string; // The final text generated by the Reality Weave
}

export interface RealityWeaveTemplate {
    id: string;
    name: string;
    description: string;
    systemInstruction: string;
}

// --- Node Graph ---
export type PortType = 'data' | 'trigger' | 'any';
export interface Port {
  id: string;
  name: string;
  type: PortType;
}

export interface QuantumComposerNode {
  id:string;
  label: string;
  type: string;
  icon: IconName;
  inputs: Port[];
  outputs: Port[];
  position: { x: number; y: number };
  attributes?: Record<string, any>;
  isSelected?: boolean;
  aiConfig?: AINodeConfig;
  mediaAssetId?: string;
  category?: 'text' | 'ai' | 'logic' | 'media';
  quantumState: QuantumNarrativeState;
  // Manual additions
  traitIds?: string[];
  symbolIds?: string[];
}

export type QuantumComposerNodeUpdate = Partial<Omit<QuantumComposerNode, 'id'>> & { id: string };

export interface Connection {
  id:string;
  fromNodeId: string;
  fromPortId: string;
  toNodeId: string;
  toPortId: string;
}

export interface NodeGraph {
  nodes: QuantumComposerNode[];
  connections: Connection[];
}

export interface Zone {
  id: string;
  label: string;
  rect: { x: number; y: number; width: number; height: number };
  color: string;
  symbolism?: string;
  resonanceField?: SignalModulationCurve;
}

// --- ScrollForge ---
export interface ScrollCapsuleFile {
  fileName: string;
  content: string;
}

export interface ScrollCapsule {
  id: string;
  createdAt: number;
  sourceText: string;
  files: ScrollCapsuleFile[];
}

// --- Project & Plugins ---
export interface ControlElement {
  id: string;
  label: string;
  type: 'fader' | 'knob' | 'switch';
  value: number;
  targetNodeId: string;
  targetAttribute: string;
  linkedResonanceFieldId?: string;
}

export interface QuantumComposerProject {
  id: string;
  name: string;
  description: string;
  icon: IconName;
  nodeGraph: NodeGraph;
  isTemplate?: boolean;
  tags: string[];
  createdAt: number;
  updatedAt: number;
  plugins?: QuantumComposerProject[];
  controls?: ControlElement[];
  zones?: Zone[];
  intent?: string;
  traitRegistry: TraitRegistry;
  symbolRegistry: SymbolRegistry;
  quillGestureMaps?: QuillGestureMap[];
  performativeTakes?: PerformativeTake[];
  narrativeArtifacts?: NarrativeArtifact[];
  showcaseCapsules?: ShowcaseCapsule[];
  linkedShells?: StudioShell[];
  ritualLinks?: RitualLink[];
  apiConfigs?: EcosystemAPIConfig[];
  activeGenreProfileId?: string | null;
  mythicArchetypes?: MythicArchetype[];
  narrativeSeeds?: NarrativeSeed[];
  observerAuditLog?: ObserverAuditLogEntry[];
  collapsedNarrativeBundles?: CollapsedNarrativeBundle[];
  roadmapState?: RoadmapState;
  scrollCapsules?: ScrollCapsule[];
  lastUpdatedNodeId?: string;
  lastUpdateTime?: number;
}

// --- Live Performance & Artifacts ---

export interface GestureInput {
  x: number;
  y: number;
  type: 'move' | 'press' | 'release';
}

export interface AnimationPulse {
  id: string;
  targetId: string;
  type: 'port-glow' | 'trait-pulse';
  startTime: number;
  duration: number;
  delay?: number;
}

export interface AnimationState {
  pulses: AnimationPulse[];
}

export interface SignalHistoryLogEntry {
  timestamp: number;
  type: 'gesture' | 'node_update' | 'trait_change' | 'system' | 'collapse';
  payload: any;
  description: string;
}

export interface PerformativeTake {
  id: string;
  startTime: number;
  endTime: number;
  signalLog: SignalHistoryLogEntry[];
}

export interface NarrativeArtifact {
  id: string;
  title: string;
  generatedAt: number;
  sourceTakeId: string;
  styleProfileId: string;
  content: string;
}

export interface OutputStyleProfile {
  id: string;
  name: string;
  description: string;
  systemInstruction: string;
}

// --- AI & Language Models ---
export interface LLMConfig {
  id: string;
  name: string;
  provider: 'google' | 'openai' | 'local';
  modelId: string;
  url?: string;
  apiKey?: string;
}

export interface AINodeConfig {
  modelId: string;
  promptTemplate: string;
}

// --- Media & Exporting ---
export interface MediaAsset {
  id: string;
  name:string;
  type: 'image' | 'audio' | 'video' | 'model' | 'document';
  path: string;
  tags: string[];
}

// --- Miscellaneous & Manual Types ---
export interface HelpSection {
  id: string;
  title: string;
  content: string;
}

export interface Archetype {
  id: string;
  name: string;
  description: string;
}

export interface VisualEffectManifest {
    categoryColors: {
        text: string;
        ai: string;
        logic: string;
        media: string;
        default: string;
    };
}

export interface LegacyShowcaseArtifact {
  title: string;
  timestamp: number;
  graphSnapshot: NodeGraph;
  sourceChronicleId: string;
}

export interface OutputConfig {
  format: 'markdown' | 'json';
  includeHidden: boolean;
}

export interface NarrativeDraftConfig {
  draftStyle: 'mythic' | 'poetic' | 'minimalist' | 'surreal' | 'cinematic';
  traitInfluenceCurve: any;
  sceneSequenceMap: any;
  symbolicPalette: string[];
  narratorAgent: string;
}

export interface TutorialPack {
  tutorialId: string;
  title: string;
  skillLevel: 'beginner' | 'intermediate' | 'advanced';
  linkedPhase?: string;
  requiredTraits?: Trait[];
  symbolsFeatured?: string[];
  guidanceSteps: string[];
  remixableSceneStarter?: string;
}

export interface PluginManifest {
  pluginId: string;
  title: string;
  extensionHooks: string[];
  traitBundle?: Trait[];
  symbolOverlay?: string[];
  uiComponentRefs?: string[];
  agentProfiles?: string[];
  permissions?: string[];
  remixable: boolean;
}

export interface ChronicleEntry {
  id: string;
  timestamp: number;
  type: 'insight' | 'narrative' | 'simulation' | 'ai_node';
  title: string;
  summary: string;
  relatedNodeIds?: string[];
}

export type IconName =
  | 'synth' | 'visualizer' | 'persona' | 'sequencer' | 'export'
  | 'plus' | 'chevron-left' | 'cubes' | 'node-cluster' | 'inspector' | 'map-pin'
  | 'arrows-pointing-out' | 'arrows-pointing-in' | 'trash' | 'layout-grid' | 'diagram' | 'cog'
  | 'help-circle' | 'fork' | 'notebook' | 'document-text' | 'user' | 'brain-circuit' | 'atom'
  | 'switch' | 'sampler' | 'fx' | 'mixer' | 'showcase' | 'database'
  | 'layers' | 'telescope' | 'sparkles'
  | 'play' | 'pause' | 'stop' | 'forward' | 'backward' | 'quill' | 'share'
  | 'dice' | 'git-branch'
  | 'window' | 'palette' | 'image' | 'audio' | 'video' | 'cpu' | 'file-code' | 'puzzle-piece'
  | 'chevron-right'
  | 'dna'
  | 'record'
  | 'stop-circle'
  | 'capsule'
  | 'remix'
  | 'infinity'
  | 'theater'
  | 'book-open'
  | 'shield-check'
  | 'lock-closed'
  | 'arrow-path'
  | 'swirl'
  | 'check-circle'
  | 'document-arrow-down'
  | 'tag'; // New icon for Symbols