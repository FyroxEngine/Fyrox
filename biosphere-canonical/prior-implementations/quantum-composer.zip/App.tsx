import React, { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import SplashScreen from './components/SplashScreen';
import Workspace from './components/Workspace';
import HelpModal from './components/HelpModal';
import NewProjectModal from './components/NewProjectModal';
import SettingsModal from './components/SettingsModal';
import Icon from './components/icons/Icon';
import ContextMenu from './components/ContextMenu';
import AddPluginModal from './components/AddPluginModal';
import BlueprintDisplayModal from './components/BlueprintDisplayModal';

import ExplorerPanel from './components/panels/ExplorerPanel';
import InspectorPanel from './components/panels/InspectorPanel';
import PluginManagerPanel from './components/panels/PluginManagerPanel';
import MediaLibraryPanel from './components/panels/MediaLibraryPanel';
import ExportConsole from './components/panels/ExportConsole';
import TraitRegistryPanel from './components/panels/TraitRegistryPanel';
import ShowcaseComposerPanel from './components/panels/ShowcaseComposerPanel';
import MultiShellLinkManagerPanel from './components/panels/MultiShellLinkManagerPanel';
import GenrePalettePanel from './components/panels/GenrePalettePanel';
import GenesisPanel from './components/panels/GenesisPanel';
import BlueprintHubPanel from './components/panels/BlueprintHubPanel';
import ScrollForgePanel from './components/panels/ScrollForgePanel';


import { INITIAL_PROJECTS, GENRE_TEMPLATES, THEMES, AI_MODELS, INITIAL_MEDIA_ASSETS, GENRE_PROFILES, MYTHIC_ARCHETYPES, REALITY_WEAVE_TEMPLATES, BLUEPRINT_CATEGORIES } from './constants';
import type { QuantumForgeProject, Theme, LLMConfig, IconName, QuantumForgeNode, QuantumForgeNodeUpdate, ContextMenuState, Zone, MediaAsset, GestureInput, AnimationState, AnimationPulse, PerformativeTake, NarrativeArtifact, RightPanelTab, ShowcaseCapsule, LeftPanelTab, StudioShell, RitualLink, EcosystemAPIConfig, GenreProfile, MythicArchetype, NarrativeSeed, QuantumOutcome, ObserverAuditLogEntry, CollapsedNarrativeBundle, Blueprint, CellStatus, ScrollCapsule } from './types';
import { FusionPulseAnimator } from './services/FusionPulseAnimator';
import { FusionVaultRecorder } from './services/FusionVaultRecorder';
import { QuantumResonanceService } from './services/QuantumResonanceService';
import { getPerformanceSuggestion, weaveNarrativeFromBundle } from './services/geminiService';

export type ActiveView = 'quantumforge' | 'quantumquill';
type RecordingState = 'idle' | 'recording' | 'paused';


const App: React.FC = () => {
  const [appState, setAppState] = useState<'splash' | 'workspace'>('splash');
  const [isWorkspaceEntering, setIsWorkspaceEntering] = useState(false);
  const [projects, setProjects] = useState<QuantumForgeProject[]>(INITIAL_PROJECTS);
  const [activeProject, setActiveProject] = useState<QuantumForgeProject | null>(null);
  const [theme, setTheme] = useState<Theme>(() => {
    const randomIndex = Math.floor(Math.random() * THEMES.length);
    return THEMES[randomIndex].id;
  });
  const [themeConfig, setThemeConfig] = useState({ bgOverlay: '', panelOverlay: '' });
  
  // Modal States
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isNewProjectOpen, setIsNewProjectOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAddPluginOpen, setAddPluginOpen] = useState(false);
  const [viewingBlueprint, setViewingBlueprint] = useState<Blueprint | null>(null);

  // Panel & View States
  const [isLeftPanelOpen, setLeftPanelOpen] = useState(true);
  const [isRightPanelOpen, setRightPanelOpen] = useState(true);
  const [activeLeftTab, setActiveLeftTab] = useState<LeftPanelTab>('explorer');
  const [activeRightTab, setActiveRightTab] = useState<RightPanelTab>('inspector');
  const [activeView, setActiveView] = useState<ActiveView>('quantumforge');

  // Lifted state
  const [selectedNodeIds, setSelectedNodeIds] = useState<string[]>([]);
  const [selectedZoneId, setSelectedZoneId] = useState<string | null>(null);
  const [selectedPluginId, setSelectedPluginId] = useState<string | null>(null);
  const [contextMenu, setContextMenu] = useState<ContextMenuState | null>(null);
  const [mediaAssets, setMediaAssets] = useState<MediaAsset[]>(INITIAL_MEDIA_ASSETS);
  const [animationState, setAnimationState] = useState<AnimationState>({ pulses: [] });
  
  // V12 Phase 3: Recording State
  const recorderRef = useRef(new FusionVaultRecorder());
  const [recordingState, setRecordingState] = useState<RecordingState>('idle');
  const [performanceSuggestion, setPerformanceSuggestion] = useState<string>('');
  const lastGestureRef = useRef<GestureInput | null>(null);

  // AI Models
  const [aiModels, setAiModels] = useState<LLMConfig[]>(AI_MODELS);
  
  const activeGenreProfile = GENRE_PROFILES.find(gp => gp.id === activeProject?.activeGenreProfileId) || null;

  // V12 Phase 5: Dynamic Probabilities
  const effectiveProbabilities = useMemo(() => {
    if (!activeProject) return new Map();
    return QuantumResonanceService.calculateEffectiveProbabilities(activeProject);
  }, [activeProject]);


  useEffect(() => {
    document.documentElement.style.setProperty('--custom-bg-image', themeConfig.bgOverlay ? `url(${themeConfig.bgOverlay})` : 'none');
    document.documentElement.style.setProperty('--custom-panel-image', themeConfig.panelOverlay ? `url(${themeConfig.panelOverlay})` : 'none');
  }, [themeConfig]);

  useEffect(() => {
    const now = Date.now();
    const activePulses = animationState.pulses.filter(p => now < (p.startTime + (p.delay || 0) + p.duration));
    
    if (activePulses.length < animationState.pulses.length) {
      setAnimationState({ pulses: activePulses });
    }

    const nextPulseTime = Math.min(...animationState.pulses.map(p => (p.startTime + (p.delay || 0) + p.duration)), Infinity);
    
    if(nextPulseTime < Infinity) {
      const timeoutId = setTimeout(() => {
        setAnimationState(prevState => {
          const now = Date.now();
          return { pulses: prevState.pulses.filter(p => now < (p.startTime + (p.delay || 0) + p.duration)) };
        });
      }, nextPulseTime - now + 10);
      return () => clearTimeout(timeoutId);
    }
  }, [animationState]);


  const handleEnter = () => {
    setAppState('workspace');
    setIsWorkspaceEntering(true);
    setTimeout(() => setIsWorkspaceEntering(false), 2500); // Remove animation class after it completes
    
    if (projects.length === 0) {
      setIsNewProjectOpen(true);
    } else {
      setActiveProject(projects[0]);
    }
  };
  
  const updateProjectProperty = (updater: (draft: QuantumForgeProject) => void) => {
    if (!activeProject) return;
    const newProject = JSON.parse(JSON.stringify(activeProject));
    updater(newProject);
    newProject.updatedAt = Date.now();
    setActiveProject(newProject);
    setProjects(projects.map(p => p.id === newProject.id ? newProject : p));
  };

  const handleCreateProject = useCallback((template: QuantumForgeProject) => {
      const newProject: QuantumForgeProject = {
        ...JSON.parse(JSON.stringify(template)),
        id: `proj_${Date.now()}`,
        name: `${template.name} Project`,
        isTemplate: false,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        mythicArchetypes: MYTHIC_ARCHETYPES, // Add default archetypes
      };
      setProjects(prev => [...prev, newProject]);
      setActiveProject(newProject);
      setIsNewProjectOpen(false);
  }, []);
  
  const handleCreateProjectFromCapsule = useCallback((capsule: ShowcaseCapsule) => {
      const sourceProject = projects.find(p => p.id === capsule.sourceProject.id);
      if (!sourceProject) return; // Or show an error
      
      const newProject: QuantumForgeProject = {
        ...JSON.parse(JSON.stringify(sourceProject)), // Base it on the source project
        id: `proj_${Date.now()}`,
        name: `Remix of ${capsule.metadata.title}`,
        isTemplate: false,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        performativeTakes: [],
        showcaseCapsules: [],
        description: `Remixed from "${capsule.metadata.title}". Original author: ${capsule.metadata.author}.`,
      };
      
      setProjects(prev => [...prev, newProject]);
      setActiveProject(newProject);
      setIsNewProjectOpen(false);
  }, [projects]);

  const updateAiModels = (newModels: LLMConfig[]) => {
    setAiModels(newModels);
  };
  
  // --- Selection Handlers ---
  const handleSelectNodes = (nodeIds: string[]) => {
    setSelectedNodeIds(nodeIds);
    setSelectedZoneId(null);
    setSelectedPluginId(null);
    if (nodeIds.length > 0) {
      setActiveRightTab('inspector');
      if (!isRightPanelOpen) setRightPanelOpen(true);
    }
  };

  const handleSelectZone = (zoneId: string | null) => {
    setSelectedZoneId(zoneId);
    setSelectedNodeIds([]);
    setSelectedPluginId(null);
    if (zoneId) {
      setActiveRightTab('inspector');
      if (!isRightPanelOpen) setRightPanelOpen(true);
    }
  };

  const handleSelectPlugin = (pluginId: string | null) => {
    setSelectedPluginId(pluginId);
    setSelectedNodeIds([]);
    setSelectedZoneId(null);
    if (pluginId) {
      setActiveRightTab('inspector');
      if (!isRightPanelOpen) setRightPanelOpen(true);
    }
  };

  // --- Node, Zone, Connection Handlers ---
  const handleUpdateNodes = (nodeUpdates: QuantumForgeNodeUpdate[]) => {
      updateProjectProperty(draft => {
        let updated = false;
        nodeUpdates.forEach(update => {
            const nodeIndex = draft.nodeGraph.nodes.findIndex(n => n.id === update.id);
            if (nodeIndex !== -1) {
                // Deep merge for quantumState
                if (update.quantumState) {
                  const existingNode = draft.nodeGraph.nodes[nodeIndex];
                  update.quantumState = { ...existingNode.quantumState, ...update.quantumState };
                }

                Object.assign(draft.nodeGraph.nodes[nodeIndex], update);
                draft.lastUpdatedNodeId = update.id;
                draft.lastUpdateTime = Date.now();
                updated = true;
            }
        });
        if (updated) {
            setAnimationState(prev => ({
                ...prev,
                pulses: [
                    ...prev.pulses,
                    ...nodeUpdates.map(u => ({
                        id: `port-glow-${u.id}-${Date.now()}`,
                        targetId: u.id!,
                        type: 'port-glow',
                        startTime: Date.now(),
                        duration: 1500
                    } as AnimationPulse))
                ]
            }));

            if (recorderRef.current.isRecording()) {
                 const desc = `Node(s) updated: ${nodeUpdates.map(u => {
                    const node = draft.nodeGraph.nodes.find(n => n.id === u.id);
                    return node?.label || u.id;
                 }).join(', ')}`;
                 recorderRef.current.log('node_update', {updates: nodeUpdates}, desc);
            }
        }
      });
  };
  
  const handleUpdateProject = (updatedProject: QuantumForgeProject) => {
    setActiveProject(updatedProject);
    setProjects(projects.map(p => p.id === updatedProject.id ? updatedProject : p));
  };


  const handleAddNode = (type: string, position: { x: number, y: number }, icon: IconName, mediaAsset?: MediaAsset) => {
      const content = mediaAsset ? mediaAsset.name : `New ${type}`;
      const newNode: QuantumForgeNode = {
          id: `node_${Date.now()}`,
          label: content,
          type,
          icon,
          position,
          inputs: [{ id: 'p_in', name: 'in', type: 'any' }],
          outputs: [{ id: 'p_out', name: 'out', type: 'any' }],
          attributes: {},
          mediaAssetId: mediaAsset?.id,
          quantumState: {
            collapsed: true,
            outcomes: [{ probability: 1, content: content }]
          }
      };
      updateProjectProperty(draft => {
          draft.nodeGraph.nodes.push(newNode);
      });
      setContextMenu(null);
  };
  
  const handleDeleteNodes = (nodeIds: string[]) => {
     updateProjectProperty(draft => {
        draft.nodeGraph.nodes = draft.nodeGraph.nodes.filter(n => !nodeIds.includes(n.id));
        draft.nodeGraph.connections = draft.nodeGraph.connections.filter(
            c => !nodeIds.includes(c.fromNodeId) && !nodeIds.includes(c.toNodeId)
        );
     });
     setSelectedNodeIds([]);
  };

  const handleAddZone = (position: { x: number, y: number }) => {
      const newZone: Zone = {
          id: `zone_${Date.now()}`,
          label: 'New Zone',
          rect: { x: position.x, y: position.y, width: 300, height: 200 },
          color: 'rgba(56, 189, 248, 0.1)',
      };
      updateProjectProperty(draft => {
          if (!draft.zones) draft.zones = [];
          draft.zones.push(newZone);
      });
      setContextMenu(null);
  };

  const handleUpdateZone = (zone: Zone) => {
      updateProjectProperty(draft => {
          const index = draft.zones?.findIndex(z => z.id === zone.id);
          if (draft.zones && index !== -1) {
              draft.zones[index] = zone;
          }
      });
  };

  const handleDeleteZone = (zoneId: string) => {
      updateProjectProperty(draft => {
          if (!draft.zones) return;
          draft.zones = draft.zones.filter(z => z.id !== zoneId);
      });
      if (selectedZoneId === zoneId) setSelectedZoneId(null);
  };

  // --- Plugin Handlers ---
  const handleAddPlugin = (name: string, icon: IconName, description: string) => {
    const newPlugin: QuantumForgeProject = {
      id: `inst_${Date.now()}`,
      name,
      description,
      icon,
      isTemplate: false,
      tags: ['custom'],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      nodeGraph: { nodes: [], connections: [] },
      controls: [
          {id: 'ctrl_vol', label: 'Volume', type: 'fader', value: 0.75, targetNodeId: '', targetAttribute: 'volume'},
          {id: 'ctrl_pan', label: 'Pan', type: 'knob', value: 0.5, targetNodeId: '', targetAttribute: 'pan'},
      ],
      traitRegistry: { id: 'default', name: 'Default', traits: [] },
      symbolRegistry: { id: 'default', name: 'Default', symbols: [] },
    };
    updateProjectProperty(draft => {
        if (!draft.plugins) draft.plugins = [];
        draft.plugins.push(newPlugin);
    });
    setAddPluginOpen(false);
  };
  
  const handleDeletePlugin = (pluginId: string) => {
    updateProjectProperty(draft => {
        if (!draft.plugins) return;
        draft.plugins = draft.plugins.filter(i => i.id !== pluginId);
    });
    if (selectedPluginId === pluginId) setSelectedPluginId(null);
  };

  // --- Media Handlers ---
  const handleAddMediaAsset = (asset: MediaAsset) => {
      setMediaAssets(prev => [...prev, asset]);
  };

  // --- Gesture Handler ---
  const handleGesture = (gesture: GestureInput) => {
    if (!activeProject) return;
    lastGestureRef.current = gesture;

    const pulse = FusionPulseAnimator.processGesture(gesture, activeProject.nodeGraph.nodes);
    if (pulse) {
        let pulsesToAdd = [pulse];

        const gestureRitual = (activeProject.ritualLinks || []).find(r => r.enabled && r.triggerType === 'gesture');
        if (gestureRitual) {
            const echoPulse: AnimationPulse = {
                ...pulse,
                id: `${pulse.id}-echo`,
                delay: 500, // 500ms delay for the echo
            };
            pulsesToAdd.push(echoPulse);
        }

        setAnimationState(prev => ({
            pulses: [...prev.pulses.filter(p => p.type !== 'trait-pulse'), ...pulsesToAdd]
        }));
    }
    if (recorderRef.current.isRecording()) {
        const desc = `Gesture performed at (${gesture.x.toFixed(2)}, ${gesture.y.toFixed(2)})`;
        recorderRef.current.log('gesture', gesture, desc);
    }
  };
  
  // --- Recording Handlers ---
  const handleStartRecording = () => {
    recorderRef.current.start();
    setRecordingState('recording');
  };

  const handleStopRecording = () => {
    const take = recorderRef.current.stop();
    if (take) {
        updateProjectProperty(draft => {
            if (!draft.performativeTakes) draft.performativeTakes = [];
            draft.performativeTakes.push(take);
        });
        setActiveRightTab('showcase');
        if (!isRightPanelOpen) setRightPanelOpen(true);
    }
    setRecordingState('idle');
  };

  // --- Artifact & Capsule Handlers ---
  const handleSaveArtifact = (artifact: NarrativeArtifact) => {
     updateProjectProperty(draft => {
        if (!draft.narrativeArtifacts) draft.narrativeArtifacts = [];
        draft.narrativeArtifacts.push(artifact);
     });
  };

  const handleCreateShowcaseCapsule = (capsule: ShowcaseCapsule) => {
    updateProjectProperty(draft => {
        if (!draft.showcaseCapsules) draft.showcaseCapsules = [];
        draft.showcaseCapsules.push(capsule);
    });
  };
  
  // --- V13: ScrollForge Handler ---
  const handleSaveScrollCapsule = (capsule: ScrollCapsule) => {
    updateProjectProperty(draft => {
        if (!draft.scrollCapsules) draft.scrollCapsules = [];
        draft.scrollCapsules.push(capsule);
    });
  };

  // --- V12 Phase 6: Ecosystem Handlers ---
  const handleUpdateEcosystemData = (key: 'linkedShells' | 'ritualLinks' | 'apiConfigs', data: any[]) => {
    updateProjectProperty(draft => {
        draft[key] = data;
    });
  };
  
  // --- V12 Phase 7: Genre Handlers ---
  const handleSetGenreProfile = (genreId: string | null) => {
    updateProjectProperty(draft => {
        draft.activeGenreProfileId = genreId;
    });
  };

  // --- V12 Phase 8: Genesis Handlers ---
  const handleCreateMythicArchetype = (archetype: MythicArchetype) => {
    updateProjectProperty(draft => {
        if (!draft.mythicArchetypes) draft.mythicArchetypes = [];
        draft.mythicArchetypes.push(archetype);
    });
  };
  
  const handleUpdateArchetype = (archetype: MythicArchetype) => {
     updateProjectProperty(draft => {
        if (!draft.mythicArchetypes) return;
        const index = draft.mythicArchetypes.findIndex(a => a.id === archetype.id);
        if (index !== -1) {
            draft.mythicArchetypes[index] = archetype;
        }
    });
  };

  const handleCreateNarrativeSeed = (seed: NarrativeSeed) => {
    updateProjectProperty(draft => {
        if (!draft.narrativeSeeds) draft.narrativeSeeds = [];
        draft.narrativeSeeds.push(seed);
    });
  };

  // --- V12 Phase 9 & 10: Quantum & Audit Handlers ---
  const handleCollapseNode = (nodeId: string) => {
    const node = activeProject?.nodeGraph.nodes.find(n => n.id === nodeId);
    if (!node || node.quantumState.collapsed) return;

    // Probabilistic Resolution Engine
    const rand = Math.random();
    let cumulativeProb = 0;
    let chosenOutcome: QuantumOutcome | null = null;
    
    // Use effective probabilities for resolution
    const probabilitiesForNode = effectiveProbabilities.get(nodeId) || node.quantumState.outcomes;

    for (const outcome of probabilitiesForNode) {
        cumulativeProb += outcome.probability;
        if (rand <= cumulativeProb) {
            chosenOutcome = outcome;
            break;
        }
    }
    if (!chosenOutcome && probabilitiesForNode.length > 0) {
        chosenOutcome = probabilitiesForNode[0]; // Fallback
    }
    
    if (chosenOutcome) {
        const logEntry: ObserverAuditLogEntry = {
            id: `obs_${Date.now()}`,
            timestamp: Date.now(),
            collapsedNodeId: node.id,
            chosenOutcome: chosenOutcome,
            allOutcomes: node.quantumState.outcomes,
        };

        const nodeUpdate: QuantumForgeNodeUpdate = {
            id: nodeId,
            quantumState: {
                ...node.quantumState,
                collapsed: true,
                outcomes: [chosenOutcome],
            }
        };
        handleUpdateNodes([nodeUpdate]);

        updateProjectProperty(draft => {
            if (!draft.observerAuditLog) draft.observerAuditLog = [];
            draft.observerAuditLog.push(logEntry);
        });
    }
  };
  
  const handleCreateBundle = (bundle: CollapsedNarrativeBundle) => {
    updateProjectProperty(draft => {
      if (!draft.collapsedNarrativeBundles) draft.collapsedNarrativeBundles = [];
      draft.collapsedNarrativeBundles.push(bundle);
    });
  };
  
  const handleUpdateBundle = (updatedBundle: CollapsedNarrativeBundle) => {
    updateProjectProperty(draft => {
      if (!draft.collapsedNarrativeBundles) return;
      const index = draft.collapsedNarrativeBundles.findIndex(b => b.id === updatedBundle.id);
      if (index !== -1) {
        draft.collapsedNarrativeBundles[index] = updatedBundle;
      }
    });
  };

  const handleUpdateRoadmapCell = useCallback((layerId: string, versionKey: string, phaseKey: string, status: CellStatus) => {
    updateProjectProperty(draft => {
        if (!draft.roadmapState) {
            draft.roadmapState = {};
        }
        if (!draft.roadmapState[layerId]) {
            draft.roadmapState[layerId] = {};
        }
        if (!draft.roadmapState[layerId][versionKey]) {
            draft.roadmapState[layerId][versionKey] = {};
        }
        draft.roadmapState[layerId][versionKey][phaseKey] = { status };
    });
  }, []);


  const handleGetSuggestion = async () => {
    if (!activeProject) return;
    try {
      const suggestion = await getPerformanceSuggestion(activeProject, activeGenreProfile);
      setPerformanceSuggestion(suggestion);
    } catch (e) {
      console.error("Failed to get suggestion", e);
      setPerformanceSuggestion("Could not get suggestion.");
    }
  };
  
  const allShowcaseCapsules = projects.flatMap(p => p.showcaseCapsules || []);

  const SidebarIcon = ({ name, icon, tab }: { name: string; icon: IconName; tab: LeftPanelTab }) => (
    <button
      title={name}
      onClick={() => { setActiveLeftTab(tab); if(!isLeftPanelOpen) setLeftPanelOpen(true); }}
      className={`p-2 rounded-md ${activeLeftTab === tab && isLeftPanelOpen ? 'bg-[var(--color-accent-primary)] text-white' : 'text-[var(--text-secondary)] hover:bg-[var(--bg-interactive)] hover:text-[var(--text-primary)]'}`}
    >
      <Icon name={icon} className="w-6 h-6" />
    </button>
  );

  const RightSidebarIcon = ({ name, icon, tab }: { name: string; icon: IconName; tab: RightPanelTab }) => (
     <button
      title={name}
      onClick={() => { setActiveRightTab(tab); if(!isRightPanelOpen) setRightPanelOpen(true); }}
      className={`p-2 rounded-md ${activeRightTab === tab && isRightPanelOpen ? 'bg-[var(--color-accent-primary)] text-white' : 'text-[var(--text-secondary)] hover:bg-[var(--bg-interactive)] hover:text-[var(--text-primary)]'}`}
    >
      <Icon name={icon} className="w-6 h-6" />
    </button>
  );

  const renderLeftPanelContent = () => {
    if (!activeProject) return null;
    switch (activeLeftTab) {
      case 'explorer': return <ExplorerPanel project={activeProject} onUpdateProject={handleUpdateProject} />;
      case 'plugins': return <PluginManagerPanel project={activeProject} selectedPluginId={selectedPluginId} onSelect={handleSelectPlugin} onUpdateProject={handleUpdateProject} onAddPlugin={() => setAddPluginOpen(true)} onDeletePlugin={handleDeletePlugin} />;
      case 'media': return <MediaLibraryPanel mediaAssets={mediaAssets} onAddAsset={handleAddMediaAsset} />;
      case 'lore': return <TraitRegistryPanel project={activeProject} onUpdateProject={handleUpdateProject} />;
      case 'linking': return <MultiShellLinkManagerPanel project={activeProject} onUpdateEcosystemData={handleUpdateEcosystemData} />;
      case 'genre': return <GenrePalettePanel project={activeProject} onSetGenre={handleSetGenreProfile} />;
      case 'genesis': return <GenesisPanel project={activeProject} onCreateArchetype={handleCreateMythicArchetype} onUpdateArchetype={handleUpdateArchetype} onCreateSeed={handleCreateNarrativeSeed} />;
      case 'blueprints': return <BlueprintHubPanel onViewBlueprint={setViewingBlueprint} />;
      case 'scrollforge': return <ScrollForgePanel onSaveCapsule={handleSaveScrollCapsule} />;
      default: return null;
    }
  };

  const renderRightPanelContent = () => {
    if (!activeProject) return null;
    const selectedNodeObjects = selectedNodeIds.map(id => activeProject.nodeGraph.nodes.find(n => n.id === id)).filter(n => n) as QuantumForgeNode[];
    const selectedZoneObject = activeProject.zones?.find(z => z.id === selectedZoneId) || null;
    const selectedPluginObject = activeProject.id === selectedPluginId ? activeProject : activeProject.plugins?.find(p => p.id === selectedPluginId) || null;

    switch (activeRightTab) {
      case 'inspector': return <InspectorPanel project={activeProject} selectedNodes={selectedNodeObjects} selectedZone={selectedZoneObject} selectedPlugin={selectedPluginObject} onUpdateProject={handleUpdateProject} onUpdateNodes={handleUpdateNodes} aiModels={aiModels} onDeleteNode={handleDeleteNodes} activeGenreProfile={activeGenreProfile} onCollapseNode={handleCollapseNode} />;
      case 'export': return <ExportConsole project={activeProject} />;
      case 'showcase': return <ShowcaseComposerPanel project={activeProject} onSaveArtifact={handleSaveArtifact} onSaveCapsule={handleCreateShowcaseCapsule} onUpdateApiConfigs={(data) => handleUpdateEcosystemData('apiConfigs', data)} onCreateBundle={handleCreateBundle} onUpdateBundle={handleUpdateBundle} activeGenreProfile={activeGenreProfile} />;
      default: return null;
    }
  };

  const currentTheme = THEMES.find(t => t.id === theme) || THEMES[0];
  const themeClass = currentTheme.id;

  if (appState === 'splash') {
    return (
      <main className={`${themeClass} h-full w-full bg-[var(--bg-primary)] text-[var(--text-primary)]`}>
        <SplashScreen onEnter={handleEnter} />
      </main>
    );
  }

  return (
    <main className={`${themeClass} h-full w-full bg-[var(--bg-primary)] text-[var(--text-primary)] flex flex-col ${isWorkspaceEntering ? 'workspace-active' : ''}`}>
      <Header onNewProjectClick={() => setIsNewProjectOpen(true)} activeView={activeView} onToggleView={setActiveView} />
      <div className="flex-grow flex overflow-hidden">
        {/* Left Static Panel */}
        <div className="left-sidebar flex-shrink-0 w-16 bg-[var(--bg-secondary)] flex flex-col items-center justify-between py-4 border-r border-[var(--border-primary)] panel-overlay-bg">
          <div className="flex flex-col items-center gap-2">
            <SidebarIcon name="Explorer" icon="cubes" tab="explorer" />
            <SidebarIcon name="Plugins" icon="puzzle-piece" tab="plugins" />
            <SidebarIcon name="Media" icon="image" tab="media" />
            <SidebarIcon name="ScrollForge" icon="document-arrow-down" tab="scrollforge" />
            <SidebarIcon name="Lore" icon="dna" tab="lore" />
            <SidebarIcon name="Linking" icon="infinity" tab="linking" />
            <SidebarIcon name="Genre" icon="theater" tab="genre" />
            <SidebarIcon name="Genesis" icon="atom" tab="genesis" />
            <SidebarIcon name="Blueprints" icon="book-open" tab="blueprints" />
          </div>
          <button onClick={() => setLeftPanelOpen(!isLeftPanelOpen)} className="p-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)]">
            <Icon name={isLeftPanelOpen ? 'chevron-left' : 'chevron-right'} className="w-6 h-6" />
          </button>
        </div>

        {/* Left Sliding Panel */}
        <div className={`left-panel transition-all duration-300 ease-in-out bg-[var(--bg-secondary)]/80 backdrop-blur-sm border-r border-[var(--border-primary)] panel-overlay-bg overflow-y-auto ${isLeftPanelOpen ? 'w-80 p-4' : 'w-0 p-0'}`}>
          {isLeftPanelOpen && renderLeftPanelContent()}
        </div>

        {/* Main Content */}
        <div className="workspace-content flex-grow relative bg-overlay-bg bg-cover bg-center" style={{height: '80vh'}}>
          {activeProject ? (
             <Workspace 
                project={activeProject} 
                onUpdateProject={handleUpdateProject}
                selectedNodeIds={selectedNodeIds}
                onSelectNodes={handleSelectNodes}
                selectedZoneId={selectedZoneId}
                onSelectZone={handleSelectZone}
                setContextMenu={setContextMenu}
                onAddNode={handleAddNode}
                onUpdateNodes={handleUpdateNodes}
                onUpdateZone={handleUpdateZone}
                mediaAssets={mediaAssets}
                activeView={activeView}
                animationState={animationState}
                onGesture={handleGesture}
                recordingState={recordingState}
                onStartRecording={handleStartRecording}
                onStopRecording={handleStopRecording}
                activeGenreProfile={activeGenreProfile}
                performanceSuggestion={performanceSuggestion}
                onGetSuggestion={handleGetSuggestion}
                onCollapseNode={handleCollapseNode}
                lastGesture={lastGestureRef.current}
                effectiveProbabilities={effectiveProbabilities}
             />
          ) : (
             <div className="flex items-center justify-center h-full text-[var(--text-secondary)]">No project loaded.</div>
          )}
        </div>

        {/* Right Sliding Panel */}
         <div className={`right-panel transition-all duration-300 ease-in-out bg-[var(--bg-secondary)]/80 backdrop-blur-sm border-l border-[var(--border-primary)] panel-overlay-bg overflow-y-auto ${isRightPanelOpen ? 'w-80' : 'w-0'}`}>
          {isRightPanelOpen && renderRightPanelContent()}
        </div>

        {/* Right Static Panel */}
        <div className="right-sidebar flex-shrink-0 w-16 bg-[var(--bg-secondary)] flex flex-col items-center justify-between py-4 border-l border-[var(--border-primary)] panel-overlay-bg">
          <div className="flex flex-col items-center gap-2">
            <RightSidebarIcon name="Inspector" icon="inspector" tab="inspector" />
            <RightSidebarIcon name="Export" icon="export" tab="export" />
            <RightSidebarIcon name="Showcase" icon="showcase" tab="showcase" />
            <button title="Settings" onClick={() => setIsSettingsOpen(true)} className="p-2 text-[var(--text-secondary)] hover:bg-[var(--bg-interactive)] hover:text-[var(--text-primary)] rounded-md"><Icon name="cog" className="w-6 h-6" /></button>
            <button title="Help" onClick={() => setIsHelpOpen(true)} className="p-2 text-[var(--text-secondary)] hover:bg-[var(--bg-interactive)] hover:text-[var(--text-primary)] rounded-md"><Icon name="help-circle" className="w-6 h-6" /></button>
          </div>
           <button onClick={() => setRightPanelOpen(!isRightPanelOpen)} className="p-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)]">
            <Icon name={isRightPanelOpen ? 'chevron-right' : 'chevron-left'} className="w-6 h-6" />
          </button>
        </div>
      </div>
      <Footer projectName={activeProject?.name} />
      
      {/* Modals */}
      {isHelpOpen && <HelpModal onClose={() => setIsHelpOpen(false)} />}
      {isNewProjectOpen && <NewProjectModal onClose={() => setIsNewProjectOpen(false)} onSelectTemplate={handleCreateProject} showcaseCapsules={allShowcaseCapsules} onCreateFromCapsule={handleCreateProjectFromCapsule} />}
      {isSettingsOpen && <SettingsModal onClose={() => setIsSettingsOpen(false)} currentTheme={theme} onSetTheme={setTheme} customConfig={themeConfig} onSetConfig={setThemeConfig} aiModels={aiModels} onUpdateAiModels={updateAiModels} />}
      {isAddPluginOpen && <AddPluginModal onClose={() => setAddPluginOpen(false)} onAdd={handleAddPlugin} />}
      {viewingBlueprint && activeProject && <BlueprintDisplayModal blueprint={viewingBlueprint} project={activeProject} onClose={() => setViewingBlueprint(null)} onUpdateRoadmapCell={handleUpdateRoadmapCell} />}

      {/* Context Menu */}
      {contextMenu && (
        <ContextMenu x={contextMenu.x} y={contextMenu.y} onClose={() => setContextMenu(null)}>
            {contextMenu.type === 'canvas' && (
                <>
                    <button onClick={() => handleAddZone({x: contextMenu.canvasX || 0, y: contextMenu.canvasY || 0})} className="context-menu-item">Add Zone</button>
                </>
            )}
            {contextMenu.type === 'node' && contextMenu.nodeId && (
                <>
                    <button onClick={() => handleDeleteNodes([contextMenu.nodeId!])} className="context-menu-item text-red-400">Delete Node</button>
                </>
            )}
             {contextMenu.type === 'zone' && contextMenu.zoneId && (
                <>
                    <button onClick={() => handleDeleteZone(contextMenu.zoneId!)} className="context-menu-item text-red-400">Delete Zone</button>
                </>
            )}
        </ContextMenu>
      )}

      <style>{`
          .panel-header {
              font-weight: bold;
              text-transform: uppercase;
              letter-spacing: 0.05em;
          }
          .label-text {
             font-size: 0.75rem;
             font-weight: bold;
             color: var(--text-secondary);
             text-transform: uppercase;
             letter-spacing: 0.05em;
          }
          .inspector-input {
              width: 100%;
              background-color: var(--bg-primary);
              padding: 0.5rem;
              border-radius: 0.375rem;
              border: 1px solid var(--border-primary);
              color: var(--text-primary);
          }
          .inspector-input:focus {
             outline: none;
             ring: 1px;
             border-color: var(--color-accent-primary);
             box-shadow: 0 0 5px var(--color-accent-primary);
          }
          .button-primary {
              padding: 0.5rem 1rem;
              border-radius: 0.375rem;
              background-color: var(--color-accent-primary);
              color: white;
              font-weight: bold;
              transition: background-color 0.2s;
          }
          .button-primary:hover {
              background-color: var(--color-accent-primary-hover);
          }
           .button-secondary {
              padding: 0.5rem 1rem;
              border-radius: 0.375rem;
              background-color: var(--bg-interactive);
              color: var(--text-primary);
              transition: background-color 0.2s;
          }
          .button-secondary:hover {
              background-color: var(--bg-tertiary);
          }
          .button-danger {
              padding: 0.5rem 1rem;
              border-radius: 0.375rem;
              background-color: #991b1b; /* red-800 */
              color: #fca5a5; /* red-300 */
          }
          .button-danger:hover {
            background-color: #b91c1c; /* red-700 */
          }
          .context-menu-item {
              display: block;
              width: 100%;
              padding: 0.5rem 1rem;
              text-align: left;
              font-size: 0.875rem;
          }
           .context-menu-item:hover {
              background-color: var(--bg-interactive);
           }
      `}</style>
    </main>
  );
}

export default App;
