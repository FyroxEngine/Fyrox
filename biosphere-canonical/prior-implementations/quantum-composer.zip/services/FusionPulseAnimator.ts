import type { QuantumForgeNode, GestureInput, AnimationPulse } from '../types';

export class FusionPulseAnimator {
    /**
     * Finds the node closest to a given gesture's coordinates.
     */
    public static findNearestNode(gesture: GestureInput, nodes: QuantumForgeNode[]): QuantumForgeNode | null {
        if (nodes.length === 0) {
            return null;
        }

        let closestNode: QuantumForgeNode | null = null;
        let minDistance = Infinity;

        // This is a simplified proximity check based on the node's top-left corner.
        // A more advanced implementation would use node dimensions and the gesture pad's aspect ratio.
        for (const node of nodes) {
            // Estimate canvas size for mapping gesture coordinates (0-1) to pixel space
            const estimatedCanvasWidth = 2000;
            const estimatedCanvasHeight = 1500;

            const gestureX = gesture.x * estimatedCanvasWidth;
            const gestureY = gesture.y * estimatedCanvasHeight;
            
            // Find center of node for more accurate distance check
            const nodeCenterX = node.position.x + 90; // width / 2
            const nodeCenterY = node.position.y + 50; // approximate height / 2

            const distance = Math.sqrt(
                Math.pow(nodeCenterX - gestureX, 2) +
                Math.pow(nodeCenterY - gestureY, 2)
            );

            if (distance < minDistance) {
                minDistance = distance;
                closestNode = node;
            }
        }
        return closestNode;
    }

    /**
     * Translates a gesture input into a visual animation pulse on the nearest node.
     */
    public static processGesture(gesture: GestureInput, nodes: QuantumForgeNode[]): AnimationPulse | null {
        const closestNode = this.findNearestNode(gesture, nodes);
        
        if (closestNode) {
            return {
                id: `trait-pulse-${closestNode.id}-${Date.now()}`,
                targetId: closestNode.id,
                type: 'trait-pulse',
                startTime: Date.now(),
                duration: 1000, // 1 second pulse
            };
        }

        return null;
    }
}