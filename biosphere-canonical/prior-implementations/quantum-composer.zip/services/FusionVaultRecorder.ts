import type { PerformativeTake, SignalHistoryLogEntry } from '../types';

export class FusionVaultRecorder {
    private currentTake: PerformativeTake | null = null;

    public start(): void {
        this.currentTake = {
            id: `take_${Date.now()}`,
            startTime: Date.now(),
            endTime: 0,
            signalLog: [{
                timestamp: Date.now(),
                type: 'system',
                payload: {},
                description: 'Recording started.'
            }],
        };
    }

    public stop(): PerformativeTake | null {
        if (!this.currentTake) {
            return null;
        }
        this.currentTake.endTime = Date.now();
        this.log('system', {}, 'Recording stopped.');
        const finishedTake = { ...this.currentTake };
        this.currentTake = null;
        return finishedTake;
    }

    public isRecording(): boolean {
        return this.currentTake !== null;
    }

    public log(type: SignalHistoryLogEntry['type'], payload: any, description: string): void {
        if (!this.isRecording()) {
            return;
        }
        const entry: SignalHistoryLogEntry = {
            timestamp: Date.now(),
            type,
            payload,
            description
        };
        this.currentTake?.signalLog.push(entry);
    }
}
