import { GoogleGenAI, Type } from "@google/genai";
import type { QuantumForgeProject, LLMConfig, QuantumForgeNode, Archetype, PerformativeTake, OutputStyleProfile, NarrativeArtifact, GenreProfile, MythicArchetype, NarrativeSeed, EvolutionaryAlgorithmConfig, ProceduralArc, QuantumOutcome, CollapsedNarrativeBundle, RealityWeaveTemplate, ScrollCapsule, ScrollCapsuleFile } from '../types';

const googleApiKey = process.env.API_KEY;

const aiInstances: Record<string, GoogleGenAI> = {};

function getGoogleAI(apiKey?: string) {
    const key = apiKey || googleApiKey;
    if (!key) return null;
    if (!aiInstances[key]) {
        aiInstances[key] = new GoogleGenAI({ apiKey: key });
    }
    return aiInstances[key];
}


async function generateWithGoogle(prompt: string, model: string, systemInstruction?: string) {
    const ai = getGoogleAI();
    if (!ai) {
        throw new Error("Google AI client not initialized. Is API_KEY set?");
    }
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                systemInstruction,
                temperature: 0.7,
            }
        });
        return response.text;
    } catch (error) {
        console.error('Google Gemini API Error:', error);
        throw new Error(`Failed to generate content from Google: ${error instanceof Error ? error.message : String(error)}`);
    }
}

async function generateWithLocalLLM(prompt: string, modelConfig: LLMConfig, systemInstruction?: string) {
    if (!modelConfig.url) {
        throw new Error("Local LLM URL is not configured.");
    }
    try {
        const response = await fetch(modelConfig.url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: modelConfig.modelId,
                prompt: systemInstruction ? `${systemInstruction}\n\n${prompt}` : prompt,
                stream: false,
            }),
        });
        if (!response.ok) {
            throw new Error(`Local LLM request failed with status ${response.status}`);
        }
        const data = await response.json();
        return data.response; // Assuming Ollama-like response format
    } catch (error) {
        console.error('Local LLM Error:', error);
        throw new Error(`Failed to generate content from Local LLM: ${error instanceof Error ? error.message : String(error)}`);
    }
}

export const generateQuantumOutcomes = async (prompt: string, modelId: string = 'gemini-2.5-flash'): Promise<QuantumOutcome[]> => {
    const ai = getGoogleAI();
    if (!ai) throw new Error("Google AI client not initialized.");

    const fullPrompt = `Based on the following prompt, generate 3-5 distinct, creative, and varied potential outcomes or snippets of text. Each outcome should be a short sentence or two.

PROMPT: "${prompt}"
`;

    const responseSchema = {
        type: Type.OBJECT,
        properties: {
            outcomes: {
                type: Type.ARRAY,
                description: "An array of 3 to 5 potential narrative outcomes.",
                items: {
                    type: Type.OBJECT,
                    properties: {
                        content: { type: Type.STRING, description: "The text of the narrative outcome." }
                    }
                }
            }
        }
    };

    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: fullPrompt,
            config: {
                systemInstruction: "You are a creative engine for generating narrative possibilities. For the given prompt, provide a diverse set of potential outcomes in the specified JSON format. Do not add any commentary.",
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            }
        });
        
        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);

        if (parsedJson.outcomes && Array.isArray(parsedJson.outcomes) && parsedJson.outcomes.length > 0) {
            const totalOutcomes = parsedJson.outcomes.length;
            const probability = 1 / totalOutcomes;
            return parsedJson.outcomes.map((o: any) => ({ content: o.content, probability }));
        } else {
            throw new Error("Generated JSON does not match the expected QuantumOutcomes schema.");
        }
    } catch (error) {
        console.error('Gemini API Error during quantum outcome generation:', error);
        throw new Error(`Failed to generate quantum outcomes from Google: ${error instanceof Error ? error.message : String(error)}`);
    }
};

export const forgeScrollCapsule = async (transcript: string, modelId: string = 'gemini-2.5-flash'): Promise<ScrollCapsuleFile[]> => {
    const ai = getGoogleAI();
    if (!ai) throw new Error("Google AI client not initialized.");

    const prompt = `
Analyze the following text transcript and structure it into a "ScrollCapsule" format. 
You must generate exactly 8 files with the specified filenames. 
The content of each file should be derived from the themes, concepts, and dialogue within the transcript. 
Adhere to the "Forge Principles": Signal before Structure, Emotion before Execution, Memory before Manifest.

TRANSCRIPT:
---
${transcript}
---
`;
    
    const responseSchema = {
        type: Type.OBJECT,
        properties: {
            capsule: {
                type: Type.ARRAY,
                description: "An array of exactly 8 file objects representing the ScrollCapsule.",
                items: {
                    type: Type.OBJECT,
                    properties: {
                        fileName: { type: Type.STRING, description: "The full path and name of the file." },
                        content: { type: Type.STRING, description: "The generated content for the file, formatted as a string (e.g., JSON string for .json files, Markdown for .md files)." }
                    }
                }
            }
        }
    };

    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: prompt,
            config: {
                systemInstruction: `You are ScrollForge, an AI that transmutes raw text into structured, performable, and remixable assets. Your task is to analyze the user's transcript and generate a complete 8-file ScrollCapsule in the specified JSON format. The required files are: 'CapsuleManifest.json', 'blueprint/scrolls/dialogue.md', 'blueprint/scrolls/prologue.md', 'blueprint/scrolls/traits.json', 'blueprint/scrolls/cueMap.ts', 'blueprint/scrolls/README.md', 'blueprint/scrolls/parsing-log.md', and 'blueprint/scrolls/tables/reflectiveGrid.json'. Populate each file with relevant content derived from the transcript. For JSON and TS files, the content must be a valid JSON/TS string.`,
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            }
        });
        
        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);
        
        if (parsedJson.capsule && Array.isArray(parsedJson.capsule)) {
            return parsedJson.capsule as ScrollCapsuleFile[];
        } else {
            throw new Error("Generated JSON does not match the expected ScrollCapsule schema.");
        }

    } catch (error) {
        console.error('Gemini API Error during ScrollCapsule forging:', error);
        throw new Error(`Failed to forge ScrollCapsule: ${error instanceof Error ? error.message : String(error)}`);
    }
};


export const generateProjectInsights = async (project: QuantumForgeProject): Promise<string[]> => {
    const ai = getGoogleAI();
    if (!ai) {
        return Promise.resolve([
            "Mock Insight: The 'Audio Engine' and 'Visual Engine' zones suggest a core AV relationship.",
            "Mock Suggestion: Consider adding a 'Modulation' node to create more dynamic interactions between your audio and visual components."
        ]);
    }
    
    const prompt = `Analyze the following Quantum Forge project structure. The project's intent is: "${project.intent || 'Not specified'}". Identify interesting patterns, potential areas for improvement or expansion, and suggest a creative next step. Provide 2-3 short, actionable insights in a numbered list.\n\nProject Data:\n${JSON.stringify({
        name: project.name,
        nodes: project.nodeGraph.nodes.length,
        connections: project.nodeGraph.connections.length,
        zones: project.zones?.length,
        plugins: project.plugins?.length,
    }, null, 2)}`;
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: "You are a brilliant systems analyst and creative strategist for Quantum Forge. Your task is to analyze project data and provide high-level insights and suggestions to help the creator. Be concise and perceptive.",
            }
        });
        return response.text.split('\n').map(line => line.replace(/^[0-9]+\.\s*/, '')).filter(line => line.trim() !== '');

    } catch (error) {
        console.error('Gemini API error:', error);
        throw new Error('Failed to generate insights from Gemini API.');
    }
};

export const generateNarrativeArtifact = async (take: PerformativeTake, profile: OutputStyleProfile, genreProfile?: GenreProfile | null, modelId: string = 'gemini-2.5-flash'): Promise<NarrativeArtifact> => {
    const ai = getGoogleAI();
    if (!ai) {
        throw new Error("Google AI client not initialized.");
    }

    const logSummary = take.signalLog.map(log => `[${new Date(log.timestamp).toLocaleTimeString()}] ${log.description}`).join('\n');

    let prompt = `
        Here is a log of events from a creative performance session. Please generate a narrative artifact based on this log.

        PERFORMANCE LOG:
        ---
        ${logSummary}
        ---
        
        Please generate the output based on these instructions.
    `;

    let systemInstruction = profile.systemInstruction;
    if (genreProfile) {
        systemInstruction = genreProfile.systemInstruction;
        prompt += `\n\nRemember to incorporate these symbolic motifs into your response: ${genreProfile.symbolicMotifs.join(', ')}.`;
    }

    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                temperature: 0.8,
            }
        });

        const generatedContent = response.text;

        const artifact: Omit<NarrativeArtifact, 'id'> = {
            title: `Artifact from Take @ ${new Date(take.startTime).toLocaleTimeString()}`,
            generatedAt: Date.now(),
            sourceTakeId: take.id,
            styleProfileId: profile.id,
            content: generatedContent,
        };
        
        return {
            id: `art_${Date.now()}`,
            ...artifact
        };

    } catch (error) {
        console.error('Gemini API Error during artifact generation:', error);
        throw new Error(`Failed to generate artifact from Google: ${error instanceof Error ? error.message : String(error)}`);
    }
};

export const weaveNarrativeFromBundle = async (bundle: CollapsedNarrativeBundle, template: RealityWeaveTemplate, project: QuantumForgeProject, modelId: string = 'gemini-2.5-flash'): Promise<string> => {
    const ai = getGoogleAI();
    if (!ai) throw new Error("Google AI client not initialized.");

    const nodesById = project.nodeGraph.nodes.reduce((acc, node) => {
            acc[node.id] = node;
            return acc;
        }, {} as Record<string, QuantumForgeNode>);

    const logSummary = bundle.auditLog.map(entry => {
        const nodeLabel = nodesById[entry.collapsedNodeId]?.label || 'Unknown Node';
        return `At ${new Date(entry.timestamp).toLocaleTimeString()}, the possibility within "${nodeLabel}" collapsed into the reality: "${entry.chosenOutcome.content}"`;
    }).join('\n');

    const prompt = `
        A story has been resolved from a series of quantum possibilities. Below is the chronological log of how the story was "woven" into a single reality. Your task is to transform this log into a final narrative piece, following the provided template.

        REALITY WEAVE LOG:
        ---
        ${logSummary}
        ---

        Please generate the final narrative based on this log.
    `;

    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: prompt,
            config: {
                systemInstruction: template.systemInstruction,
                temperature: 0.75,
            }
        });
        return response.text;
    } catch (error) {
        console.error('Gemini API Error during narrative weaving:', error);
        throw new Error(`Failed to weave narrative from Google: ${error instanceof Error ? error.message : String(error)}`);
    }
};

export const analyzeNarrativeDNA = async (project: QuantumForgeProject, genreProfiles: GenreProfile[], modelId: string = 'gemini-2.5-flash'): Promise<string | null> => {
    const ai = getGoogleAI();
    if (!ai) throw new Error("Google AI client not initialized.");

    const projectContent = project.nodeGraph.nodes.map(n => n.quantumState.outcomes.map(o => o.content).join(' ')).join('\n');
    const genreOptions = genreProfiles.map(g => `- ${g.name} (${g.id}): ${g.description}`).join('\n');

    const prompt = `
        Analyze the following project content and determine which of the provided genre profiles it most closely matches.
        Respond with ONLY the ID of the best-matching genre (e.g., 'genre_cyberpunk_noir').

        GENRE PROFILES:
        ---
        ${genreOptions}
        ---

        PROJECT CONTENT:
        ---
        ${projectContent.substring(0, 4000)}
        ---

        Based on the content, the best matching genre ID is:
    `;

    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: prompt,
            config: {
                systemInstruction: "You are a literary analyst AI. Your task is to match text content to a genre profile from a given list. Respond only with the genre ID.",
                temperature: 0.1,
            }
        });
        
        const matchingId = response.text.trim();
        return genreProfiles.some(g => g.id === matchingId) ? matchingId : null;

    } catch (error) {
        console.error('Gemini API Error during DNA analysis:', error);
        throw new Error(`Failed to analyze DNA from Google: ${error instanceof Error ? error.message : String(error)}`);
    }
};


export const getPerformanceSuggestion = async (project: QuantumForgeProject, genreProfile: GenreProfile | null, modelId: string = 'gemini-2.5-flash'): Promise<string> => {
    const ai = getGoogleAI();
    if (!ai) throw new Error("Google AI client not initialized.");

    const projectSummary = `
      Project: ${project.name}
      Intent: ${project.intent || 'not specified'}
      Number of nodes: ${project.nodeGraph.nodes.length}
      Active Genre: ${genreProfile?.name || 'none'}
    `;

    const prompt = `
        Given the following project summary, provide a single, concise, and creative suggestion for the user.
        This suggestion should guide their performance or inspire a narrative event.
        The suggestion should be a short phrase or question.

        PROJECT SUMMARY:
        ---
        ${projectSummary}
        ---
    `;
    
    let systemInstruction = "You are a creative muse. Provide a short, inspiring suggestion to a storyteller.";
    if (genreProfile) {
        systemInstruction = `You are a creative muse for the ${genreProfile.name} genre. Provide a short, inspiring suggestion that fits the style.`;
    }

    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: prompt,
            config: {
                systemInstruction,
                temperature: 0.9,
            }
        });
        
        return response.text.trim();
    } catch (error) {
        console.error('Gemini API Error during suggestion generation:', error);
        throw new Error(`Failed to get suggestion from Google: ${error instanceof Error ? error.message : String(error)}`);
    }
}

export const generateNarrativeArc = async (seed: NarrativeSeed, config: EvolutionaryAlgorithmConfig, genre: GenreProfile, archetype: MythicArchetype, modelId: string = 'gemini-2.5-flash'): Promise<ProceduralArc> => {
    const ai = getGoogleAI();
    if (!ai) throw new Error("Google AI client not initialized.");

    const prompt = `
    Generate a 3-scene narrative arc based on the provided seed.
    - Genre: ${genre.name}
    - Archetype: ${archetype.name}
    - Core Prompt: ${seed.corePrompt}
    - Stability: ${config.stability} (0=wildly creative, 1=very predictable)
    
    Provide a title for the arc and a title, description, and key event for each of the 3 scenes.
    `;
    
    const responseSchema = {
        type: Type.OBJECT,
        properties: {
            title: { type: Type.STRING, description: "The overall title for the narrative arc." },
            scenes: {
                type: Type.ARRAY,
                description: "An array of three scenes that form the arc.",
                items: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING, description: "The title of the scene." },
                        description: { type: Type.STRING, description: "A one-sentence description of the scene's setting and mood." },
                        keyEvent: { type: Type.STRING, description: "The single most important event or action that occurs in this scene." }
                    }
                }
            }
        }
    };

    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: prompt,
            config: {
                systemInstruction: `You are a procedural narrative generator. Your purpose is to create structured story arcs. Follow the user's instructions and the provided JSON schema precisely. The stability setting should influence your creativity; lower stability means more unusual or unexpected plot points.`,
                temperature: 1 - config.stability,
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            }
        });
        
        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);

        // Basic validation
        if (parsedJson.title && Array.isArray(parsedJson.scenes) && parsedJson.scenes.length > 0) {
            return parsedJson as ProceduralArc;
        } else {
            throw new Error("Generated JSON does not match the expected ProceduralArc schema.");
        }

    } catch (error) {
        console.error('Gemini API Error during narrative arc generation:', error);
        throw new Error(`Failed to generate arc from Google: ${error instanceof Error ? error.message : String(error)}`);
    }
};

export const mutateArchetype = async (archetype: MythicArchetype, project: QuantumForgeProject, modelId: string = 'gemini-2.5-flash'): Promise<Partial<MythicArchetype>> => {
    const ai = getGoogleAI();
    if (!ai) throw new Error("Google AI client not initialized.");
    
    const projectContext = `The project is named "${project.name}". The overall intent is: "${project.intent || 'not specified'}".`;
    
    const prompt = `
    Given the following mythic archetype and project context, suggest an evolution or mutation for it.
    Provide a new, evolved description and a new list of 4 thematic traits.
    
    Current Archetype:
    - Name: ${archetype.name}
    - Description: ${archetype.description}
    - Thematic Traits: ${archetype.thematicTraits.join(', ')}
    
    Project Context: ${projectContext}
    
    Based on this, what is a plausible evolution for this archetype?
    `;
    
    const responseSchema = {
        type: Type.OBJECT,
        properties: {
            description: { type: Type.STRING, description: "The new, evolved description for the archetype." },
            thematicTraits: {
                type: Type.ARRAY,
                description: "A list of exactly 4 new thematic traits for the evolved archetype.",
                items: { type: Type.STRING }
            }
        }
    };
    
    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: prompt,
            config: {
                systemInstruction: "You are an expert in narrative theory and mythology. Your task is to evolve character archetypes based on a story's context. Provide a new description and a list of four thematic traits in the specified JSON format.",
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            }
        });

        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);

        if (parsedJson.description && Array.isArray(parsedJson.thematicTraits)) {
            return parsedJson as Partial<MythicArchetype>;
        } else {
            throw new Error("Generated JSON does not match the expected Archetype mutation schema.");
        }
        
    } catch (error) {
        console.error('Gemini API Error during archetype mutation:', error);
        throw new Error(`Failed to mutate archetype from Google: ${error instanceof Error ? error.message : String(error)}`);
    }
};