import type { QuantumForgeProject, QuantumForgeNode, QuantumOutcome, Zone } from '../types';

export class QuantumResonanceService {
    /**
     * Calculates the effective probabilities for all nodes in a project,
     * considering any active Resonance Fields.
     * @param project The full QuantumForgeProject object.
     * @returns A Map where keys are node IDs and values are the calculated outcomes.
     */
    public static calculateEffectiveProbabilities(project: QuantumForgeProject): Map<string, QuantumOutcome[]> {
        const effectiveProbabilities = new Map<string, QuantumOutcome[]>();
        const { nodes } = project.nodeGraph;
        const resonanceZones = (project.zones || []).filter(z => z.resonanceField);
        
        const controlValues = (project.plugins || []).flatMap(p => p.controls || [])
            .reduce((acc, control) => {
                acc[control.id] = control.value;
                return acc;
            }, {} as Record<string, number>);

        for (const node of nodes) {
            if (node.quantumState.collapsed || node.quantumState.outcomes.length <= 1) {
                effectiveProbabilities.set(node.id, node.quantumState.outcomes);
                continue;
            }

            let modulationFactor = 0;
            let totalStrength = 0;

            for (const zone of resonanceZones) {
                if (this.isNodeInZone(node, zone)) {
                    const { resonanceField } = zone;
                    if (resonanceField && resonanceField.signalSource === 'control') {
                        const controlValue = controlValues[resonanceField.sourceId] ?? 0;
                        modulationFactor += controlValue * resonanceField.strength;
                        totalStrength += resonanceField.strength;
                    }
                }
            }

            const averageModulation = totalStrength > 0 ? modulationFactor / totalStrength : 0;
            
            const modulatedOutcomes = this.modulateProbabilities(node.quantumState.outcomes, averageModulation);
            effectiveProbabilities.set(node.id, modulatedOutcomes);
        }
        
        return effectiveProbabilities;
    }

    /**
     * Checks if a node's center is within a zone's rectangle.
     */
    private static isNodeInZone(node: QuantumForgeNode, zone: Zone): boolean {
        const nodeCenterX = node.position.x + 90; // width / 2
        const nodeCenterY = node.position.y + 50; // approx height / 2
        
        return (
            nodeCenterX >= zone.rect.x &&
            nodeCenterX <= zone.rect.x + zone.rect.width &&
            nodeCenterY >= zone.rect.y &&
            nodeCenterY <= zone.rect.y + zone.rect.height
        );
    }

    /**
     * Adjusts the probabilities of outcomes based on a modulation factor.
     * A factor of 0 leaves probabilities unchanged.
     * A factor towards 1 pushes probability towards the highest-probability outcome.
     */
    private static modulateProbabilities(outcomes: QuantumOutcome[], factor: number): QuantumOutcome[] {
        if (factor === 0 || outcomes.length <= 1) {
            return outcomes;
        }

        const sortedOutcomes = [...outcomes].sort((a, b) => b.probability - a.probability);
        const highestProb = sortedOutcomes[0].probability;
        const otherTotalProb = 1 - highestProb;
        
        // Calculate the amount of probability to redistribute from others to the highest
        const amountToMove = otherTotalProb * factor;
        
        const newHighestProb = highestProb + amountToMove;

        const newOutcomes = sortedOutcomes.map((outcome, index) => {
            if (index === 0) {
                return { ...outcome, probability: newHighestProb };
            }
            // Scale down other probabilities proportionally
            const originalShare = otherTotalProb > 0 ? outcome.probability / otherTotalProb : 0;
            const newProb = outcome.probability - (amountToMove * originalShare);
            return { ...outcome, probability: Math.max(0, newProb) };
        });

        // Final normalization pass to ensure it sums to 1 due to floating point math
        const finalTotal = newOutcomes.reduce((sum, o) => sum + o.probability, 0);
        return newOutcomes.map(o => ({ ...o, probability: o.probability / finalTotal }));
    }
}
