import type { QuantumComposerProject, HelpSection, ThemeConfig, MediaAsset, LLMConfig, Archetype, IconName, VisualEffectManifest, QuantumComposerNode, OutputStyleProfile, GenreProfile, MythicArchetype, RealityWeaveTemplate, BlueprintCategory, Blueprint, RoadmapState, CellStatus, BlueprintRoadmapData } from './types';
import { ROADMAP_LAYER_1, ROADMAP_LAYER_2, ROADMAP_LAYER_3, ROADMAP_LAYER_4, ROADMAP_LAYER_5, ROADMAP_LAYER_6, ROADMAP_LAYER_7, ROADMAP_LAYER_8, ROADMAP_LAYER_9, ROADMAP_LAYER_10, ROADMAP_MANUAL } from './roadmaps';

export const USER = { name: 'Creator' };

const ALL_ROADMAP_DATA = [
    ROADMAP_LAYER_1, 
    ROADMAP_LAYER_2, 
    ROADMAP_LAYER_3, 
    ROADMAP_LAYER_4, 
    ROADMAP_LAYER_5,
    ROADMAP_LAYER_6,
    ROADMAP_LAYER_7,
    ROADMAP_LAYER_8,
    ROADMAP_LAYER_9,
    ROADMAP_LAYER_10,
    ROADMAP_MANUAL
];

const createInitialRoadmapState = (roadmaps: BlueprintRoadmapData[]): RoadmapState => {
    const state: RoadmapState = {};
    
    // Default all to locked
    for (const roadmap of roadmaps) {
        state[roadmap.layerId] = {};
        for (const versionKey in roadmap.versions) {
            state[roadmap.layerId][versionKey] = {};
            for (const phaseKey in roadmap.versions[versionKey]) {
                state[roadmap.layerId][versionKey][phaseKey] = { status: 'locked' };
            }
        }
    }

    // Override with implemented features based on code analysis
    const implemented: { [layerId: string]: { [versionKey: string]: { [phaseKey: string]: CellStatus } } } = {
        'layer1_forge': {
            'V1': { 'P1': 'completed', 'P2': 'completed', 'P3': 'completed', 'P4': 'completed', 'P5': 'completed', 'P6': 'completed', 'P7': 'completed', 'P8': 'completed', 'P10': 'completed' },
            'V2': { 'P1': 'completed', 'P7': 'completed', 'P8': 'completed' },
            'V3': { 'P1': 'completed', 'P2': 'completed', 'P7': 'completed' },
            'V5': { 'P1': 'completed' },
            'V9': { 'P9': 'completed' },
        },
        'layer2_quill': {
            'V1': { 'P1': 'completed', 'P2': 'sub-phase', 'P5': 'sub-phase', 'P9': 'completed' },
            'V2': { 'P1': 'completed', 'P7': 'sub-phase' },
            'V3': { 'P2': 'sub-phase' },
            'V5': { 'P1': 'completed' },
        },
        'layer3_scribe': {
            'V1': { 'P7': 'completed' },
        },
        'layer4_remix': {
            'V1': { 'P9': 'completed' },
            'V2': { 'P7': 'completed' },
        },
        'layer5_vaults': {
            'V2': { 'P2': 'completed' },
        },
        'layer6_metaforge': {
            'V2': { 'P3': 'completed', 'P5': 'sub-phase' },
        },
        'layer7_symphony': {
            'V1': { 'P1': 'sub-phase', 'P3': 'completed', 'P5': 'completed', 'P6': 'completed' },
        },
        'layer8_choreography': {
            'V1': { 'P7': 'completed', 'P9': 'completed' },
            'V3': { 'P2': 'completed' },
        },
        'layer9_capsules': {
            'V1': { 'P1': 'completed', 'P2': 'completed', 'P10': 'completed' },
        },
    };

    for (const layerId in implemented) {
        if (state[layerId]) {
            for (const versionKey in implemented[layerId]) {
                if (state[layerId][versionKey]) {
                    for (const phaseKey in implemented[layerId][versionKey]) {
                        if (state[layerId][versionKey][phaseKey]) {
                            state[layerId][versionKey][phaseKey].status = implemented[layerId][versionKey][phaseKey];
                        }
                    }
                }
            }
        }
    }
    
    // Mark manual chapters 1-3 as complete
    if (state[ROADMAP_MANUAL.layerId]) {
        state[ROADMAP_MANUAL.layerId]['V1']['P1'] = { status: 'completed' };
        state[ROADMAP_MANUAL.layerId]['V2']['P1'] = { status: 'completed' };
        state[ROADMAP_MANUAL.layerId]['V3']['P1'] = { status: 'completed' };
    }


    return state;
};

export const INITIAL_ROADMAP_STATE = createInitialRoadmapState(ALL_ROADMAP_DATA);

const USER_MANUAL_BLUEPRINT_CONTENT = `
<div class="blueprint-section"><h3>Introductory Letter from Jeremy Dickinson</h3><p>Dear Storyteller, This isn’t just a manual. It’s a map — across signal, symbol, emotion, and performance...</p></div>
<div class="blueprint-section"><h3>User Manual Outline</h3><p>1. Introduction & Philosophy...</p></div>
<div class="blueprint-section"><h3>Chapter 1: Introduction & Philosophy of Quantum Quill</h3><p>Welcome to the cognitive frontier — where story becomes system, and meaning becomes performable...</p></div>
<!-- ... all 20 chapters and appendices would be formatted here ... -->
`;

export const BLUEPRINT_CATEGORIES: BlueprintCategory[] = [
    {
        id: 'cat_manual',
        name: 'Quantum Composer Manual',
        blueprints: [
             {
                id: 'bp_manual_roadmap',
                name: 'Manual Implementation',
                icon: 'diagram',
                description: 'Tracks the implementation progress of the User Manual chapters.',
                content: '',
                roadmap: ROADMAP_MANUAL,
            },
            {
                id: 'bp_manual_full',
                name: 'Full User Manual',
                icon: 'book-open',
                description: 'The complete Quantum Composer User Manual, Mythic Signals Edition.',
                content: USER_MANUAL_BLUEPRINT_CONTENT,
            },
        ]
    },
    {
        id: 'cat_roadmaps',
        name: 'Development Roadmaps',
        blueprints: ALL_ROADMAP_DATA.filter(r => r.layerId !== ROADMAP_MANUAL.layerId).map(roadmap => ({
            id: `bp_roadmap_${roadmap.layerId}`,
            name: roadmap.layerName,
            icon: 'diagram', // A default icon
            description: `Roadmap for ${roadmap.layerName}.`,
            content: '',
            roadmap: roadmap,
        }))
    },
    {
        id: 'cat_system',
        name: 'System Architecture',
        blueprints: [
            {
                id: 'bp_host_system',
                name: 'Host System',
                icon: 'cpu',
                description: 'Core behaviors of the Quantum Composer host application.',
                content: `
### Composer Settings

- **Theme Engine:** Supports multiple, switchable themes defined in \`constants.ts\`. Themes are applied via CSS variables for easy customization.
- **Custom Skins:** Users can upload PNGs for background and panel overlays, which are applied via the \`--custom-bg-image\` and \`--custom-panel-image\` CSS variables.

### Signal Zones (Resonance Fields)

- **Concept:** Any Zone on the canvas can be designated as a "Resonance Field".
- **Behavior:** These fields actively modulate the probabilities of any Quantum Narrative Nodes located within their boundaries.
- **Modulation:** The strength and effect of a Resonance Field are driven by a linked **Control Element** from a Plugin, allowing for real-time, performative influence on the narrative's probabilistic outcomes.
`
            },
            {
                id: 'bp_plugin_integration',
                name: 'Plugin Integration',
                icon: 'puzzle-piece',
                description: 'Protocol for integrating external plugins like Audio Architect.',
                content: `
### 1. Core Principle: Signal In, Signal Out
A plugin must be able to both **receive signals from** and **emit signals to** the Quantum Composer host. The primary mechanism for this is the **Control Element**.

### 2. Required Plugin Manifest (\`plugin.json\`)
Each plugin must provide a manifest file at its root with the following structure:
<pre><code>
{
  "id": "unique-plugin-id",
  "name": "Plugin Display Name",
  "version": "1.0.0",
  "description": "A short description of what the plugin does.",
  "icon": "synth",
  "controls": [
    {
      "id": "ctrl_unique_1",
      "label": "Master Volume",
      "type": "fader",
      "defaultValue": 0.75
    }
  ]
}
</code></pre>

### 3. Control Elements as the Bridge
- **Definition:** Control Elements (\`fader\`, \`knob\`, \`switch\`) are the UI components that a plugin exposes to the Quantum Composer host.
- **Host Interaction:** The host renders these controls within its **Plugin Manager Panel**.
- **Signal Source:** The values of these controls (from 0 to 1) are the primary signals a plugin can emit.

### 4. Integration with Quantum Composer Systems
A plugin's control signals can be linked to core Quantum Composer systems, primarily **Resonance Fields**. When a user adjusts the control, it will modulate the probabilities of nodes within that field.
`
            },
             {
                id: 'bp_plugin_capsule_loader',
                name: 'Plugin Capsule Loader',
                icon: 'puzzle-piece',
                description: 'A universal loading logic pattern for plugin capsules.',
                content: `
<div class="blueprint-section">
    <h3>⚠️ Blueprint Usage Notice (Universal Header)</h3>
    <p>This page contains reference-only Blueprints designed for modular scaffold logic in Quantum Composer. These fragments are not production-ready and should always be reviewed, contextually adapted, and version-tagged before use in runtime environments.</p>
    <p><strong>Tag Convention:</strong> (BLUEPRINT ONLY!)</p>
    <p><strong>Required Action:</strong> Audit, refactor, and version-link before activation.</p>
    <p><strong>Intended Usage:</strong> Plugin loader scaffold, signal patching, theme-link remapping.</p>
</div>

<div class="blueprint-section">
    <h3>🔌 PluginCapsuleLoader.tsx Stub</h3>
    <pre><code>
import { PluginRegistry } from './PluginRegistry';
import { CapsuleAuditOverlay } from './CapsuleAuditOverlay';

export const PluginCapsuleLoader = ({ pluginId }) => {
  const pluginData = PluginRegistry[pluginId];
  if (!pluginData || !pluginData.active) return null;

  const { archetype, signals, config } = pluginData;

  // Optional: Render capsule audit overlay if mapped
  const auditCapsule = config?.auditCapsule;
  const showOverlay = auditCapsule && signals.includes('auditOverlay.render');

  return (
    &lt;div className={\`plugin-capsule \${archetype}\`}&gt;
      &lt;h3&gt;{pluginId}&lt;/h3&gt;
      {showOverlay && (
        &lt;CapsuleAuditOverlay capsuleId={auditCapsule} theme={config?.themeId || 'XyronaPrime'} /&gt;
      )}
      {/* Render inner plugin logic dynamically */}
      &lt;PluginContentRenderer pluginId={pluginId} config={config} /&gt;
    &lt;/div&gt;
  );
};
    </code></pre>
</div>

<div class="blueprint-section">
    <h3>🎛 What This Enables</h3>
    <ul>
        <li>Universal loading logic for any plugin capsule, including Studio Scribe, GlyphTraceMap, VaultView, etc.</li>
        <li>Visual overlays, audit signals, trait injection based on signal grammar.</li>
        <li>Future support for drag-to-remix, capsule sequencing, and dock-to-panel behavior.</li>
    </ul>
</div>
`
            }
        ]
    },
    {
        id: 'cat_ui_canvas',
        name: 'UI & Canvas',
        blueprints: [
             {
                id: 'bp_ui_layout',
                name: 'UI Layout',
                icon: 'layout-grid',
                description: 'The overall UI structure and behavior map.',
                content: `
<div class="mermaid">
graph TD
    A[Quantum Composer App] --> H[Header];
    A --> F[Footer];
    A --> W[Workspace];
    
    W --> LSB[Left Static Sidebar];
    W --> LSP[Left Sliding Panel];
    W --> C[Main Canvas];
    W --> RSP[Right Sliding Panel];
    W --> RSB[Right Static Sidebar];
    
    LSB -- Toggles --> LSP;
    RSB -- Toggles --> RSP;
    
    subgraph Header
        direction LR
        H1(Title) -- H2(View Toggle);
        H2 -- H3(New Project);
    end
    
    subgraph "Main Canvas"
        C1(NodeCanvas) -- C2(QuantumQuillCanvas Overlay);
    end
</div>
`
            },
            {
                id: 'bp_canvas_interaction',
                name: 'Canvas Interaction',
                icon: 'arrows-pointing-out',
                description: 'How users interact with the main creative space.',
                content: `
### NodeNest (Node Graph)
- **Core Component:** \`NodeCanvas.tsx\`
- **Functionality:** A spatial, zoomable, and pannable canvas that houses Quantum Composer Nodes.
- **Interactions:** Drag-and-drop node creation, marquee selection, connecting nodes via ports, context-menus.
- **Quantum State Visualization:** Nodes in an uncollapsed state visually shimmer and cycle through their potential outcomes.

### CueOrbit (Zones & Resonance Fields)
- **Component:** \`Zone.tsx\`
- **Functionality:** Draggable, resizable zones for organizing nodes.
- **Resonance Fields:** When a Zone is designated as a Resonance Field, it gains a pulsing border and actively influences the nodes within it.
`
            }
        ]
    },
    {
        id: 'cat_narrative_objects',
        name: 'Narrative Objects',
        blueprints: [
            {
                id: 'bp_noir_bloom',
                name: 'Noir Bloom Drift Capsule',
                icon: 'capsule',
                description: 'A complete blueprint for a performable, remixable capsule narrative.',
                content: `
### 🧿 Capsule Manifest (v0.1)
<pre><code>
{
  "id": "capsule-noir-bloom-drift",
  "name": "Noir Bloom Drift",
  "mood": "Depth",
  "traits": ["Moody", "Introspective", "Lo-Fi Bloom"],
  "glyphStack": ["Drift", "Reflector", "Mirage"],
  "pulseCueSequence": ["DriftPhase", "ReflectCycle", "MirageWarp"]
}
</code></pre>

### 🎚️ PulseCue Choreography
| PulseCue | Behavior | Trait Bindings | Orbit Role |
| :--- | :--- | :--- | :--- |
| ⟲ DriftPhase | Stereo shimmer, LPF glide | Ambient, Temporal | Intro / Bridge |
| ∞ ReflectCycle | Recursive motif, echo lift | Reflective, Introspective | Core Loop |
| ↻ MirageWarp | Vinyl pulse, phase mod warp | Lo-Fi, Dreamy | Outro / Transition |

### 🌀 Cue Orbit Model (Mermaid Diagram)
<div class="mermaid">
graph TD
    subgraph "🌀 Cue Orbit"
        A[⟲ DriftPhase] --> B[∞ ReflectCycle];
        B --> C[↻ MirageWarp];
        C --> A;
    end
</div>
`
            },
            {
                id: 'bp_observer_audit',
                name: 'Observer Audit Log',
                icon: 'shield-check',
                description: 'The log of all quantum collapse events.',
                content: `
### Purpose
Provides a comprehensive, chronological log of every time a quantum narrative state was collapsed into a single reality. This panel serves as the definitive record of how observer influence shaped the story.

### Workflow
1. An observer uses the "Collapse Node" button in the Quantum Quill HUD.
2. The system resolves the node's probabilistic state into a single outcome.
3. An **ObserverAuditLogEntry** is created and added to the project's log.
4. The raw data from this log is used to create **Collapsed Narrative Bundles** for the "Reality Weaving" process in the Showcase Composer.
`
            },
            {
                id: 'bp_scroll_capsule',
                name: 'ScrollCapsule: Reflective Glyph Batch',
                icon: 'document-text',
                description: 'A blueprint for transmuting chat archives into performable Capsule vaults.',
                content: `
<div class="blueprint-section">
    <h3>Project Overview</h3>
    <p><strong>Project Name:</strong> ScrollCapsule: Reflective Glyph Batch</p>
    <p><strong>Goal:</strong> Transmute chat archives into a "performable Capsule vault" by parsing, staging, and structuring dialogue into modular, remixable files.</p>
    <p><strong>Core Principles:</strong> Signal before Structure, Emotion before Execution, Memory before Manifest.</p>
</div>

<div class="blueprint-section">
    <h3>Generated Artifacts & Technical Specifications</h3>
    <h4>1. <code>CapsuleManifest.json</code></h4>
    <pre><code>
{
  "title": "ScrollCapsule: Reflective Glyph Batch",
  "author": "Jeremy Dickinson",
  "remixable": true,
  "tags": [
    "emotion:curious",
    "cue:initCapsule",
    "trait:modularPulse"
  ],
  "assets": [
    "blueprint/scrolls/dialogue.md",
    "blueprint/scrolls/README.md",
    "..."
  ],
  "stage": "compile",
  "forge-ready": true,
  "loader": "CapsuleBootStudio"
}
    </code></pre>

    <h4>2. <code>blueprint/scrolls/dialogue.md</code></h4>
    <pre><code>
# Dialogue Log
Jeremy: That is nice of you but it still doesn't solve the fact that then I have to copy and paste them to a document of some sort…
Copilot: Exactly — that manual loop is the real bottleneck... Let’s not just parse the scrolls… let’s _stage_ them.
...
    </code></pre>

    <h4>3. <code>blueprint/scrolls/prologue.md</code></h4>
    <pre><code>
# Prologue: The Ritual of Refinement
This scroll began with frustration — the burden of parsing, pasting, organizing, and uploading chat fragments... But frustration, when staged with care, becomes momentum.
...
    </code></pre>

    <h4>4. <code>blueprint/scrolls/traits.json</code></h4>
    <pre><code>
{
  "traits": [
    {
      "name": "modularFrustration",
      "tags": ["emotion:bottleneck", "cue:initCapsule"],
      "description": "Activated when workflow repetition triggers design reflex."
    },
    ...
  ]
}
    </code></pre>
    
    <h4>5. <code>blueprint/scrolls/cueMap.ts</code></h4>
    <pre><code>
export const cueMap = {
  initCapsule: {
    description: "Triggers staging of modular transcript into Capsule bundle",
    traits: ["modularFrustration", "vaultVision"],
    status: "✅",
    phase: "V1P1",
    remixable: true
  },
  ...
};
    </code></pre>
</div>
`
            }
        ]
    }
];

export const THEMES: ThemeConfig[] = [
  { id: 'theme-default-dark', name: 'Default Dark', description: 'A sleek, modern dark theme.', motifs: ['modern', 'dark', 'tech'] },
  { id: 'theme-cyber-minimalist', name: 'Cyber Minimalist', description: 'A high-contrast, neon green on black theme.', motifs: ['cyberpunk', 'hacker', 'minimalist'] },
  { id: 'theme-vintage-paper', name: 'Vintage Paper', description: 'A warm, classic theme reminiscent of old books.', motifs: ['vintage', 'academic', 'warm'] },
  { id: 'theme-ancient-relic', name: 'Ancient Relic', description: 'A mysterious theme of gold on stone.', motifs: ['ancient', 'gold', 'stone'] },
  { id: 'theme-neural-narrative-designer', name: 'Neural Designer', description: 'Storytelling interfaces with adaptive memory recall.', motifs: ['neural', 'organic', 'glowing'] },
  { id: 'theme-void-hunter', name: 'Void Hunter', description: 'UI optimized for tracking entities in unknown realms.', motifs: ['tactical', 'hud', 'sharp'] },
  { id: 'theme-shadow-illusionist', name: 'Shadow Illusionist', description: 'Depth manipulation panels for illusion crafting.', motifs: ['dark', 'ethereal', 'depth'] },
  { id: 'theme-spellwright', name: 'Spellwright', description: 'Runic command panels with enchanted glyph interactions.', motifs: ['arcane', 'fantasy', 'magic'] },
  { id: 'theme-dream-cartographer', name: 'Dream Cartographer', description: 'Ethereal mapping tools for subconscious navigation.', motifs: ['dream', 'surreal', 'ethereal'] },
  { id: 'theme-synesthetic-architect', name: 'Synesthetic Architect', description: 'Multi-sensory design interfaces blending sight and sound.', motifs: ['vibrant', 'multi-sensory', 'dynamic'] },
  { id: 'theme-fractal-artisan', name: 'Fractal Artisan', description: 'Recursive pattern-generation UI.', motifs: ['geometric', 'recursive', 'precise'] },
  { id: 'theme-dream-sequencer', name: 'Dream Sequencer', description: 'Subconscious storyline panels with fluid transitions.', motifs: ['soft', 'layered', 'fluid'] },
  { id: 'theme-arcane-weather-weaver', name: 'Arcane Weather Weaver', description: 'Elemental storm manipulation interface.', motifs: ['stormy', 'elemental', 'powerful'] },
  { id: 'theme-celestial-navigator', name: 'Celestial Navigator', description: 'Star chart overlays for astral guidance.', motifs: ['space', 'constellations', 'precise'] },
];

export const GENRE_PROFILES: GenreProfile[] = [
    {
        id: 'genre_cyberpunk_noir',
        name: 'Cyberpunk Noir',
        description: 'Rain-soaked streets, neon signs, and morally ambiguous detectives in a high-tech, low-life future.',
        performativeStylings: {
            overlayColor: 'rgba(255, 0, 255, 0.05)',
            borderColor: '#ff00ff',
        },
        symbolicMotifs: ['corporate espionage', 'cybernetic enhancements', 'AI consciousness', 'digital ghosts', 'acid rain'],
        systemInstruction: 'You are a writer in the style of classic noir detective fiction blended with high-tech cyberpunk. Use gritty, concise language. Focus on themes of alienation, identity, and the blurring line between human and machine. Your tone should be cynical yet world-weary.'
    },
    {
        id: 'genre_high_fantasy',
        name: 'High Fantasy',
        description: 'Epic quests, ancient magic, and the clash of kingdoms in a world of myth and legend.',
        performativeStylings: {
            overlayColor: 'rgba(212, 175, 55, 0.05)',
            borderColor: '#d4af37',
        },
        symbolicMotifs: ['ancient prophecies', 'lost relics', 'dragon fire', 'elven lineage', 'dark sorcery'],
        systemInstruction: 'You are a master epic fantasy author. Your prose should be rich and descriptive, evoking a sense of history, grandeur, and magic. Focus on themes of destiny, heroism, and the struggle between light and darkness. Use elevated language and formal sentence structures.'
    },
    {
        id: 'genre_cosmic_horror',
        name: 'Cosmic Horror',
        description: 'The terrifying revelation of humanity\'s insignificance in the face of incomprehensible, ancient entities.',
        performativeStylings: {
            overlayColor: 'rgba(74, 0, 224, 0.05)',
            borderColor: '#4a00e0',
        },
        symbolicMotifs: ['non-euclidean geometry', 'forbidden knowledge', 'insanity', 'eldritch gods', 'whispers from the void'],
        systemInstruction: 'You are a writer in the style of H.P. Lovecraft. Your writing should build a sense of dread and unease. Focus on the psychological terror of the unknown and the fragility of the human mind. Use complex sentences and a vocabulary that emphasizes the alien and incomprehensible.'
    }
];

export const MYTHIC_ARCHETYPES: MythicArchetype[] = [
    {
        id: 'arch_hero',
        name: 'The Hero',
        description: 'A character who embarks on a journey, faces adversity, and emerges transformed.',
        thematicTraits: ['courage', 'sacrifice', 'determination', 'flaw'],
    },
    {
        id: 'arch_mentor',
        name: 'The Mentor',
        description: 'A wise and trusted guide who prepares the hero for their journey.',
        thematicTraits: ['wisdom', 'guidance', 'experience', 'protection'],
    },
    {
        id: 'arch_trickster',
        name: 'The Trickster',
        description: 'A mischievous entity who challenges the status quo and brings about change through chaos and cunning.',
        thematicTraits: ['wit', 'deception', 'boundary-crossing', 'unpredictability'],
    },
    {
        id: 'arch_shadow',
        name: 'The Shadow',
        description: 'The antagonist or the hero\'s inner darkness, representing repressed desires and fears.',
        thematicTraits: ['antagonism', 'repression', 'fear', 'projection'],
    }
];

const BASE_PROJECT_TEMPLATE: Omit<QuantumComposerProject, 'id' | 'name' | 'description' | 'icon' | 'isTemplate' | 'tags' | 'createdAt' | 'updatedAt' | 'nodeGraph' | 'activeGenreProfileId'> = {
    plugins: [],
    performativeTakes: [],
    narrativeArtifacts: [],
    showcaseCapsules: [],
    linkedShells: [],
    ritualLinks: [],
    apiConfigs: [],
    mythicArchetypes: [],
    narrativeSeeds: [],
    observerAuditLog: [],
    collapsedNarrativeBundles: [],
    roadmapState: JSON.parse(JSON.stringify(INITIAL_ROADMAP_STATE)),
    scrollCapsules: [],
    traitRegistry: { id: 'default_traits', name: 'Default Traits', traits: [] },
    symbolRegistry: { id: 'default_symbols', name: 'Default Symbols', symbols: [] },
};

export const GENRE_TEMPLATES: QuantumComposerProject[] = [
  {
    ...BASE_PROJECT_TEMPLATE,
    id: 'template_blank',
    name: 'Blank Canvas',
    description: 'A completely empty project. The purest start.',
    icon: 'cubes',
    isTemplate: true,
    tags: ['Core'],
    createdAt: Date.now(),
    updatedAt: Date.now(),
    nodeGraph: { nodes: [], connections: [] },
    activeGenreProfileId: null,
  },
  {
    ...BASE_PROJECT_TEMPLATE,
    id: 'template_novel',
    name: 'Novel Structure',
    description: 'A basic scaffold for a novel with characters, plot, and chapters.',
    icon: 'notebook',
    isTemplate: true,
    tags: ['Narrative', 'Writing'],
    createdAt: Date.now(),
    updatedAt: Date.now(),
    nodeGraph: {
      nodes: [
